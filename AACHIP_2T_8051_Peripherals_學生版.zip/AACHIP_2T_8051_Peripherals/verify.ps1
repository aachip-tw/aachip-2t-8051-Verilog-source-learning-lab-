$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 if(Test-Path teaching_manifest.json) {
  & python verify_teaching.py
  if($LASTEXITCODE -ne 0){throw 'Teaching-source verification failed'}
 } else {
  foreach($entry in (Get-Content source_manifest.json -Raw | ConvertFrom-Json)) {
   if((Get-FileHash $entry.destination -Algorithm SHA256).Hash -ne $entry.sha256){throw "Hash mismatch: $($entry.destination)"}
  }
 }
 & cmd.exe /d /c "iverilog -g2012 -Wall -s tb_peripherals -o build/test.vvp -c files.f tests/tb_peripherals.v 2>&1" | Tee-Object build/compile.log
 if($LASTEXITCODE -ne 0){throw 'Compile failed'}
 & vvp build/test.vvp | Tee-Object build/simulation.log
 if($LASTEXITCODE -ne 0){throw 'Simulation failed'}
} finally {Pop-Location}
