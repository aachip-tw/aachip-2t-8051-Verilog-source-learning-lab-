"""Audit the actual standalone engine, without printing any possible secret value."""
from pathlib import Path
import hashlib,json,re,sys,struct
ROOT=Path(__file__).resolve().parents[1]
engine=ROOT/'tools/TeachingEngine'
output=ROOT/'build/teaching_engine_audit.json'
forbidden=['LicenseService','LicenseCrypto','NativeLicense','LicenseSettings','FtdiSecret','WebRequestAesKey','WebLicenseSalt','license_form','System.Windows.Forms','FTD2XX','aachip_8051emulator','ActiveKey','AuthDate']
findings=[];files=[]
for p in sorted(engine.rglob('*')):
    if not p.is_file() or 'obj' in p.parts or 'bin' in p.parts:continue
    data=p.read_bytes()
    if p.suffix.lower() in ('.ini','.key','.pem','.pfx','.p12'):findings.append({'file':str(p.relative_to(ROOT)),'type':'unexpected credential/config file'})
    for marker in forbidden:
        if marker.encode() in data or marker.encode('utf-16le') in data:
            findings.append({'file':str(p.relative_to(ROOT)),'type':'forbidden component identifier','identifier':marker})
    if b'-----BEGIN PRIVATE KEY-----' in data or b'-----BEGIN RSA PRIVATE KEY-----' in data:
        findings.append({'file':str(p.relative_to(ROOT)),'type':'private-key block'})
    if p.suffix=='.deps.json':
        deps=json.loads(data)
        if set(deps.get('libraries',{}))!={'Aachip.TeachingCompiler/1.0.0'}:
            findings.append({'file':str(p.relative_to(ROOT)),'type':'unexpected dependency'})
    files.append({'file':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
for relative in ('tools/aachip','tools/IdeAssembler'):
    if (ROOT/relative).exists():findings.append({'file':relative,'type':'old full IDE engine still present'})
native=engine/'aot/Aachip.TeachingCompiler.exe'
native_result={'exists':native.exists(),'machine':None,'clr_directory_size':None}
if native.exists():
    data=native.read_bytes();pe=struct.unpack_from('<I',data,0x3c)[0]
    machine=struct.unpack_from('<H',data,pe+4)[0];optional=pe+24
    magic=struct.unpack_from('<H',data,optional)[0]
    directory=optional+(112 if magic==0x20b else 96)
    clr_rva,clr_size=struct.unpack_from('<II',data,directory+14*8)
    native_result.update(machine=hex(machine),clr_directory_size=clr_size)
    if machine!=0x8664 or clr_rva or clr_size:findings.append({'file':str(native.relative_to(ROOT)),'type':'not a native x64 PE executable'})
else:findings.append({'file':str(native.relative_to(ROOT)),'type':'missing native executable'})
report={'status':'FAIL' if findings else 'PASS','native_pe':native_result,'scope':'Standalone compiler source and native deliverable; identifier and private-key-block checks. Not a proof that arbitrary unknown secrets cannot exist.','files':files,'findings':findings}
output.parent.mkdir(exist_ok=True);output.write_text(json.dumps(report,indent=2),encoding='utf-8')
print(f'{report["status"]}: standalone engine audit; {len(files)} files, {len(findings)} findings. Report: {output}')
sys.exit(bool(findings))
