"""Standalone two-pass 8051 teaching assembler. No IDE/native dependencies.

Accepts canonical Intel 8051 instructions, ORG/DB/DW/DS/EQU/END and expressions.
Unsupported macros/includes fail explicitly; output is never silently truncated.
"""
from pathlib import Path
import ast,operator,re
BANNER='//AACHIP TECHNOLOGY CO LTD;TAIWAN 合合科技有限公司'

class AssemblyError(ValueError):pass
def normalize(text):
    return ''.join(part if part.startswith(('"',"'")) else part.upper() for part in re.split(r'("[^"\n]*"|\'[^\'\n]*\')',text))
class Assembler:
    def __init__(self):
        self.symbols={'P0':0x80,'SP':0x81,'DPL':0x82,'DPH':0x83,'PCON':0x87,'TCON':0x88,'TMOD':0x89,'TL0':0x8a,'TL1':0x8b,'TH0':0x8c,'TH1':0x8d,'P1':0x90,'SCON':0x98,'SBUF':0x99,'P2':0xa0,'IE':0xa8,'P3':0xb0,'IP':0xb8,'PSW':0xd0,'ACC':0xe0,'B':0xf0}
        self.first=True;self.pc=0
    def value(self,text):
        text=normalize(text.strip())
        text=re.sub(r'\$(?=(?:[^\'"]|\'[^\']*\'|"[^"]*")*$)',str(self.pc),text)
        text=re.sub(r'\b([0-9][0-9A-F]*)H\b',lambda m:str(int(m[1],16)),text)
        text=re.sub(r'\b([01]+)B\b',lambda m:str(int(m[1],2)),text)
        ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.FloorDiv:operator.floordiv,ast.BitOr:operator.or_,ast.BitAnd:operator.and_,ast.BitXor:operator.xor,ast.LShift:operator.lshift,ast.RShift:operator.rshift}
        def visit(n):
            if isinstance(n,ast.Constant) and isinstance(n.value,int):return n.value
            if isinstance(n,ast.Constant) and isinstance(n.value,str) and len(n.value)==1:return ord(n.value)
            if isinstance(n,ast.Name):
                if n.id in self.symbols:return self.symbols[n.id]
                if self.first:return 0
                raise AssemblyError('Undefined symbol: '+n.id)
            if isinstance(n,ast.UnaryOp) and isinstance(n.op,(ast.UAdd,ast.USub,ast.Invert)):
                v=visit(n.operand);return v if isinstance(n.op,ast.UAdd) else -v if isinstance(n.op,ast.USub) else ~v
            if isinstance(n,ast.BinOp) and type(n.op) in ops:return ops[type(n.op)](visit(n.left),visit(n.right))
            raise AssemblyError('Unsupported expression: '+text)
        return visit(ast.parse(text,mode='eval').body)
    def byte(self,x,immediate=False):
        v=self.value(x.lstrip('#') if immediate else x)
        if not self.first and not ((-128 if immediate else 0)<=v<=255):raise AssemblyError('Byte out of range: '+x)
        return v&255
    def layout_value(self,text):
        first=self.first
        try:
            self.first=False
            return self.value(text)
        finally:self.first=first
    def word(self,x):
        v=self.value(x.lstrip('#'))
        if not self.first and not -32768<=v<=65535:raise AssemblyError('Word out of range')
        return [(v>>8)&255,v&255]
    def bit(self,x):
        m=re.fullmatch(r'(.+)\.([0-7])',x)
        if not m:return self.byte(x)
        base=self.value(m[1]);bit=int(m[2])
        if 0x20<=base<=0x2f:return (base-0x20)*8+bit
        if 0x80<=base<=0xf8 and base%8==0:return base+bit
        raise AssemblyError('Not bit-addressable: '+x)
    def rel(self,x,length):
        if self.first:return 0
        distance=(self.value(x)-(self.pc+length))&65535
        if distance>=32768:distance-=65536
        if not -128<=distance<=127:raise AssemblyError('Relative jump out of range: '+x)
        return distance&255
    @staticmethod
    def rn(s):return int(s[1]) if re.fullmatch(r'R[0-7]',s) else None
    @staticmethod
    def ri(s):return int(s[2]) if re.fullmatch(r'@R[01]',s) else None
    def encode(self,m,a):
        b=self.byte;rn=self.rn;ri=self.ri
        fixed={'NOP':([],0x00),'RET':([],0x22),'RETI':([],0x32),'RR':(['A'],3),'RRC':(['A'],0x13),'RL':(['A'],0x23),'RLC':(['A'],0x33),'SWAP':(['A'],0xc4),'DA':(['A'],0xd4),'MUL':(['AB'],0xa4),'DIV':(['AB'],0x84)}
        if m in fixed and a==fixed[m][0]:return [fixed[m][1]]
        if m in ('LJMP','LCALL') and len(a)==1:return [2 if m=='LJMP' else 0x12]+self.word(a[0])
        if m in ('AJMP','ACALL') and len(a)==1:
            t=self.value(a[0]);
            if not self.first and (t&0xf800)!=((self.pc+2)&0xf800):raise AssemblyError('11-bit jump crosses page')
            return [(1 if m=='AJMP' else 0x11)|((t>>3)&0xe0),t&255]
        if m=='JMP' and a==['@A+DPTR']:return [0x73]
        if m in ('SJMP','JC','JNC','JZ','JNZ') and len(a)==1:return [{'SJMP':0x80,'JC':0x40,'JNC':0x50,'JZ':0x60,'JNZ':0x70}[m],self.rel(a[0],2)]
        if m in ('JB','JNB','JBC') and len(a)==2:return [{'JB':0x20,'JNB':0x30,'JBC':0x10}[m],self.bit(a[0]),self.rel(a[1],3)]
        if m in ('CLR','CPL','SETB') and len(a)==1:
            if a[0]=='C':return [{'CLR':0xc3,'CPL':0xb3,'SETB':0xd3}[m]]
            if a[0]=='A' and m!='SETB':return [0xe4 if m=='CLR' else 0xf4]
            return [{'CLR':0xc2,'CPL':0xb2,'SETB':0xd2}[m],self.bit(a[0])]
        if m in ('PUSH','POP') and len(a)==1:return [0xc0 if m=='PUSH' else 0xd0,b(a[0])]
        if m in ('INC','DEC') and len(a)==1:
            d=a[0];base=0 if m=='INC' else 0x10
            if d=='A':return [base+4]
            if d=='DPTR' and m=='INC':return [0xa3]
            if rn(d)!=None:return [base+8+rn(d)]
            if ri(d)!=None:return [base+6+ri(d)]
            return [base+5,b(d)]
        if m in ('ADD','ADDC','SUBB','ANL','ORL','XRL') and len(a)==2:
            d,s=a
            if d=='A':
                base={'ADD':0x20,'ADDC':0x30,'SUBB':0x90,'ANL':0x50,'ORL':0x40,'XRL':0x60}[m]
                if s.startswith('#'):return [base+4,b(s,True)]
                if rn(s)!=None:return [base+8+rn(s)]
                if ri(s)!=None:return [base+6+ri(s)]
                return [base+5,b(s)]
            if m in ('ANL','ORL') and d=='C':
                base=0x82 if m=='ANL' else 0x72
                return [base+0x2e if s.startswith('/') else base,self.bit(s.lstrip('/'))]
            if m in ('ANL','ORL','XRL'):
                base={'ANL':0x50,'ORL':0x40,'XRL':0x60}[m]
                if s=='A':return [base+2,b(d)]
                if s.startswith('#'):return [base+3,b(d),b(s,True)]
        if m=='MOV' and len(a)==2:
            d,s=a
            if d=='DPTR' and s.startswith('#'):return [0x90]+self.word(s)
            if d=='C':return [0xa2,self.bit(s)]
            if s=='C':return [0x92,self.bit(d)]
            if d=='A':
                if s.startswith('#'):return [0x74,b(s,True)]
                if rn(s)!=None:return [0xe8+rn(s)]
                if ri(s)!=None:return [0xe6+ri(s)]
                return [0xe5,b(s)]
            if rn(d)!=None:
                if s=='A':return [0xf8+rn(d)]
                if s.startswith('#'):return [0x78+rn(d),b(s,True)]
                return [0xa8+rn(d),b(s)]
            if ri(d)!=None:
                if s=='A':return [0xf6+ri(d)]
                if s.startswith('#'):return [0x76+ri(d),b(s,True)]
                return [0xa6+ri(d),b(s)]
            if s=='A':return [0xf5,b(d)]
            if s.startswith('#'):return [0x75,b(d),b(s,True)]
            if rn(s)!=None:return [0x88+rn(s),b(d)]
            if ri(s)!=None:return [0x86+ri(s),b(d)]
            return [0x85,b(s),b(d)]
        if m=='MOVC' and len(a)==2 and a[0]=='A' and a[1] in ('@A+PC','@A+DPTR'):return [0x83 if a[1]=='@A+PC' else 0x93]
        if m=='MOVX' and len(a)==2:
            d,s=a
            if d=='A':
                if s=='@DPTR':return [0xe0]
                if ri(s)!=None:return [0xe2+ri(s)]
            if s=='A':
                if d=='@DPTR':return [0xf0]
                if ri(d)!=None:return [0xf2+ri(d)]
        if m in ('XCH','XCHD') and len(a)==2 and a[0]=='A':
            s=a[1]
            if m=='XCHD' and ri(s)!=None:return [0xd6+ri(s)]
            if m=='XCH':
                if rn(s)!=None:return [0xc8+rn(s)]
                if ri(s)!=None:return [0xc6+ri(s)]
                return [0xc5,b(s)]
        if m=='DJNZ' and len(a)==2:
            if rn(a[0])!=None:return [0xd8+rn(a[0]),self.rel(a[1],2)]
            return [0xd5,b(a[0]),self.rel(a[1],3)]
        if m=='CJNE' and len(a)==3:
            d,s,t=a
            if d=='A':return [0xb4 if s.startswith('#') else 0xb5,b(s,s.startswith('#')),self.rel(t,3)]
            if s.startswith('#'):
                if rn(d)!=None:return [0xb8+rn(d),b(s,True),self.rel(t,3)]
                if ri(d)!=None:return [0xb6+ri(d),b(s,True),self.rel(t,3)]
        raise AssemblyError('Unsupported operands/instruction: '+m+' '+','.join(a))
    def assemble(self,text):
        listing=[];image={};defined=set()
        lines=text.splitlines()
        for first in (True,False):
            self.first=first;self.pc=0
            for number,line in enumerate(lines,1):
                try:
                    # Compiler strings use numeric DB; quoted DB strings supported below.
                    line=re.split(r';(?=(?:[^\'"]|\'[^\']*\'|"[^"]*")*$)',line,maxsplit=1)[0].strip()
                    if not line or line.startswith('//'):continue
                    eq=re.fullmatch(r'(\w+)\s+EQU\s+(.+)',line,re.I)
                    if eq:
                        self.symbols[eq[1].upper()]=self.layout_value(eq[2]);continue
                    label=re.match(r'^(\w+):',line)
                    if label:
                        name=label[1].upper()
                        if first:
                            if name in defined:raise AssemblyError('Duplicate label: '+name)
                            defined.add(name);self.symbols[name]=self.pc
                        line=line[label.end():].strip()
                        if not line:continue
                    parts=line.split(None,1);m=parts[0].upper();operand=parts[1].strip() if len(parts)>1 else ''
                    if m=='END':break
                    if m=='ORG':
                        self.pc=self.layout_value(operand)
                        if not 0<=self.pc<=65535:raise AssemblyError('ORG outside ROM')
                        continue
                    if m in ('DB','DW'):
                        data=[]
                        for field in re.split(r',(?=(?:[^\'"]|\'[^\']*\'|"[^"]*")*$)',operand):
                            field=field.strip()
                            if m=='DB' and field.startswith(('"',"'")):
                                data.extend(ast.literal_eval(field).encode('latin1'))
                            else:data.extend([self.byte(field,True)] if m=='DB' else self.word(field))
                    elif m=='DS':
                        count=self.layout_value(operand)
                        if not 0<=count<=65536:raise AssemblyError('Invalid DS')
                        data=[0]*count
                    else:data=self.encode(m,[normalize(s.strip()) for s in operand.split(',')] if operand else [])
                    if self.pc+len(data)>65536:raise AssemblyError('ROM overflow')
                    if not first:
                        for offset,value in enumerate(data):
                            address=self.pc+offset
                            if address in image:raise AssemblyError('Overlapping ROM data')
                            image[address]=value
                        listing.append(f'{self.pc:04X} '+ ' '.join(f'{b:02X}' for b in data)+'    '+line)
                    self.pc+=len(data)
                except Exception as e:raise AssemblyError(f'ASM line {number}: {e}') from e
        end=max(image,default=-1)+1
        return bytes(image.get(a,0) for a in range(end)),listing

def write_outputs(asm_path):
    asm_path=Path(asm_path);binary,listing=Assembler().assemble(asm_path.read_text(encoding='utf-8-sig'))
    asm_path.with_suffix('.bin').write_bytes(binary)
    records=[]
    for address in range(0,len(binary),16):
        block=binary[address:address+16]
        record=bytes([len(block),address>>8,address&255,0])+block
        records.append(':'+record.hex().upper()+f'{(-sum(record))&255:02X}')
    records.append(':00000001FF')
    asm_path.with_suffix('.hex').write_text('\n'.join(records)+'\n')
    for suffix in ('.Dis','.Lst','.LIS'):
        asm_path.with_suffix(suffix).write_text(BANNER+'\n'+'\n'.join(listing)+'\n',encoding='utf-8')
    asm_path.with_suffix('.bin.txt').write_text(BANNER+'\nRaw 8051 ROM binary; no text bytes are inserted into the BIN.\n',encoding='utf-8')
    asm_path.with_suffix('.hex.txt').write_text(BANNER+'\nIntel HEX; only valid data/checksum records are stored in the HEX.\n',encoding='utf-8')
    return binary
