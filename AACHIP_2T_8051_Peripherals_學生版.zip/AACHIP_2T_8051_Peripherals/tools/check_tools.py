from pathlib import Path
import shutil,subprocess,os,sys
root=Path(__file__).resolve().parents[1]
failed=[]
for tool in ('python','iverilog','vvp','yosys'):
    path=shutil.which(tool)
    print(f'{tool}: {path or "MISSING"}')
    if not path:failed.append(tool)
for p in ('tools/TeachingEngine/aot/Aachip.TeachingCompiler.exe','tools/teaching_engine.py','tools/assembler8051.py'):
    if not (root/p).exists():failed.append(p)
gtk=Path(os.environ.get('GTKWAVE_EXE',r'C:\gtkwave-3.3.100-bin-win32\gtkwave\bin\gtkwave.exe'))
print(f'GTKWave: {gtk} [{"OK" if gtk.exists() else "MISSING"}]')
if not gtk.exists():failed.append('GTKWave; set GTKWAVE_EXE')
if failed:
    print('FAIL: '+', '.join(failed));sys.exit(1)
print('PASS: required tools found. See docs/8051實驗操作手冊.md')
