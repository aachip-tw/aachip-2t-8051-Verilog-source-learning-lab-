"""Technology-independent synthesis of the basic 8051 CPU (not the testbench)."""
from pathlib import Path
import subprocess,shutil,sys,os
root=Path(__file__).resolve().parents[1]
out=root/'build/synthesis';out.mkdir(parents=True,exist_ok=True)
if not shutil.which('yosys'):sys.exit('Missing yosys; install OSS CAD Suite and add bin to PATH')
files=(root/'files_8051.f').read_text().split()
script='read_verilog '+ ' '.join('"'+f+'"' for f in files)+'\nhierarchy -check -top aachip_8051_top\nsynth -top aachip_8051_top\ncheck -assert\nstat\nwrite_json build/synthesis/8051.json\nwrite_verilog -noattr build/synthesis/8051_netlist.v\n'
(out/'synth.ys').write_text(script)
env=os.environ.copy()
env['PATH']=str(Path(shutil.which('yosys')).resolve().parents[1]/'lib')+os.pathsep+env.get('PATH','')
with (out/'synthesis.log').open('w') as f:
 result=subprocess.run(['yosys','-s',str(out/'synth.ys')],cwd=root,stdout=f,stderr=subprocess.STDOUT,env=env)
if result.returncode:sys.exit('Synthesis failed; see build/synthesis/synthesis.log')
print('PASS: generic 8051 synthesis/check; JSON and netlist in build/synthesis. No FPGA timing/board claim.')
