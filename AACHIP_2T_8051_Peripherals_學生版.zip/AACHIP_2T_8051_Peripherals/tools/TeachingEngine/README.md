# AACHIP Native AOT teaching compiler

Student distribution: aot/Aachip.TeachingCompiler.exe (Windows x64).
Requires Python 3.10+ for the assembler wrapper; no .NET Runtime or SDK installation.
Run python tools/teaching_engine.py main.c from the lab root.
Compiler C# source and build intermediates are not included in this student distribution.
Native machine code remains subject to reverse engineering. See docs/精簡教學引擎.md and the root NOTICE.
