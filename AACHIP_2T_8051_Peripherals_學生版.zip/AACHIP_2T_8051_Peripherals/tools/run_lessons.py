"""Standalone AACHIP teaching C compiler -> assembler -> RTL -> VCD/GTKWave."""
from pathlib import Path
import argparse,subprocess,shutil,json,hashlib,re,math,os,sys
ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'Learn-Embedded-C-with-8051-Microcontroller-master'
BUILD=ROOT/'build/lessons'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(cmd,log,cwd=ROOT):
    with log.open('w',encoding='utf-8') as f:
        result=subprocess.run([str(c) for c in cmd],cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
    if result.returncode:raise RuntimeError(f'Command failed ({result.returncode}): {log}\n'+log.read_text(encoding='utf-8',errors='replace')[-4000:])
def waves(out,lesson,cycles):
    core=['clk','rst_n','image_reset_bytes[23:0]','image_reset_target[15:0]','fetch','pc[15:0]','rom_addr[15:0]','rom_data[7:0]','opcode[7:0]','state[4:0]','acc[7:0]','sp[7:0]','psw[7:0]','last_instruction_clocks[31:0]']
    relevant=['led','p0[7:0]','p0_pin[7:0]','p1[7:0]','p2[7:0]','p3[7:0]']
    if lesson in (6,7,8):relevant+=['external_p0[7:0]','button_pressed','switch_a_pressed','switch_b_pressed']
    if lesson==5:relevant+=['lcd_rs','lcd_en','lcd_data[3:0]']
    if lesson==9:relevant+=['tr0','tf0','th0[7:0]','tl0[7:0]','tcon[7:0]','tmod[7:0]']
    relevant+=['ram_addr[7:0]','ram_wr_data[7:0]','ram_wr_en','ram_rd_en']
    for name,zoom in [('detail',-7),('overview',-math.ceil(math.log2(max(1,cycles*10000/1000))))]:
        text=f'[*] //AACHIP TECHNOLOGY CO LTD;TAIWAN 合合科技有限公司\n[*] AACHIP lesson {lesson:02d}; PC, ROM DATA, CLK\n[dumpfile] "{(out/"wave.vcd").as_posix()}"\n[timestart] 0\n[size] 1500 900\n*{zoom}.000000 0 0 0 0 0\n'
        for signal in core+relevant:
            text+=('@22\n' if '[' in signal else '@28\n')+'tb_lessons.'+signal+'\n'
        (out/f'{name}.gtkw').write_text(text,encoding='utf-8')
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lesson',nargs='?',default='all',help='all or 01..09')
    parser.add_argument('--open',action='store_true',help='Open each successful result in GTKWave')
    parser.add_argument('--waves-only',action='store_true',help='Open existing successful results without rebuilding')
    parser.add_argument('--full',action='store_true',help='Original long delays; allow more simulation clocks with --maxcycles')
    parser.add_argument('--maxcycles',type=int,default=500000)
    args=parser.parse_args()
    BUILD.mkdir(parents=True,exist_ok=True)
    for tool in ('iverilog','vvp'):
        if not shutil.which(tool):raise RuntimeError(f'Missing {tool}; see docs/8051實驗操作手冊.md')
    compiler=ROOT/'tools/TeachingEngine/aot/Aachip.TeachingCompiler.exe'
    assembler=ROOT/'tools/assembler8051.py'
    if not compiler.exists():raise RuntimeError('Missing TeachingCompiler; run 00_CHECK_TOOLS.bat')
    selected=[p for p in sorted(BASE.iterdir()) if p.is_dir() and (p/'main.c').exists() and (args.lesson=='all' or int(p.name[:2])==int(args.lesson))]
    if not selected:raise RuntimeError('No matching lesson')
    gtkwave=os.environ.get('GTKWAVE_EXE',r'C:\gtkwave-3.3.100-bin-win32\gtkwave\bin\gtkwave.exe')
    if args.open or args.waves_only:
        if not Path(gtkwave).exists():raise RuntimeError('GTKWave missing; set GTKWAVE_EXE')
    if not args.waves_only:
        config=(BASE/'lab_config.h').read_text()
        if args.full:config=config.replace('#define LAB_FAST_SIM 1','#define LAB_FAST_SIM 0')
        (BUILD/'lab_config.h').write_text(config)
        run(['iverilog','-g2012','-Wall','-s','tb_lessons','-o',BUILD/'lessons.vvp','-c','files_8051.f','tests/tb_lessons.v'],BUILD/'rtl_compile.log')
    results=[]
    for example in selected:
        lesson=int(example.name[:2]);out=BUILD/example.name;out.mkdir(exist_ok=True)
        result_path=out/'result.json'
        if args.waves_only:
            result=json.loads(result_path.read_text())
            if result.get('status')!='PASS':raise RuntimeError(f'{example.name}: no PASS result')
        else:
            result={'lesson':example.name,'status':'RUNNING','profile':'full' if args.full else 'fast','source_sha256':sha(example/'main.c'),'compiler_engine_sha256':sha(compiler),'assembler_sha256':sha(assembler)}
            result_path.write_text(json.dumps(result,indent=2))
            shutil.copy2(example/'main.c',out/'main.c')
            for h in example.glob('*.h'):shutil.copy2(h,out/h.name)
            # A failed build must not be mistaken for a prior successful image.
            for name in ('main.bin','main.hex','wave.vcd','detail.gtkw','overview.gtkw'):
                p=out/name
                if p.exists():p.unlink()
            try:
                run([sys.executable,ROOT/'tools/teaching_engine.py',out/'main.c'],out/'c_compile.log')
                binary=(out/'main.bin').read_bytes()
                assert binary[0]==2,'Expected reset LJMP'
                assert len(binary)<=65536
                # Independently verify every Intel HEX record and exact BIN equivalence.
                image=bytearray(65536);present=set()
                for line in (out/'main.hex').read_text().splitlines():
                    raw=bytes.fromhex(line[1:]);assert sum(raw)%256==0
                    if raw[3]==0:
                        addr=int.from_bytes(raw[1:3],'big')
                        for j,b in enumerate(raw[4:4+raw[0]]):image[addr+j]=b;present.add(addr+j)
                    elif raw[3]==1:break
                    else:raise RuntimeError('Unexpected HEX record')
                assert image[:len(binary)]==binary and present==set(range(len(binary)))
                rom=binary+bytes(65536-len(binary))
                (out/'rom.mem').write_text('//AACHIP TECHNOLOGY CO LTD;TAIWAN 合合科技有限公司\n'+'\n'.join(f'{b:02x}' for b in rom)+'\n',encoding='utf-8')
                run(['vvp',BUILD/'lessons.vvp',f'+outdir={out.as_posix()}',f'+lesson={lesson}',f'+maxcycles={args.maxcycles}'],out/'simulation.log')
                vcd=out/'wave.vcd'
                vcd.write_bytes(b'$comment //AACHIP TECHNOLOGY CO LTD;TAIWAN $end\n'+vcd.read_bytes())
                vcd.with_suffix('.vcd.txt').write_text('//AACHIP TECHNOLOGY CO LTD;TAIWAN 合合科技有限公司\nGTKWave 3.3.100 requires an ASCII-only VCD comment.\n',encoding='utf-8')
                log=(out/'simulation.log').read_text()
                m=re.search(r'PASS lesson=(\d+) cycles=(\d+) instructions=(\d+) checks=(\d+) 2T_samples=(\d+)',log)
                if not m:raise RuntimeError('Simulation did not report PASS')
                cycles=int(m[2]);waves(out,lesson,cycles)
                result.update(status='PASS',rom_bytes=len(binary),binary_sha256=sha(out/'main.bin'),cycles=cycles,instructions=int(m[3]),checks=int(m[4]),two_t_samples=int(m[5]),clock_period_ns=10)
                # Confirm configured GTKWave signal names exist in the VCD header.
                header=(out/'wave.vcd').open(encoding='utf-8').read(12000).split('$enddefinitions')[0]
                for signal in ('clk','pc','rom_addr','rom_data','opcode','led'):
                    assert re.search(r'\$var\s+\w+\s+\d+\s+\S+\s+'+signal+r'\b',header),signal
            except Exception as error:
                result.update(status='FAIL',error=str(error));result_path.write_text(json.dumps(result,indent=2));raise
            result_path.write_text(json.dumps(result,indent=2))
        results.append(result)
        print(f'{example.name}: {result["status"]}, {result["rom_bytes"]} ROM bytes, {result["cycles"]} CLK, {result["checks"]} checks',flush=True)
        if args.open or args.waves_only:
            # Older Windows GTKWave misreads non-ASCII VCD comments.
            vcd=out/'wave.vcd'
            if not vcd.exists():raise RuntimeError(f'Missing waveform: {vcd}; run RUN.bat first')
            data=vcd.read_bytes()
            if data.startswith(b'$comment //AACHIP'):
                vcd.write_bytes(b'$comment //AACHIP TECHNOLOGY CO LTD;TAIWAN $end\n'+data.split(b'\n',1)[1])
                vcd.with_suffix('.vcd.txt').write_text('//AACHIP TECHNOLOGY CO LTD;TAIWAN 合合科技有限公司\n',encoding='utf-8')
            launch_log=out/'gtkwave.log'
            with launch_log.open('wb') as log:
                process=subprocess.Popen([gtkwave,str(vcd),str(out/'detail.gtkw')],cwd=str(Path(gtkwave).parent),stdout=log,stderr=subprocess.STDOUT)
                try:
                    code=process.wait(timeout=2)
                    if code:raise RuntimeError(f'GTKWave exited ({code}): '+launch_log.read_text(encoding='utf-8',errors='replace'))
                except subprocess.TimeoutExpired:pass
            print(f'GTKWave opened: {vcd}',flush=True)
    if args.lesson=='all' and not args.waves_only:(BUILD/'summary.json').write_text(json.dumps(results,indent=2))
if __name__=='__main__':
    try:main()
    except Exception as e:print(e,file=sys.stderr);sys.exit(1)

