"""Compile C and assemble 8051 code without loading the IDE or licensing engine."""
from pathlib import Path
import argparse,subprocess,sys
sys.dont_write_bytecode=True
from assembler8051 import write_outputs
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path);parser.add_argument('--mode',type=int,choices=(1,2,3),default=1)
    args=parser.parse_args();source=args.source.resolve()
    if source.suffix.lower()=='.c':
        compiler=Path(__file__).resolve().parent/'TeachingEngine/aot/Aachip.TeachingCompiler.exe'
        result=subprocess.run([str(compiler),str(source),str(source.with_suffix('.asm')),str(args.mode)])
        if result.returncode:return result.returncode
        source=source.with_suffix('.asm')
    elif source.suffix.lower()!='.asm':raise ValueError('Input must be .c or .asm')
    binary=write_outputs(source)
    print(f'PASS teaching 8051 assembler: {source.with_suffix(".bin")} ({len(binary)} bytes)')
    return 0
if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:print(e,file=sys.stderr);sys.exit(1)
