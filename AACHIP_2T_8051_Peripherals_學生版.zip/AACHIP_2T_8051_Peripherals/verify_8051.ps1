$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
 & python verify_teaching.py
 if($LASTEXITCODE -ne 0){throw 'Teaching-source verification failed'}
 & python tests/make_8051_firmware.py
 if($LASTEXITCODE -ne 0){throw 'Firmware generation failed'}
 $files=Get-Content files_8051.f
 foreach($file in $files) {
  $code=(Get-Content $file -Raw -Encoding utf8) -replace '(?m)//.*$',''
  if($code -match '(?i)\b\w*(debug|breakpoint|single_step|halt)\w*\b'){throw "Unexpected control in basic 8051: $file"}
 }
 foreach($pipeline in @(0,1)) {
  & cmd.exe /d /c "iverilog -g2012 -Wall -s tb_8051 -Ptb_8051.RAM_PIPELINED=$pipeline -o build/test_8051_$pipeline.vvp -c files_8051.f tests/tb_8051.v 2>&1" | Tee-Object "build/compile_8051_$pipeline.log"
  if($LASTEXITCODE -ne 0){throw "8051 compile failed (RAM_PIPELINED=$pipeline)"}
  & vvp "build/test_8051_$pipeline.vvp" | Tee-Object "build/simulation_8051_$pipeline.log"
  if($LASTEXITCODE -ne 0){throw "8051 simulation failed (RAM_PIPELINED=$pipeline)"}
 }
 Write-Output 'PASS: basic 8051 compilation list contains no debug/halt/step/breakpoint identifiers'
} finally {Pop-Location}
