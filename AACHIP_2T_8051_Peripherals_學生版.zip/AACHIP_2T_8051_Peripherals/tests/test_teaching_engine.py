"""Known-byte vectors for every defined base-8051 opcode, plus failure checks."""
import sys,unittest,tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from assembler8051 import Assembler,AssemblyError,write_outputs,BANNER

class EncodingTests(unittest.TestCase):
    def test_headers_preserve_rom_and_hex(self):
        with tempfile.TemporaryDirectory() as folder:
            asm=Path(folder)/'main.asm'
            asm.write_text(BANNER+'\nLJMP 0030h\n',encoding='utf-8')
            write_outputs(asm)
            self.assertEqual(asm.with_suffix('.bin').read_bytes(),bytes.fromhex('02 00 30'))
            for suffix in ('.Dis','.Lst','.LIS','.bin.txt','.hex.txt'):
                self.assertEqual(asm.with_suffix(suffix).read_text(encoding='utf-8').splitlines()[0],BANNER)
            for line in asm.with_suffix('.hex').read_text().splitlines():
                self.assertTrue(line.startswith(':'))
                self.assertEqual(sum(bytes.fromhex(line[1:]))%256,0)
    def test_all_255_defined_opcodes(self):
        vectors={}
        def add(op,text,*tail):vectors[op]=(text,bytes([op,*tail]))
        for op,text in {0:'NOP',3:'RR A',0x13:'RRC A',0x23:'RL A',0x33:'RLC A',0x22:'RET',0x32:'RETI',0x73:'JMP @A+DPTR',0x83:'MOVC A,@A+PC',0x93:'MOVC A,@A+DPTR',0xa3:'INC DPTR',0xa4:'MUL AB',0x84:'DIV AB',0xc3:'CLR C',0xd3:'SETB C',0xb3:'CPL C',0xc4:'SWAP A',0xd4:'DA A',0xe4:'CLR A',0xf4:'CPL A',0xe0:'MOVX A,@DPTR',0xf0:'MOVX @DPTR,A'}.items():add(op,text)
        for op in range(1,256,0x20):
            target=((op&0xe0)<<3)|0x34;add(op,f'AJMP {target}',0x34)
            add(op+0x10,f'ACALL {target}',0x34)
        for op,m in [(2,'LJMP'),(0x12,'LCALL')]:add(op,m+' 1234h',0x12,0x34)
        for op,m in [(0x10,'JBC'),(0x20,'JB'),(0x30,'JNB')]:add(op,m+' 20h,60h',0x20,0x5d)
        for op,m in [(0x40,'JC'),(0x50,'JNC'),(0x60,'JZ'),(0x70,'JNZ'),(0x80,'SJMP')]:add(op,m+' 60h',0x5e)
        for base,m in [(0,'INC'),(0x10,'DEC')]:
            add(base+4,m+' A');add(base+5,m+' 20h',0x20)
            for r in range(2):add(base+6+r,f'{m} @R{r}')
            for r in range(8):add(base+8+r,f'{m} R{r}')
        for base,m in [(0x20,'ADD'),(0x30,'ADDC'),(0x40,'ORL'),(0x50,'ANL'),(0x60,'XRL'),(0x90,'SUBB')]:
            add(base+4,f'{m} A,#34h',0x34);add(base+5,f'{m} A,20h',0x20)
            for r in range(2):add(base+6+r,f'{m} A,@R{r}')
            for r in range(8):add(base+8+r,f'{m} A,R{r}')
        for base,m in [(0x40,'ORL'),(0x50,'ANL'),(0x60,'XRL')]:
            add(base+2,f'{m} 20h,A',0x20);add(base+3,f'{m} 20h,#34h',0x20,0x34)
        for op,text in [(0x72,'ORL C,20h'),(0x82,'ANL C,20h'),(0xa0,'ORL C,/20h'),(0xb0,'ANL C,/20h'),(0x92,'MOV 20h,C'),(0xa2,'MOV C,20h'),(0xb2,'CPL 20h'),(0xc2,'CLR 20h'),(0xd2,'SETB 20h'),(0xc0,'PUSH 20h'),(0xd0,'POP 20h')]:add(op,text,0x20)
        add(0x74,'MOV A,#34h',0x34);add(0x75,'MOV 20h,#34h',0x20,0x34)
        add(0x85,'MOV 20h,21h',0x21,0x20);add(0x90,'MOV DPTR,#1234h',0x12,0x34)
        add(0xe5,'MOV A,20h',0x20);add(0xf5,'MOV 20h,A',0x20)
        for r in range(2):
            for op,text,tail in [(0x76,f'MOV @R{r},#34h',[0x34]),(0x86,f'MOV 20h,@R{r}',[0x20]),(0xa6,f'MOV @R{r},20h',[0x20]),(0xe6,f'MOV A,@R{r}',[]),(0xf6,f'MOV @R{r},A',[]),(0xc6,f'XCH A,@R{r}',[]),(0xd6,f'XCHD A,@R{r}',[]),(0xe2,f'MOVX A,@R{r}',[]),(0xf2,f'MOVX @R{r},A',[])]:add(op+r,text,*tail)
            add(0xb6+r,f'CJNE @R{r},#34h,60h',0x34,0x5d)
        for r in range(8):
            for op,text,tail in [(0x78,f'MOV R{r},#34h',[0x34]),(0x88,f'MOV 20h,R{r}',[0x20]),(0xa8,f'MOV R{r},20h',[0x20]),(0xe8,f'MOV A,R{r}',[]),(0xf8,f'MOV R{r},A',[]),(0xc8,f'XCH A,R{r}',[])]:add(op+r,text,*tail)
            add(0xb8+r,f'CJNE R{r},#34h,60h',0x34,0x5d);add(0xd8+r,f'DJNZ R{r},60h',0x5e)
        add(0xb4,'CJNE A,#34h,60h',0x34,0x5d);add(0xb5,'CJNE A,20h,60h',0x20,0x5d)
        add(0xc5,'XCH A,20h',0x20);add(0xd5,'DJNZ 20h,60h',0x20,0x5d)
        self.assertEqual(set(vectors),set(range(256))-{0xa5})
        for op,(text,expected) in vectors.items():
            with self.subTest(opcode=f'{op:02x}',text=text):self.assertEqual(Assembler().assemble(text)[0],expected)
    def test_labels_bits_literals_and_directives(self):
        self.assertEqual(Assembler().assemble("ORG 30h\nstart: MOV A,#'a'\nSETB P1.0\nSJMP start")[0][0x30:],bytes.fromhex('74 61 d2 90 80 fa'))
        self.assertEqual(Assembler().assemble("DB 'a;b',0\nDW 1234h")[0],b'a;b\x00\x12\x34')
        self.assertEqual(Assembler().assemble('MOV A,#-1\nCLR 20h.3')[0],bytes.fromhex('74 ff c2 03'))
    def test_reject_bad_inputs(self):
        for text in ['SJMP 1000h','MOV A,#256','MOV 256,A','LCALL 10000h','AJMP 800h','bad: NOP\nbad: NOP','ORG 0\nNOP\nORG 0\nNOP','LJMP missing','ORG 0ffffh\nMOV A,#0','ORG later\nlater: NOP','SETB 30h.0','MOV R8,A','MOV A,R8','MOV R0,R1']:
            with self.subTest(text=text):
                with self.assertRaises(AssemblyError):Assembler().assemble(text)
if __name__=='__main__':unittest.main()
