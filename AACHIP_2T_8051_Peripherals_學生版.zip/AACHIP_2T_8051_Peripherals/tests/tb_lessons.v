`timescale 1ns/1ps
// Shared executable lesson testbench. DUT is the unchanged real CPU/peripheral RTL.
module tb_lessons;
 reg clk=0; always #5 clk=~clk;
 reg rst_n=0;
 reg [7:0] rom[0:65535];
 wire [15:0] rom_addr,xaddr;
 wire [7:0] rom_data=rom[rom_addr];
 wire [23:0] image_reset_bytes={rom[0],rom[1],rom[2]};
 wire [15:0] image_reset_target={rom[1],rom[2]};
 wire [7:0] p0,p1,p2,p3,xdata;
 wire xwr,xrd;
 reg [7:0] external_p0=8'hff;
 wire [7:0] p0_pin=p0 & external_p0;
 aachip_8051_top #(.RAM_PIPELINED(0),.TIMER_CLK_DIV(12)) dut(
 .clk(clk),.rst_n(rst_n),.rom_addr(rom_addr),.rom_data(rom_data),
 .ext_ram_addr(xaddr),.ext_ram_wr_data(xdata),.ext_ram_rd_data(8'h00),.ext_ram_wr_en(xwr),.ext_ram_rd_en(xrd),
 .p0_in(p0_pin),.p1_in(p1),.p2_in(p2),.p3_in(p3),.p0_out(p0),.p1_out(p1),.p2_out(p2),.p3_out(p3));
 wire [15:0] pc=dut.pc;
 wire [7:0] opcode=dut.u_core.ucode_addr,acc=dut.acc,sp=dut.sp,psw=dut.psw;
 wire [4:0] state=dut.u_core.state;
 wire fetch=state==1;
 wire [7:0] ram_addr=dut.u_core.ram_addr,ram_wr_data=dut.u_core.ram_wr_data;
 wire ram_wr_en=dut.u_core.ram_wr_en,ram_rd_en=dut.u_core.ram_rd_en;
 wire [7:0] th0=dut.th0,tl0=dut.tl0,tcon=dut.tcon,tmod=dut.tmod;
 wire tr0=tcon[4],tf0=tcon[5];
 wire lcd_rs=p0[0],lcd_en=p0[1];
 wire [3:0] lcd_data=p2[7:4];
 wire switch_a_pressed=~p0_pin[6],switch_b_pressed=~p0_pin[7];
 wire button_pressed=~p0_pin[0];
 integer lesson=1,cycles=0,maxcycles=500000,previous_cycle=-1;
 integer last_instruction_clocks=0,two_t_samples=0,instructions=0;
 reg [7:0] previous_opcode;
 integer trace_file,edges=0,step=0,lcd_count=0,checks=0;
 reg old_led=1,old_en=1;
 reg [7:0] old_p2=8'hff;
 reg [7:0] sequence_bytes[0:7];
 reg [3:0] lcd_expected[0:15];
 string outdir,romfile;
 wire led=(lesson==1)?p2[0]:((lesson==2 || lesson==3)?p0[0]:(lesson==7 || lesson==8)?p1[7]:p1[0]);
 task passed;
 begin
  $display("PASS lesson=%0d cycles=%0d instructions=%0d checks=%0d 2T_samples=%0d",lesson,cycles,instructions,checks,two_t_samples);
  $fclose(trace_file);$finish;
 end
 endtask
 initial begin
  if(!$value$plusargs("outdir=%s",outdir))$fatal(1,"Need +outdir");
  if($value$plusargs("lesson=%d",lesson))begin end
  if($value$plusargs("maxcycles=%d",maxcycles))begin end
  romfile={outdir,"/rom.mem"};$readmemh(romfile,rom);
  $dumpfile({outdir,"/wave.vcd"});
  $dumpvars(0,clk,rst_n,fetch,pc,rom_addr,rom_data,image_reset_bytes,image_reset_target,opcode,state,acc,sp,psw,last_instruction_clocks,
   ram_addr,ram_wr_data,ram_wr_en,ram_rd_en,p0,p0_pin,p1,p2,p3,led,
   external_p0,switch_a_pressed,switch_b_pressed,button_pressed,
   th0,tl0,tcon,tmod,tr0,tf0,lcd_rs,lcd_en,lcd_data);
  trace_file=$fopen({outdir,"/fetch.csv"},"w");$fdisplay(trace_file,"cycle,pc,opcode,previous_clocks");
  sequence_bytes[0]=1;sequence_bytes[1]=3;sequence_bytes[2]=2;sequence_bytes[3]=6;
  sequence_bytes[4]=4;sequence_bytes[5]=12;sequence_bytes[6]=8;sequence_bytes[7]=9;
  lcd_expected[0]=3;lcd_expected[1]=3;lcd_expected[2]=3;lcd_expected[3]=2;
  lcd_expected[4]=2;lcd_expected[5]=8;lcd_expected[6]=0;lcd_expected[7]=12;
  lcd_expected[8]=0;lcd_expected[9]=6;lcd_expected[10]=0;lcd_expected[11]=1;
  lcd_expected[12]=8;lcd_expected[13]=0;lcd_expected[14]=5;lcd_expected[15]=3;
  repeat(5)@(negedge clk);rst_n=1;
 end
 always @(posedge clk)if(rst_n)begin
  cycles=cycles+1;
  if(fetch)begin
   if(previous_cycle>=0)begin
    last_instruction_clocks=cycles-previous_cycle;
    if(previous_opcode==0 || previous_opcode==8'he4 || previous_opcode==8'hc3)begin
     if(last_instruction_clocks!=2)$fatal(1,"2T failure");two_t_samples=two_t_samples+1;
    end
   end
   if(instructions==0 && pc!==0)$fatal(1,"Reset PC");
   if(instructions==1)begin
    if(pc!=={rom[1],rom[2]})$fatal(1,"Reset LJMP target mismatch, got %h",pc);
    $display("RESET: 0000 -> %h; ROM=%h %h %h",pc,rom[0],rom[1],rom[2]);
   end
   $fdisplay(trace_file,"%0d,%04h,%02h,%0d",cycles,pc,rom_data,last_instruction_clocks);
   previous_cycle=cycles;previous_opcode=rom_data;instructions=instructions+1;
  end
 end
 always @(negedge clk)if(rst_n)begin
  if(cycles>=maxcycles)$fatal(1,"Timeout lesson=%0d PC=%h checks=%0d",lesson,pc,checks);
  if(lesson==1 || lesson==2 || lesson==3 || lesson==9)begin
   if(led!==old_led)begin
    if(led!==0 && led!==1)$fatal(1,"LED unknown");
    edges=edges+1;old_led=led;checks=checks+1;
    $display("LED edge=%0d cycle=%0d value=%b time=%0t",edges,cycles,led,$time);
    if(edges==3)passed;
   end
  end
  if(lesson==4 && p2!==old_p2)begin
   old_p2=p2;
   if(p2!==sequence_bytes[step%8])$fatal(1,"Motor phase step=%0d got=%h",step,p2);
   step=step+1;checks=checks+1;$display("MOTOR step=%0d value=%h cycle=%0d",step,p2,cycles);
   if(step==9)passed;
  end
  if(lesson==5)begin
   if(old_en && !lcd_en)begin
    if(lcd_count>0 || lcd_data==3)begin
     if(lcd_data!==lcd_expected[lcd_count] || lcd_rs!==(lcd_count>=14))$fatal(1,"LCD nibble %0d: RS=%b data=%h",lcd_count,lcd_rs,lcd_data);
     $display("LCD nibble=%0d RS=%b data=%h cycle=%0d",lcd_count,lcd_rs,lcd_data,cycles);
     lcd_count=lcd_count+1;checks=checks+1;
     if(lcd_count==16)passed;
    end
   end
   old_en=lcd_en;
  end
 end
 // Allow many instruction loops to settle after each physical input change.
 task check_input;
 input [7:0] pins;
 input expected;
 begin
  @(negedge clk);external_p0=pins;
  repeat(2000)@(negedge clk);
  if(led!==expected)$fatal(1,"Input truth table pins=%h expected=%b got=%b",pins,expected,led);
  checks=checks+1;$display("INPUT pins=%h LED=%b cycle=%0d",pins,led,cycles);
 end
 endtask
 initial begin
  wait(rst_n);repeat(1000)@(negedge clk);
  if(lesson==6)begin
   check_input(8'hff,1);check_input(8'hfe,0);check_input(8'hff,1);passed;
  end
  if(lesson==7 || lesson==8)begin
   check_input(8'hff,1);
   check_input(8'hbf,lesson==8);check_input(8'h7f,lesson==8);
   check_input(8'h3f,0);check_input(8'hff,1);passed;
  end
 end
endmodule
