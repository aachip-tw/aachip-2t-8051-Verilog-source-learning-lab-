`timescale 1ns/1ps
module tb_8051;
 parameter RAM_PIPELINED=0;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0;
 reg [7:0] rom[0:2047],xram[0:65535];
 wire [15:0] rom_addr,xaddr;
 wire [7:0] xdata,p0,p1,p2,p3;
 wire xwr,xrd;
 reg int0=1,int1=1;
 wire [7:0] p3_in={4'b1111,int1,int0,1'b1,p3[1]};
 integer i;
 aachip_8051_top #(.RAM_PIPELINED(RAM_PIPELINED),.TIMER_CLK_DIV(12)) dut(
  .clk(clk),.rst_n(rst_n),.rom_addr(rom_addr),.rom_data(rom[rom_addr[10:0]]),
  .ext_ram_addr(xaddr),.ext_ram_wr_data(xdata),.ext_ram_rd_data(xram[xaddr]),
  .ext_ram_wr_en(xwr),.ext_ram_rd_en(xrd),
  .p0_in(8'h5a),.p1_in(p1),.p2_in(p2),.p3_in(p3_in),
  .p0_out(p0),.p1_out(p1),.p2_out(p2),.p3_out(p3));
 always @(posedge clk) if(xwr && rst_n)xram[xaddr]<=xdata;
 always @(negedge clk) if(rst_n && $test$plusargs("trace") && dut.u_core.state==1)
  $display("PC=%h OP=%h A=%h B=%h PSW=%h SP=%h",dut.pc,rom[dut.pc[10:0]],dut.acc,dut.b,dut.psw,dut.sp);
 initial begin
  for(i=0;i<65536;i=i+1)xram[i]=0;
  $readmemh("tests/8051_selftest.hex",rom);
  repeat(5)@(negedge clk);rst_n=1;
 end
 initial begin
  wait(rst_n);wait(p1===8'h55);
  @(negedge clk);int0=0;
  repeat(3)@(negedge clk);int0=1;
  wait(p1===8'ha0);
  @(negedge clk);int1=0;
  repeat(3)@(negedge clk);int1=1;
 end
 initial begin
  wait(rst_n);
  forever begin
   @(negedge clk);
   if(p2===8'hee)$fatal(1,"firmware assertion failed pc=%h A=%h PSW=%h",dut.pc,dut.acc,dut.psw);
   if(p2===8'ha5)begin
    if(p0!==8'h05)$fatal(1,"GPIO RMW got %h",p0);
    if(xram[16'h1234]!==8'h69 || xram[16'h1235]!==8'h96)$fatal(1,"MOVX address/data");
    if(dut.u_iram.g_sim.mem[8'h60]!==1 || dut.u_iram.g_sim.mem[8'h61]!==1 || dut.u_iram.g_sim.mem[8'h62]!==1 || dut.u_iram.g_sim.mem[8'h63]!==1 || dut.u_iram.g_sim.mem[8'h64]!==1)$fatal(1,"IRQ counters");
    if(dut.sp!==8'h6f || dut.active_high || dut.active_low)$fatal(1,"RETI nesting/stack");
    $display("PASS: classic 8051 RAM_PIPELINED=%0d: arithmetic/flags, RAM/register banks, bits, stack/call/ret, MOVC/MOVX, GPIO/RMW, UART loopback, all five interrupt vectors, nested INT0/INT1, RETI",RAM_PIPELINED);
    $finish;
   end
  end
 end
 initial begin #2000000;$fatal(1,"timeout pc=%h A=%h p1=%h p2=%h SCON=%h",dut.pc,dut.acc,p1,p2,dut.scon);end
endmodule
