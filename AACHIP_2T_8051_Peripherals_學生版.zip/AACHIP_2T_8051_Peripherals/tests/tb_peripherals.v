`timescale 1ns/1ps
module tb_peripherals;
 reg clk=0; always #5 clk=~clk;
 reg rst_n=0,run_enable=1;
 reg [7:0] addr=0,data=0,p3=8'hff;
 reg wr=0,rmw=0;
 wire [7:0] rd,p0_out,p0_oe;
 wire [12:0] pending;
 integer k;
 reg [10:0] frame;
 aachip_8051_peripherals #(.SERIAL_MODE2_BAUD_DIV(8)) dut(
  .clk(clk),.rst_n(rst_n),.run_enable(run_enable),
  .sfr_addr(addr),.sfr_wdata(data),.sfr_we(wr),.sfr_rmw(rmw),.sfr_rdata(rd),
  .irq_ack(1'b0),.irq_ack_source(4'd0),.irq_pending(pending),
  .p0_in(8'h5a),.p1_in(8'hff),.p2_in(8'hff),.p3_in(p3),
  .p0_out(p0_out),.p0_oe(p0_oe),
  .int0_n(1'b1),.int1_n(1'b1),.t0_pin(1'b1),.t1_pin(1'b1),
  .adc_miso(1'b1),.export_a_in(8'h00),.export_b_in(8'h00),
  .export_c_in(8'h00),.export_d_in(8'h00));
 task write_sfr;input [7:0] a,d;begin
  @(negedge clk);addr=a;data=d;wr=1;
  @(negedge clk);wr=0;
 end endtask
 task expect_sfr;input [7:0] a,d,mask;begin
  @(negedge clk);addr=a;#1;
  if((rd&mask)!==(d&mask))$fatal(1,"SFR %h got %h expected %h mask %h",a,rd,d,mask);
 end endtask
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  expect_sfr(8'h88,0,8'hff);
  write_sfr(8'h80,8'ha5);
  expect_sfr(8'h80,8'h5a,8'hff);
  rmw=1;expect_sfr(8'h80,8'ha5,8'hff);rmw=0;
  if(p0_oe!==8'h5a)$fatal(1,"quasi OE");
  write_sfr(8'he2,8'hff);
  if(p0_oe!==8'hff)$fatal(1,"push pull OE");
  write_sfr(8'he1,8'hff);write_sfr(8'he2,0);
  if(p0_oe!==0)$fatal(1,"input OE");
  // Timer 0 16-bit overflow and sticky flag.
  write_sfr(8'h89,8'h01);write_sfr(8'h8a,8'hfe);write_sfr(8'h8c,8'hff);
  write_sfr(8'ha8,8'h82);write_sfr(8'h88,8'h10);
  repeat(6)@(negedge clk);
  expect_sfr(8'h88,8'h20,8'h20);
  if(!pending[1])$fatal(1,"Timer0 IRQ");
  write_sfr(8'h88,0);
  // Counter path: no tick counts without a falling edge.
  write_sfr(8'h89,8'h05);write_sfr(8'h8a,0);write_sfr(8'h8c,0);
  write_sfr(8'h88,8'h10);repeat(4)@(negedge clk);
  expect_sfr(8'h8a,0,8'hff);
  @(negedge clk);p3[4]=0;repeat(3)@(negedge clk);
  expect_sfr(8'h8a,1,8'hff);
  write_sfr(8'h88,0);p3=8'hff;
  // Timer 2 reload/flag.
  write_sfr(8'hca,8'hfc);write_sfr(8'hcb,8'hff);
  write_sfr(8'hcc,8'hfe);write_sfr(8'hcd,8'hff);write_sfr(8'hc8,8'h04);
  repeat(8)@(negedge clk);expect_sfr(8'hc8,8'h80,8'h80);
  write_sfr(8'hc8,0);
  // UART mode 2: verify serialized frame at every baud enable.
  write_sfr(8'h98,8'h80);
  write_sfr(8'h99,8'ha5);
  wait(dut.serial_tx_busy);#1;
  frame={1'b1,1'b0,8'ha5,1'b0};
  if(dut.serial_txd_pin!==0)$fatal(1,"UART start");
  for(k=0;k<10;k=k+1)begin
   @(negedge clk);
   while(!dut.u_serial.fixed_baud_tick)@(negedge clk);
   @(posedge clk);#1;
   if(dut.serial_txd_pin!==frame[k+1])$fatal(1,"UART frame bit %0d",k+1);
  end
  wait(!dut.serial_tx_busy);
  repeat(3)@(negedge clk);expect_sfr(8'h98,8'h02,8'h02);
  // Export direction and readback.
  write_sfr(8'hfa,8'h0f);write_sfr(8'hfb,8'ha5);
  expect_sfr(8'hfb,8'h05,8'hff);
  $display("PASS: reset, GPIO pin/RMW/OE, Timer0 overflow/IRQ, external counter, Timer2, UART TX completion, export IO");
  $finish;
 end
 initial begin #100000;$fatal(1,"timeout");end
endmodule
