@echo off
setlocal
cd /d "%~dp0"
:menu
echo.
echo AACHIP 8051 - C / ASM / RTL / GTKWave
echo 0. Check tools
echo 1. Build and simulate all 9 lessons
echo 2. Open all existing waves
echo 3. Build, simulate and open one lesson
echo 4. Synthesize 8051 RTL with Yosys
echo 5. Verify core and peripherals
echo Q. Quit
choice /c 012345Q /n /m "Select: "
if errorlevel 7 exit /b 0
if errorlevel 6 (call 05_VERIFY_RTL.bat& goto menu)
if errorlevel 5 (call 04_SYNTHESIZE.bat& goto menu)
if errorlevel 4 (call 03_RUN_ONE.bat& goto menu)
if errorlevel 3 (call 02_OPEN_ALL_WAVES.bat& goto menu)
if errorlevel 2 (call 01_BUILD_SIM_ALL.bat& goto menu)
call 00_CHECK_TOOLS.bat
goto menu
