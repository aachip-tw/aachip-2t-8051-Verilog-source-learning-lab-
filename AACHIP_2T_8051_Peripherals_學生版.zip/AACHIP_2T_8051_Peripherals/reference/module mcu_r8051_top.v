`timescale 1ns / 1ps

// ============================================================================
// Module Name : mcu_r8051_top
// Description : Top-Level Wrapper integrating Fetch/Decode, Microcode ROM,
//               ALU, Independent SFR Bank, and Internal Data RAM.
// ============================================================================

module mcu_r8051_top #(
    // Number of clk cycles per timer machine-cycle increment.  Use 12 for a
    // classic 12T oscillator interface, or 1 when clk already is the CPU tick.
    parameter integer EMULATOR = 0,
    parameter integer MOVX_RI_PAGED = 0,
    parameter integer TIMER_CLK_DIV = 1,
    parameter integer SERIAL_VARIABLE_BAUD_DIV = 32,
    parameter integer SERIAL_MODE2_BAUD_DIV = 64,
    parameter integer SERIAL_MODE0_BAUD_DIV = 1
) (
    input  wire        clk,
    input  wire        rst_n,
    input wire adc_miso,
    output wire adc_sclk,adc_mosi,adc_cs_n,
    output wire program_write_enable,

    // ------------------------------------------------------------------------
    // Program Memory (ROM) 介面
    // ------------------------------------------------------------------------
    output wire [15:0] rom_addr,
    output wire [7:0] p0_oe, p1_oe, p2_oe, p3_oe,
    input  wire [7:0]  rom_data,

    // ------------------------------------------------------------------------
    // External Data RAM (MOVX) 介面
    // ------------------------------------------------------------------------
    output wire [15:0] ext_ram_addr,
    output wire [7:0]  ext_ram_wr_data,
    input  wire [7:0]  ext_ram_rd_data,
    output wire        ext_ram_wr_en,
    output wire        ext_ram_rd_en,

    // ------------------------------------------------------------------------
    // GPIO Parallel Ports (P0 ~ P3)
    // ------------------------------------------------------------------------
    input  wire [7:0]  p0_in,  output wire [7:0] p0_out,
    input  wire [7:0]  p1_in,  output wire [7:0] p1_out,
    input  wire [7:0]  p2_in,  output wire [7:0] p2_out,
    input  wire [7:0]  p3_in,  output wire [7:0] p3_out,
    input  wire        int0_n,
    input  wire        int1_n,
    input  wire        t0_pin,
    input  wire        t1_pin,
    input  wire        timer0_overflow,
    input  wire        timer1_overflow,
    input  wire        serial_rx_irq,
    input  wire        serial_tx_irq,

    // ------------------------------------------------------------------------
    // 狀態與 Debug 監控輸出
    // ------------------------------------------------------------------------
    output wire [15:0] pc_out,
    output wire [7:0]  acc_out,
    output wire [7:0]  b_out,
    output wire [7:0]  psw_out,
    output wire [7:0]  sp_out,
	output wire [7:0]  dpl_out, // 新增 DPL 輸出
    output wire [7:0]  dph_out, // 新增 DPH 輸出
    output wire [15:0] dptr_out,
    output wire        reti_complete,

    // SPI/IDE debug port.  Requests are accepted while debug_halt is asserted.
    input  wire        debug_halt,
    output wire debug_stopped,
    output wire debug_instruction_boundary,
    output wire debug_instruction_active,
    input  wire [7:0]  debug_addr,
    input  wire [7:0]  debug_wr_data,
    input  wire        debug_iram_wr,
    input  wire        debug_sfr_wr,
    output wire [7:0]  debug_iram_rd_data,
    output wire [7:0]  debug_sfr_rd_data
);

    // ------------------------------------------------------------------------
    // 內部匯流排與連線訊號
    // ------------------------------------------------------------------------
    wire [7:0] mem_addr;
    wire [7:0] mem_wr_data;
    wire [7:0] mem_rd_data;
    wire       mem_wr_en;
    wire       mem_rd_en;
    wire       ram_cs;
    wire       mem_rmw;
    wire       mem_indirect;

    wire       core_acc_we;
    wire [7:0] core_acc_data;
    wire       core_b_we;
    wire [7:0] core_b_data;
    wire       core_sp_we;
    wire [7:0] core_sp_data;
    wire       core_psw_we;
    wire [7:0] core_psw_data;

	wire 		core_dptr_we;
    wire [15:0] core_dptr_data;


    wire selected_dptr;
    wire [15:0] dp0_value,dp1_value;
    wire [7:0] sfr_rd_data,base_sfr_rd_data,extended_sfr_data;
    wire extended_sfr_select;
    wire [7:0] ckcon,spc_fnc,mpage,eie,exif,eicon;
    wire timer2_irq,serial1_irq,uart1_txd,uart1_rxd_out,uart1_rxd_oe;
    wire t2_output_enable,t2_out,t2_rx_tick,t2_tx_tick,t2_rx_select,t2_tx_select;
    assign program_write_enable=spc_fnc[0];
    assign sfr_rd_data=extended_sfr_select?extended_sfr_data:base_sfr_rd_data;
    wire [7:0] iram_rd_data;
    wire debug_writeback_idle;
    wire debug_halt_request = (debug_halt === 1'b1);
    // A request waits until the current instruction and its delayed stores commit.
    wire debug_halt_active = debug_halt_request &&
        debug_instruction_boundary && debug_writeback_idle;
    assign debug_stopped = debug_halt_active && debug_halt_latched;
    reg  debug_halt_latched;
    always @(negedge clk or negedge rst_n) begin
        if (!rst_n) debug_halt_latched <= 1'b0;
        else debug_halt_latched <= debug_halt_active;
    end
    // Keep the design on one physical clock tree.  CPU halt uses clock
    // enables, avoiding skew from a combinationally gated global clock.
    wire peripheral_enable=~debug_halt_latched;
    reg [2:0] movx_wait_count;
    reg movx_wait_serviced;
    wire movx_active=ext_ram_wr_en||ext_ram_rd_en;
    wire movx_wait_start=movx_active&&!movx_wait_serviced&&(ckcon[2:0]!=0);
    wire core_enable=peripheral_enable&&!movx_wait_start&&(movx_wait_count==0);
    always @(posedge clk or negedge rst_n) begin
      if(!rst_n)begin movx_wait_count<=0;movx_wait_serviced<=0;end
      else if(peripheral_enable)begin
       if(movx_wait_start)begin
        movx_wait_count<=ckcon[2:0]-3'd1;movx_wait_serviced<=1;
       end else if(movx_wait_count!=0)movx_wait_count<=movx_wait_count-3'd1;
       else if(core_enable)movx_wait_serviced<=0;
      end
    end
    wire [7:0] debug_bus_addr = debug_addr;
    wire [7:0] sfr_bus_addr = debug_halt_active ? debug_bus_addr : mem_addr;
    wire [7:0] sfr_bus_wr_data = debug_halt_active ? debug_wr_data : mem_wr_data;
    wire sfr_bus_wr_en = debug_halt_active ? (debug_sfr_wr === 1'b1) :
                                            (mem_wr_en && sel_sfr);
    assign debug_iram_rd_data = iram_rd_data;
    assign debug_sfr_rd_data = sfr_rd_data;
    wire [7:0] ie, ip, tcon, tmod, scon, pcon;
    wire [7:0] tl0, th0, tl1, th1;
    wire [7:0] gpio_read_data, serial_sbuf;
    wire effective_int0_n, effective_int1_n, effective_t0, effective_t1;
    wire serial_rxd_pin, serial_txd_pin, serial_rxd_out, serial_rxd_oe;
    wire serial_ri_set, serial_ti_set, serial_rb8_write, serial_rb8_data;
    wire serial_tx_busy, serial_rx_busy;
    wire timer0_internal_overflow, timer1_internal_overflow;
    wire timer0_split_overflow;
    wire timer0_event = timer0_internal_overflow |
                        (timer0_overflow === 1'b1);
    wire timer1_event = ((tmod[1:0] == 2'b11) ? timer0_split_overflow :
                                                       timer1_internal_overflow) |
                        (timer1_overflow === 1'b1);

    localparam integer TIMER_DIV_WIDTH = (TIMER_CLK_DIV <= 1) ? 1 : $clog2(TIMER_CLK_DIV);
    reg [TIMER_DIV_WIDTH-1:0] timer_div_count;
    wire timer_tick = (TIMER_CLK_DIV <= 1) ? 1'b1 :
                      (timer_div_count == TIMER_CLK_DIV - 1);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) timer_div_count <= {TIMER_DIV_WIDTH{1'b0}};
        else if (core_enable) begin
            if (timer_tick) timer_div_count <= {TIMER_DIV_WIDTH{1'b0}};
            else timer_div_count <= timer_div_count + 1'b1;
        end
    end
    wire core_irq_ack, core_irq_priority;
    wire [3:0] core_irq_source;
    reg active_irq_low, active_irq_high;
    reg irq_valid, irq_priority;
    reg [3:0] irq_source;
    reg [15:0] irq_vector;

    wire [12:0] irq_request = {
      eicon[3]&eicon[0], exif[7]&eie[7],exif[6]&eie[6],
      exif[5]&eie[5],exif[4]&eie[4],serial1_irq&ie[6],eicon[4]&eicon[5],
      timer2_irq&ie[5],(scon[0]|scon[1])&ie[4],
      tcon[7]&ie[3],tcon[3]&ie[2],tcon[5]&ie[1],tcon[1]&ie[0]};
    wire [12:0] irq_prios={eicon[1],eie[3:0],ip[6],1'b1,ip[5:0]};
    wire [12:0] irq_high=irq_request&irq_prios;
    wire [12:0] irq_low=irq_request&~irq_prios;
    wire effective_active_high=active_irq_high&&!reti_complete;
    wire effective_active_low=active_irq_low&&!(reti_complete&&!active_irq_high);
    task select_irq;
      input [12:0] requests;
      input selected_priority;
      begin
       irq_priority=selected_priority;
       if(requests[0])irq_source=0;
       else if(requests[1])irq_source=1;
       else if(requests[2])irq_source=2;
       else if(requests[3])irq_source=3;
       else if(requests[4])irq_source=4;
       else if(requests[5])irq_source=5;
       else if(requests[7])irq_source=7;
       else if(requests[8])irq_source=8;
       else if(requests[9])irq_source=9;
       else if(requests[10])irq_source=10;
       else if(requests[11])irq_source=11;
       else if(requests[6])irq_source=6;
       else irq_source=12;
       irq_vector={9'b0,irq_source,3'b011};
      end
    endtask

    always @(*) begin
        irq_valid = 1'b0;
        irq_priority = 1'b0;
        irq_source = 3'd0;
        irq_vector = 16'd0;
        if (!core_irq_ack && ie[7] && !effective_active_high) begin
            if (|irq_high) begin
                irq_valid = 1'b1;
                select_irq(irq_high, 1'b1);
            end else if (!effective_active_low && |irq_low) begin
                irq_valid = 1'b1;
                select_irq(irq_low, 1'b0);
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active_irq_low <= 1'b0;
            active_irq_high <= 1'b0;
        end else if (core_enable) begin
            if (reti_complete) begin
                if (active_irq_high) active_irq_high <= 1'b0;
                else active_irq_low <= 1'b0;
            end
            if (core_irq_ack) begin
                if (core_irq_priority) active_irq_high <= 1'b1;
                else active_irq_low <= 1'b1;
            end
        end
    end

    // ------------------------------------------------------------------------
    // 1. 256-byte IRAM. Upper half is indirect/stack only; direct
    //    addresses 80h-FFh still select SFRs.
    // ------------------------------------------------------------------------
    wire sel_iram = !mem_addr[7] || mem_indirect;
    wire sel_sfr = !sel_iram;
    wire [7:0] iram_addr = debug_halt_active ? debug_bus_addr : mem_addr;
    wire iram_wr = rst_n && (debug_halt_active ? (debug_iram_wr === 1'b1) :
                                                      (mem_wr_en && sel_iram));
    mcu8051_memory #(.EMULATOR(EMULATOR), .PIPELINED_READ(EMULATOR)) u_iram (
        .clk(clk), .rd_addr(iram_addr), .rd_data(iram_rd_data),
        .wr_en(iram_wr), .wr_addr(iram_addr),
        .wr_data(debug_halt_active ? debug_wr_data : mem_wr_data)
    );

    // 讀取多路複用器 (RAM vs SFR)
    assign mem_rd_data = sel_iram ? iram_rd_data : sfr_rd_data;

    wire timer_write = sfr_bus_wr_en;

    mcu8051_gpio #(.EXTENDED(1)) u_gpio (
        .clk(clk), .rst_n(rst_n), .sfr_addr(sfr_bus_addr),
        .sfr_write_data(sfr_bus_wr_data), .sfr_write_enable(timer_write),
        .sfr_rmw(mem_rmw), .p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
        .p0_in(p0_in), .p1_in(p1_in),
        .p2_in(p2_in), .p3_in(p3_in), .ext_int0_n(int0_n),
        .ext_int1_n(int1_n), .ext_t0(t0_pin), .ext_t1(t1_pin),
        .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
        .t2_output_enable(t2_output_enable),.t2_out(t2_out),
        .serial_txd(serial_txd_pin), .serial_rxd_out(serial_rxd_out),
        .serial_rxd_oe(serial_rxd_oe), .p0_out(p0_out), .p1_out(p1_out),
        .p2_out(p2_out), .p3_out(p3_out), .port_read_data(gpio_read_data),
        .int0_n(effective_int0_n), .int1_n(effective_int1_n),
        .t0_pin(effective_t0), .t1_pin(effective_t1), .serial_rxd(serial_rxd_pin)
    );

    mcu8051_timer0 u_timer0 (
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[3]?peripheral_enable:timer_tick & peripheral_enable)),
        .t0_pin(effective_t0), .int0_n(effective_int0_n), .tmod(tmod[3:0]),
        .tr0(tcon[4]), .tr1(tcon[6]),
        .write_tl(timer_write && sfr_bus_addr == 8'h8A),
        .write_th(timer_write && sfr_bus_addr == 8'h8C), .write_data(sfr_bus_wr_data),
        .tl0(tl0), .th0(th0), .overflow0(timer0_internal_overflow),
        .overflow1_split(timer0_split_overflow)
    );

    mcu8051_timer1 u_timer1 (
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[4]?peripheral_enable:timer_tick & peripheral_enable)),
        .t1_pin(effective_t1), .int1_n(effective_int1_n), .tmod(tmod[7:4]),
        .tr1(tcon[6]), .timer0_split_mode(tmod[1:0] == 2'b11),
        .write_tl(timer_write && sfr_bus_addr == 8'h8B),
        .write_th(timer_write && sfr_bus_addr == 8'h8D), .write_data(sfr_bus_wr_data),
        .tl1(tl1), .th1(th1), .overflow1(timer1_internal_overflow)
    );

    mcu8051_serial #(
        .SEPARATE_BAUD(1),
        .VARIABLE_BAUD_DIV(SERIAL_VARIABLE_BAUD_DIV),
        .MODE2_BAUD_DIV(SERIAL_MODE2_BAUD_DIV),
        .MODE0_BAUD_DIV(SERIAL_MODE0_BAUD_DIV)
    ) u_serial (
        .clk(clk), .rst_n(rst_n), .clock_enable(peripheral_enable),
        .scon(scon), .smod(pcon[7]),
        .timer1_overflow(timer1_internal_overflow),
        .rx_baud_overflow(t2_rx_select?t2_rx_tick:timer1_internal_overflow),
        .tx_baud_overflow(t2_tx_select?t2_tx_tick:timer1_internal_overflow),
        .rx_use_timer2(t2_rx_select),.tx_use_timer2(t2_tx_select),.rxd(serial_rxd_pin),
        .sbuf_write(timer_write && sfr_bus_addr == 8'h99),
        .sbuf_write_data(sfr_bus_wr_data), .sbuf_read_data(serial_sbuf),
        .txd(serial_txd_pin), .rxd_out(serial_rxd_out),
        .rxd_output_enable(serial_rxd_oe), .ri_set(serial_ri_set),
        .ti_set(serial_ti_set), .rb8_write(serial_rb8_write),
        .rb8_data(serial_rb8_data), .tx_busy(serial_tx_busy), .rx_busy(serial_rx_busy)
    );

    // ------------------------------------------------------------------------
    // 2. 實例化獨立 SFR 暫存器庫 (mcu8051_sfr_bank)
    // ------------------------------------------------------------------------
    mcu8051_sfr_bank u_sfr_bank (
        .clk           (clk),
        .rst_n         (rst_n),
		
        // 指令總線存取介面
        .sfr_addr      (sfr_bus_addr),
        .sfr_wr_data   (sfr_bus_wr_data),
        .sfr_rd_data   (base_sfr_rd_data),
        .sfr_wr_en     (sfr_bus_wr_en),
        .sfr_rmw       (mem_rmw),
        .int0_n        (effective_int0_n), .int1_n(effective_int1_n),
        .timer0_overflow(timer0_event), .timer1_overflow(timer1_event),
        .timer0_tl(tl0), .timer0_th(th0),
        .timer1_tl(tl1), .timer1_th(th1),
        .serial_rx_irq (serial_ri_set | (serial_rx_irq === 1'b1)),
        .serial_tx_irq (serial_ti_set | (serial_tx_irq === 1'b1)),
        .serial_sbuf(serial_sbuf), .serial_rb8_write(serial_rb8_write),
        .serial_rb8_data(serial_rb8_data),
        .irq_ack       (core_irq_ack), .irq_ack_source(core_irq_source),

        // ALU 硬體強制寫入介面
        .core_psw_we   (core_psw_we),
        .core_psw_data (core_psw_data),
        .core_acc_we   (core_acc_we),
        .core_acc_data (core_acc_data),
        .core_b_we     (core_b_we),
        .core_b_data   (core_b_data),
        .core_sp_we    (core_sp_we),
        .core_sp_data  (core_sp_data),

		.core_dptr_we(core_dptr_we),
		.core_dptr_data (core_dptr_data),


        // Core 暫存器輸出
        .acc           (acc_out),
        .b             (b_out),
        .psw           (psw_out),
        .sp            (sp_out),
        .dpl           (dpl_out),
        .dph           (dph_out),
        .dptr          (dptr_out),.dps_out(selected_dptr),.dp0_value(dp0_value),.dp1_value(dp1_value),
        .ie             (ie), .ip(ip), .tcon(tcon), .tmod(tmod), .scon(scon),
        .pcon           (pcon),

        // GPIO readback is supplied by the independent port block.
        .port_read_data(gpio_read_data)
    );

    // ------------------------------------------------------------------------
    // 3. 實例化 CPU Fetch/Decode/Execution 控制核心
    // ------------------------------------------------------------------------
    mcu8051_fetch_decode #(.RAM_PIPELINED(EMULATOR), .MOVX_RI_PAGED(1)) u_fetch_decode (
        .clk             (clk),
        .rst_n           (rst_n),
        .clock_enable    (core_enable),
        .debug_pause_request(debug_halt_request),
        .debug_instruction_boundary(debug_instruction_boundary),
        .debug_writeback_idle(debug_writeback_idle),
        .debug_instruction_active(debug_instruction_active),

        // ROM
        .rom_addr        (rom_addr),
        .rom_data        (rom_data),

		.pc              (pc_out),
        // RAM / SFR Bus
        .ram_addr        (mem_addr),
        .ram_wr_data     (mem_wr_data),
        .ram_rd_data     (mem_rd_data),
        .ram_wr_en       (mem_wr_en),
		.ram_rd_en       (mem_rd_en),
		.ram_rmw         (mem_rmw),
        .ram_indirect    (mem_indirect),
		.ram_cs          (ram_cs),
        // External RAM
        .movx_page(mpage),
        .ext_ram_addr    (ext_ram_addr),
        .ext_ram_wr_data (ext_ram_wr_data),
        .ext_ram_rd_data (ext_ram_rd_data),
        .ext_ram_wr_en   (ext_ram_wr_en),
        .ext_ram_rd_en   (ext_ram_rd_en),

        // 硬體更新 SFR 介面
        .core_acc_we     (core_acc_we),
        .core_acc_data   (core_acc_data),
        .core_b_we       (core_b_we),
        .core_b_data     (core_b_data),
        .core_sp_we      (core_sp_we),
        .core_sp_data    (core_sp_data),
        .core_psw_we     (core_psw_we),
        .core_psw_data   (core_psw_data),
		.core_dptr_we     (core_dptr_we),
        .core_dptr_data   (core_dptr_data),
        // Status
       
        .acc_in          (acc_out),
        .b_in            (b_out),
        .psw_in          (psw_out),
        .sp_in           (sp_out),
        .dptr_in         (dptr_out),
        .irq_valid       (irq_valid), .irq_vector(irq_vector),
        .irq_priority    (irq_priority), .irq_source(irq_source),
        .irq_ack         (core_irq_ack), .irq_ack_priority(core_irq_priority),
        .irq_ack_source  (core_irq_source),
        .reti_complete   (reti_complete)
    );


    mcu8051_extended u_extended (
     .clk(clk),.rst_n(rst_n),.run_enable(peripheral_enable),.timer_tick(timer_tick),
     .addr(sfr_bus_addr),.wdata(sfr_bus_wr_data),.wr(sfr_bus_wr_en),
     .rdata(extended_sfr_data),.selected(extended_sfr_select),.p1(p1_in),
     .timer1_overflow(timer1_internal_overflow),.ie(ie),
     .ckcon(ckcon),.spc_fnc(spc_fnc),.mpage(mpage),.eie(eie),.exif(exif),.eicon(eicon),
     .timer2_irq(timer2_irq),.serial1_irq(serial1_irq),
     .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
     .t2_out(t2_out),.t2_output_enable(t2_output_enable),
     .uart0_rx_tick(t2_rx_tick),.uart0_tx_tick(t2_tx_tick),
     .uart0_use_rx_t2(t2_rx_select),.uart0_use_tx_t2(t2_tx_select),
     .adc_miso(adc_miso),.adc_sclk(adc_sclk),.adc_mosi(adc_mosi),.adc_cs_n(adc_cs_n),
     .export_a(),.export_b(),.export_c(),.export_d(),
     .export_b_oe(),.export_c_oe(),.export_d_oe(),
     .export_a_in(8'h00),.export_b_in(8'h00),.export_c_in(8'h00),.export_d_in(8'h00)
    );

endmodule