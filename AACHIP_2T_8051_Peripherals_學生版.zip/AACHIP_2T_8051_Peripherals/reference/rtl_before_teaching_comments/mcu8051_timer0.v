`timescale 1ns / 1ps

// 8051 Timer 0.  Supports modes 0, 1, 2 and the Timer-0 mode-3 split.
module mcu8051_timer0 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       timer_tick,
    input  wire       t0_pin,
    input  wire       int0_n,
    input  wire [3:0] tmod,
    input  wire       tr0,
    input  wire       tr1,
    input  wire       write_tl,
    input  wire       write_th,
    input  wire [7:0] write_data,
    output reg  [7:0] tl0,
    output reg  [7:0] th0,
    output reg        overflow0,
    output reg        overflow1_split
);
    reg t0_d;
    wire t0_level = (t0_pin === 1'b0) ? 1'b0 : 1'b1;
    wire t0_fall = t0_d && !t0_level;
    wire gate_open = !tmod[3] || (int0_n !== 1'b0);
    wire count_event = tmod[2] ? t0_fall : timer_tick;
    wire enabled = tr0 && gate_open && count_event;
    wire split_mode = (tmod[1:0] == 2'b11);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tl0 <= 8'h00;
            th0 <= 8'h00;
            t0_d <= 1'b1;
            overflow0 <= 1'b0;
            overflow1_split <= 1'b0;
        end else begin
            t0_d <= t0_level;
            overflow0 <= 1'b0;
            overflow1_split <= 1'b0;

            if (write_tl) tl0 <= write_data;
            if (write_th) th0 <= write_data;

            if (split_mode) begin
                if (enabled && !write_tl) begin
                    tl0 <= tl0 + 8'd1;
                    if (tl0 == 8'hff) overflow0 <= 1'b1;
                end
                // In split mode TH0 is an 8-bit timer driven by TR1.  It is
                // never an external counter and does not use Timer-0 GATE.
                if (tr1 && timer_tick && !write_th) begin
                    th0 <= th0 + 8'd1;
                    if (th0 == 8'hff) overflow1_split <= 1'b1;
                end
            end else if (enabled && !write_tl && !write_th) begin
                case (tmod[1:0])
                    2'b00: begin
                        {th0, tl0[4:0]} <= {th0, tl0[4:0]} + 13'd1;
                        if ({th0, tl0[4:0]} == 13'h1fff) overflow0 <= 1'b1;
                    end
                    2'b01: begin
                        {th0, tl0} <= {th0, tl0} + 16'd1;
                        if ({th0, tl0} == 16'hffff) overflow0 <= 1'b1;
                    end
                    2'b10: begin
                        if (tl0 == 8'hff) begin
                            tl0 <= th0;
                            overflow0 <= 1'b1;
                        end else tl0 <= tl0 + 8'd1;
                    end
                    default: ;
                endcase
            end
        end
    end
endmodule
