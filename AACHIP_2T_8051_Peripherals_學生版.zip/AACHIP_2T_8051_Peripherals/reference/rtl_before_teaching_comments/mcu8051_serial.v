`timescale 1ns / 1ps

// 8051 serial port.  Modes 1/2/3 implement framed UART transfer.  Mode 0
// implements an 8-bit synchronous shift using TXD as the shift clock.
module mcu8051_serial #(
    parameter integer SEPARATE_BAUD = 0,
    parameter integer VARIABLE_BAUD_DIV = 32,
    parameter integer MODE2_BAUD_DIV = 64,
    parameter integer MODE0_BAUD_DIV = 1
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       clock_enable,
    input  wire [7:0] scon,
    input  wire       smod,
    input  wire       timer1_overflow,
    input wire rx_baud_overflow,tx_baud_overflow,
    input wire rx_use_timer2,tx_use_timer2,
    input  wire       rxd,
    input  wire       sbuf_write,
    input  wire [7:0] sbuf_write_data,
    output reg  [7:0] sbuf_read_data,
    output reg        txd,
    output reg        rxd_out,
    output reg        rxd_output_enable,
    output reg        ri_set,
    output reg        ti_set,
    output reg        rb8_write,
    output reg        rb8_data,
    output reg        tx_busy,
    output reg        rx_busy
);
    localparam integer VAR_W = (VARIABLE_BAUD_DIV <= 1) ? 1 : $clog2(VARIABLE_BAUD_DIV);
    localparam integer FIX_W = (MODE2_BAUD_DIV <= 1) ? 1 : $clog2(MODE2_BAUD_DIV);
    localparam integer M0_W = (MODE0_BAUD_DIV <= 1) ? 1 : $clog2(MODE0_BAUD_DIV);
    reg [VAR_W-1:0] variable_count,tx_variable_count;
    reg [FIX_W-1:0] fixed_count;
    reg [M0_W-1:0] mode0_count;
    reg [10:0] tx_shift;
    reg [3:0] tx_remaining;
    reg [7:0] rx_shift;
    reg [3:0] rx_index;
    reg rx_ninth;
    reg mode0_phase;
    wire [1:0] mode = scon[7:6];
    wire [31:0] variable_limit = smod ? ((VARIABLE_BAUD_DIV/2) < 1 ? 1 : VARIABLE_BAUD_DIV/2) :
                                             (VARIABLE_BAUD_DIV < 1 ? 1 : VARIABLE_BAUD_DIV);
    wire [31:0] fixed_limit = smod ? ((MODE2_BAUD_DIV/2) < 1 ? 1 : MODE2_BAUD_DIV/2) :
                                          (MODE2_BAUD_DIV < 1 ? 1 : MODE2_BAUD_DIV);
    wire rx_source=SEPARATE_BAUD ? rx_baud_overflow : timer1_overflow;
    wire tx_source=SEPARATE_BAUD ? tx_baud_overflow : timer1_overflow;
    wire [31:0] rx_limit=(SEPARATE_BAUD && rx_use_timer2)?16:variable_limit;
    wire [31:0] tx_limit=(SEPARATE_BAUD && tx_use_timer2)?16:variable_limit;
    wire variable_baud_tick = rx_source && (variable_count == rx_limit-1);
    wire tx_variable_baud_tick = tx_source && (tx_variable_count == tx_limit-1);
    wire fixed_baud_tick = (fixed_count == fixed_limit-1);
    wire mode0_baud_tick = (mode0_count == MODE0_BAUD_DIV-1);
    wire uart_baud_tick = (mode == 2'b10) ? fixed_baud_tick : variable_baud_tick;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            variable_count <= 0;
            tx_variable_count <= 0;
            fixed_count <= 0;
            mode0_count <= 0;
            sbuf_read_data <= 0;
            txd <= 1'b1;
            rxd_out <= 1'b1;
            rxd_output_enable <= 1'b0;
            ri_set <= 1'b0;
            ti_set <= 1'b0;
            rb8_write <= 1'b0;
            rb8_data <= 1'b0;
            tx_busy <= 1'b0;
            rx_busy <= 1'b0;
            tx_shift <= 0;
            tx_remaining <= 0;
            rx_shift <= 0;
            rx_index <= 0;
            rx_ninth <= 0;
            mode0_phase <= 0;
        end else if (clock_enable) begin
            ri_set <= 1'b0;
            ti_set <= 1'b0;
            rb8_write <= 1'b0;

            if (rx_source) begin
                if (variable_baud_tick) variable_count <= 0;
                else variable_count <= variable_count + 1'b1;
            end
            if(tx_source) begin
                if(tx_variable_baud_tick) tx_variable_count<=0;
                else tx_variable_count<=tx_variable_count+1'b1;
            end
            if (fixed_baud_tick) fixed_count <= 0;
            else fixed_count <= fixed_count + 1'b1;
            if (mode0_baud_tick) mode0_count <= 0;
            else mode0_count <= mode0_count + 1'b1;

            if (sbuf_write && !tx_busy) begin
                tx_busy <= 1'b1;
                if (mode == 2'b00) begin
                    tx_shift <= {3'b0, sbuf_write_data};
                    tx_remaining <= 8;
                    rxd_output_enable <= 1'b1;
                    rxd_out <= sbuf_write_data[0];
                    txd <= 1'b0;
                    mode0_phase <= 1'b0;
                end else if (mode == 2'b01) begin
                    tx_shift <= {1'b0, 1'b1, sbuf_write_data, 1'b0};
                    tx_remaining <= 10;
                    txd <= 1'b0;
                end else begin
                    tx_shift <= {1'b1, scon[3], sbuf_write_data, 1'b0};
                    tx_remaining <= 11;
                    txd <= 1'b0;
                end
            end

            if (mode == 2'b00) begin
                // Two divider events form one shift clock in synchronous mode.
                if (tx_busy && mode0_baud_tick) begin
                    mode0_phase <= ~mode0_phase;
                    txd <= ~txd;
                    if (mode0_phase) begin
                        tx_shift <= tx_shift >> 1;
                        rx_shift <= {rxd,rx_shift[7:1]};
                        if (tx_remaining == 1) begin
                            tx_busy <= 1'b0;
                            rx_busy <= 1'b0;
                            txd <= 1'b1;
                            rxd_output_enable <= 1'b0;
                            sbuf_read_data <= {rxd,rx_shift[7:1]};
                            ti_set <= 1'b1;
                            ri_set <= 1'b1;
                        end else begin
                            tx_remaining <= tx_remaining - 1'b1;
                            rxd_out <= tx_shift[1];
                        end
                    end
                end
            end else begin
                if (((mode==2'b10)?fixed_baud_tick:tx_variable_baud_tick) && tx_busy) begin
                    if (tx_remaining == 1) begin
                        tx_busy <= 1'b0;
                        txd <= 1'b1;
                        ti_set <= 1'b1;
                    end else begin
                        tx_shift <= tx_shift >> 1;
                        tx_remaining <= tx_remaining - 1'b1;
                        txd <= tx_shift[1];
                    end
                end

                if (uart_baud_tick) begin
                if (!rx_busy) begin
                    if (scon[4] && !rxd) begin
                        rx_busy <= 1'b1;
                        rx_index <= 0;
                        rx_shift <= 0;
                        rx_ninth <= 0;
                    end
                end else if (rx_index < 8) begin
                    rx_shift[rx_index] <= rxd;
                    rx_index <= rx_index + 1'b1;
                end else if (mode != 2'b01 && rx_index == 8) begin
                    rx_ninth <= rxd;
                    rx_index <= 9;
                end else begin
                    rx_busy <= 1'b0;
                    sbuf_read_data <= rx_shift;
                    rb8_write <= 1'b1;
                    rb8_data <= (mode == 2'b01) ? rxd : rx_ninth;
                    if (!scon[5] || ((mode == 2'b01) ? rxd : rx_ninth)) ri_set <= 1'b1;
                end
                end
            end
        end
    end
endmodule
