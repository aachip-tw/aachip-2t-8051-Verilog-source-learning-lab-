`timescale 1ns / 1ps

// 8051 Timer 1.  In Timer-0 mode 3 its overflow remains available to the
// serial baud generator, while TH0 owns the architectural TF1 flag.
module mcu8051_timer1 (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       timer_tick,
    input  wire       t1_pin,
    input  wire       int1_n,
    input  wire [3:0] tmod,
    input  wire       tr1,
    input  wire       timer0_split_mode,
    input  wire       write_tl,
    input  wire       write_th,
    input  wire [7:0] write_data,
    output reg  [7:0] tl1,
    output reg  [7:0] th1,
    output reg        overflow1
);
    reg t1_d;
    wire t1_level = (t1_pin === 1'b0) ? 1'b0 : 1'b1;
    wire t1_fall = t1_d && !t1_level;
    wire gate_open = !tmod[3] || (int1_n !== 1'b0);
    wire count_event = tmod[2] ? t1_fall : timer_tick;
    // Timer 1 remains usable as the serial baud generator while Timer 0 is in
    // split mode.  The top level masks this overflow from TF1 in that case.
    wire enabled = tr1 && gate_open && count_event;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tl1 <= 8'h00;
            th1 <= 8'h00;
            t1_d <= 1'b1;
            overflow1 <= 1'b0;
        end else begin
            t1_d <= t1_level;
            overflow1 <= 1'b0;
            if (write_tl) tl1 <= write_data;
            if (write_th) th1 <= write_data;

            if (enabled && !write_tl && !write_th) begin
                case (tmod[1:0])
                    2'b00: begin
                        {th1, tl1[4:0]} <= {th1, tl1[4:0]} + 13'd1;
                        if ({th1, tl1[4:0]} == 13'h1fff) overflow1 <= 1'b1;
                    end
                    2'b01: begin
                        {th1, tl1} <= {th1, tl1} + 16'd1;
                        if ({th1, tl1} == 16'hffff) overflow1 <= 1'b1;
                    end
                    2'b10: begin
                        if (tl1 == 8'hff) begin
                            tl1 <= th1;
                            overflow1 <= 1'b1;
                        end else tl1 <= tl1 + 8'd1;
                    end
                    // Mode 3 is reserved for Timer 1 and does not count.
                    default: ;
                endcase
            end
        end
    end
endmodule
