`timescale 1ns/1ps
// Extended peripherals shared by the 1T, 2T and 12T implementations.
// No generated clocks: all state advances on clk with explicit enables.
module mcu8051_extended (
 input wire clk,rst_n,run_enable,timer_tick,
 input wire [7:0] addr,wdata,
 input wire wr,
 output reg [7:0] rdata,
 output wire selected,
 input wire [7:0] p1,
 input wire timer1_overflow,
 input wire [7:0] ie,
 output reg [7:0] ckcon,spc_fnc,mpage,eie,exif,eicon,
 output wire timer2_irq,serial1_irq,
 output wire uart1_txd,uart1_rxd_out,uart1_rxd_oe,
 output reg t2_out,
 output wire t2_output_enable,
 output wire uart0_rx_tick,uart0_tx_tick,
 output wire uart0_use_rx_t2,uart0_use_tx_t2,
 output wire adc_sclk,adc_mosi,adc_cs_n,
 input wire adc_miso,
 output wire [7:0] export_a,export_b,export_c,export_d,
 output wire [7:0] export_b_oe,export_c_oe,export_d_oe,
 input wire [7:0] export_a_in,export_b_in,export_c_in,export_d_in
);
 reg [7:0] scon1,t2con,t2mod;
 reg [15:0] counter2,reload2;
 reg [7:0] ddrb,ddrc,ddrd,porta,portb,portc,portd;
 wire [7:0] sbuf1;
 wire ri1,ti1,rb8we1,rb8data1;
 wire txbusy1,rxbusy1;
 reg [7:0] pins_d;
 reg timer2_overflow;
 wire t2fall=pins_d[0]&&!p1[0];
 wire exfall=pins_d[1]&&!p1[1];
 wire baud_mode=t2con[5]||t2con[4];
 // CKCON TxM=1 selects the core clock, 0 selects the timer machine tick.
 wire count_tick=run_enable && (t2con[1] ? t2fall :
                 (ckcon[5] || baud_mode || t2mod[1]) ? 1'b1 : timer_tick);
 wire down=t2mod[0]&&!baud_mode&&!p1[1];
 wire count_limit=down ? counter2==reload2 : counter2==16'hffff;
 wire ext_reload=t2con[3]&&exfall&&!t2mod[0];
 wire t2_write=wr&&(addr==8'hcc||addr==8'hcd);
 wire [7:0] adc_control,adc_hi,adc_lo;
 assign timer2_irq=t2con[7]||t2con[6];
 assign serial1_irq=scon1[0]||scon1[1];
 assign t2_output_enable=t2mod[1]&&t2con[2]&&!t2con[1];
 assign uart0_use_rx_t2=t2con[5];
 assign uart0_use_tx_t2=t2con[4];
 assign uart0_rx_tick=timer2_overflow;
 assign uart0_tx_tick=timer2_overflow;
 assign export_a=porta;
 assign export_b=portb;assign export_c=portc;assign export_d=portd;
 assign export_b_oe=ddrb;assign export_c_oe=ddrc;assign export_d_oe=ddrd;

 mcu8051_serial #(.SEPARATE_BAUD(1)) u_uart1 (
  .clk(clk),.rst_n(rst_n),.clock_enable(run_enable),
  .scon(scon1),.smod(eicon[7]),.timer1_overflow(timer1_overflow),
  .rx_baud_overflow(timer1_overflow),.tx_baud_overflow(timer1_overflow),
  .rx_use_timer2(1'b0),.tx_use_timer2(1'b0),
  .rxd(p1[2]),.sbuf_write(wr&&addr==8'hc1),.sbuf_write_data(wdata),
  .sbuf_read_data(sbuf1),.txd(uart1_txd),.rxd_out(uart1_rxd_out),
  .rxd_output_enable(uart1_rxd_oe),.ri_set(ri1),.ti_set(ti1),
  .rb8_write(rb8we1),.rb8_data(rb8data1),.tx_busy(txbusy1),.rx_busy(rxbusy1)
 );
 mcu8051_adc_spi u_adc (
  .clk(clk),.rst_n(rst_n),.wr(wr&&addr==8'hf8),.wdata(wdata),
  .control(adc_control),.result_hi(adc_hi),.result_lo(adc_lo),
  .sclk(adc_sclk),.mosi(adc_mosi),.cs_n(adc_cs_n),.miso(adc_miso)
 );

 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   ckcon<=8'h01;spc_fnc<=8'h02;mpage<=0;eie<=0;exif<=8'h08;eicon<=8'h40;
   scon1<=0;t2con<=0;t2mod<=0;counter2<=0;reload2<=0;
   pins_d<=8'hff;timer2_overflow<=0;t2_out<=1;
   ddrb<=0;ddrc<=0;ddrd<=0;porta<=0;portb<=0;portc<=0;portd<=0;
  end else begin
   timer2_overflow<=0;
   if(run_enable) pins_d<=p1;
   if(wr) case(addr)
    8'h8e:ckcon<=wdata;
    8'h8f:spc_fnc<=wdata;
    8'h91:exif<={wdata[7:4],4'h8};
    8'h92:mpage<=wdata;
    8'hc0:scon1<=wdata;
    8'hc8:t2con<=wdata;
    8'hc9:t2mod<=wdata;
    8'hca:reload2[7:0]<=wdata;
    8'hcb:reload2[15:8]<=wdata;
    8'hcc:counter2[7:0]<=wdata;
    8'hcd:counter2[15:8]<=wdata;
    8'hd8:eicon<={wdata[7],1'b1,wdata[5:3],1'b0,wdata[1:0]};
    8'he8:eie<=wdata;
    8'hf9:porta<=wdata;
    8'hfa:ddrb<=wdata;
    8'hfb:portb<=wdata;
    8'hfc:ddrc<=wdata;
    8'hfd:portc<=wdata;
    8'hfe:ddrd<=wdata;
    8'hff:portd<=wdata;
    default:;
   endcase
   if(ri1)scon1[0]<=1;
   if(ti1)scon1[1]<=1;
   if(rb8we1)scon1[2]<=rb8data1;
   if(run_enable) begin
    // Match the 4T external interrupt logic: EX2..EX5 falling. Flag capture is enabled by EXn, as on its pin mux.
    if(eie[4]&&pins_d[4]&&!p1[4])exif[4]<=1;
    if(eie[5]&&pins_d[5]&&!p1[5])exif[5]<=1;
    if(eie[6]&&pins_d[6]&&!p1[6])exif[6]<=1;
    if(eie[7]&&pins_d[7]&&!p1[7])exif[7]<=1;
    if(t2con[2]&&count_tick&&!t2_write) begin
     if(count_limit) begin
      counter2<=down?16'hffff: ((!t2con[0]||baud_mode||t2mod[0]||t2mod[1])?reload2:16'h0000);
      timer2_overflow<=1;
      if(t2mod[1])t2_out<=~t2_out;
      if(!baud_mode&&!t2mod[1])t2con[7]<=1;
      if(t2mod[0]&&!baud_mode)t2con[6]<=~t2con[6];
     end else counter2<=down?counter2-16'd1:counter2+16'd1;
    end
    if(ext_reload) begin
     t2con[6]<=1;
     if(!baud_mode&&t2con[0])reload2<=counter2;
     else if(!t2_write)counter2<=reload2;
    end
   end
  end
 end

 assign selected=addr==8'h8e||addr==8'h8f||addr==8'h91||addr==8'h92||
  (addr>=8'hc0&&addr<=8'hc3)||(addr>=8'hc8&&addr<=8'hcd)||
  addr==8'hd8||addr==8'he8||addr>=8'hf8;
 always @(*) begin
  rdata=0;
  case(addr)
   8'h8e:rdata=ckcon;8'h8f:rdata=spc_fnc;8'h91:rdata=exif;8'h92:rdata=mpage;
   8'hc0:rdata=scon1;8'hc1:rdata=sbuf1;
   8'hc2:rdata=adc_lo;8'hc3:rdata=adc_hi;
   8'hc8:rdata=t2con;8'hc9:rdata=t2mod;
   8'hca:rdata=reload2[7:0];8'hcb:rdata=reload2[15:8];
   8'hcc:rdata=counter2[7:0];8'hcd:rdata=counter2[15:8];
   8'hd8:rdata=eicon;8'he8:rdata=eie;8'hf8:rdata=adc_control;
   8'hf9:rdata=export_a_in;8'hfa:rdata=ddrb;
   8'hfb:rdata=(export_b_in&~ddrb)|(portb&ddrb);
   8'hfc:rdata=ddrc;8'hfd:rdata=(export_c_in&~ddrc)|(portc&ddrc);
   8'hfe:rdata=ddrd;8'hff:rdata=(export_d_in&~ddrd)|(portd&ddrd);
   default:;
  endcase
 end
endmodule

// Same ADC command sequence as the 4T: Ax,41,wait MISO low,00,00.
// SPI mode 3, divider 66, CS held low over four bytes, 100 clock gaps.
module mcu8051_adc_spi #(parameter HALF_PERIOD=66,GAP=100)(
 input wire clk,rst_n,wr,input wire [7:0] wdata,
 output reg [7:0] control,result_hi,result_lo,
 output reg sclk,mosi,cs_n,input wire miso
);
 reg [2:0] state;
 reg [7:0] tx,rx;
 reg [7:0] div_count,gap_count;
 reg [2:0] bit_count;
 reg [1:0] byte_count;
 reg miso_s1,miso_s2;
 wire start=wr&&wdata[6]&&!control[6];
 localparam IDLE=0,LOW=1,HIGH=2,PAUSE=3,READY=4,FINISH=5;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n) begin
   control<=0;result_hi<=0;result_lo<=0;state<=IDLE;
   tx<=0;rx<=0;div_count<=0;gap_count<=0;bit_count<=0;byte_count<=0;
   miso_s1<=1;miso_s2<=1;sclk<=1;mosi<=0;cs_n<=1;
  end else begin
   miso_s1<=miso;miso_s2<=miso_s1;
   if(wr)control<=wdata[6]?{1'b0,wdata[6:0]}:wdata;
   case(state)
    IDLE:if(start)begin
     tx<={4'ha,wdata[3:0]};rx<=0;
     byte_count<=0;bit_count<=7;div_count<=0;cs_n<=0;state<=LOW;
    end
    LOW:if(div_count==HALF_PERIOD-1)begin
     div_count<=0;sclk<=0;mosi<=tx[bit_count];state<=HIGH;
    end else div_count<=div_count+1'b1;
    HIGH:if(div_count==HALF_PERIOD-1)begin
     div_count<=0;sclk<=1;rx<={rx[6:0],miso_s2};
     if(bit_count==0)begin
      if(byte_count==2)result_hi<={rx[6:0],miso_s2};
      if(byte_count==3)begin
       result_lo<={rx[6:0],miso_s2};state<=FINISH;
      end else begin
       byte_count<=byte_count+1'b1;gap_count<=0;
       tx<=byte_count==0?8'h41:8'h00;
       state<=byte_count==1?READY:PAUSE;
      end
     end else begin bit_count<=bit_count-1'b1;state<=LOW;end
    end else div_count<=div_count+1'b1;
    READY:if(!miso_s2)begin gap_count<=0;state<=PAUSE;end
    PAUSE:if(gap_count==GAP-1)begin
     bit_count<=7;rx<=0;div_count<=0;state<=LOW;
    end else gap_count<=gap_count+1'b1;
    FINISH:begin control[7]<=1;control[6]<=0;cs_n<=1;state<=IDLE;end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
