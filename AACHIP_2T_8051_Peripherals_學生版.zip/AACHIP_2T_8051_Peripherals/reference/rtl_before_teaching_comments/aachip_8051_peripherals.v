`timescale 1ns/1ps
// CPU-independent synchronous SFR peripheral subsystem.
// Added wrapper; leaf RTL is a byte-identical snapshot of the source project.
module aachip_8051_peripherals #(
 parameter integer TIMER_CLK_DIV=1,
 parameter integer SERIAL_VARIABLE_BAUD_DIV=32,
 parameter integer SERIAL_MODE2_BAUD_DIV=64,
 parameter integer SERIAL_MODE0_BAUD_DIV=1
)(
 input wire clk,rst_n,run_enable,
 input wire [7:0] sfr_addr,sfr_wdata,
 input wire sfr_we,sfr_rmw,
 output wire [7:0] sfr_rdata,
 input wire irq_ack,
 input wire [3:0] irq_ack_source,
 output wire [12:0] irq_pending,
 output wire [7:0] ie,ip,eie,eicon,
 input wire [7:0] p0_in,p1_in,p2_in,p3_in,
 output wire [7:0] p0_out,p1_out,p2_out,p3_out,
 output wire [7:0] p0_oe,p1_oe,p2_oe,p3_oe,
 input wire int0_n,int1_n,t0_pin,t1_pin,
 input wire adc_miso,
 output wire adc_sclk,adc_mosi,adc_cs_n,
 input wire [7:0] export_a_in,export_b_in,export_c_in,export_d_in,
 output wire [7:0] export_a,export_b,export_c,export_d,
 output wire [7:0] export_b_oe,export_c_oe,export_d_oe
);
 wire [7:0] sfr_bus_addr=sfr_addr,sfr_bus_wr_data=sfr_wdata;
 wire sfr_bus_wr_en=sfr_we;
 wire mem_rmw=sfr_rmw;
 wire peripheral_enable=run_enable;
 wire timer_write=sfr_we;
 wire core_irq_ack=irq_ack;
 wire [3:0] core_irq_source=irq_ack_source;
 wire [7:0] base_sfr_rd_data,extended_sfr_data;
 wire extended_sfr_select;
 assign sfr_rdata=extended_sfr_select?extended_sfr_data:base_sfr_rd_data;
 wire [7:0] ckcon,spc_fnc,mpage,exif,tcon,tmod,scon,pcon;
 wire timer2_irq,serial1_irq,uart1_txd,uart1_rxd_out,uart1_rxd_oe;
 wire t2_output_enable,t2_out,t2_rx_tick,t2_tx_tick,t2_rx_select,t2_tx_select;
 wire [7:0] tl0,th0,tl1,th1,gpio_read_data,serial_sbuf;
 wire effective_int0_n,effective_int1_n,effective_t0,effective_t1;
 wire serial_rxd_pin,serial_txd_pin,serial_rxd_out,serial_rxd_oe;
 wire serial_ri_set,serial_ti_set,serial_rb8_write,serial_rb8_data;
 wire serial_tx_busy,serial_rx_busy;
 wire timer0_internal_overflow,timer1_internal_overflow,timer0_split_overflow;
 wire timer0_event=timer0_internal_overflow;
 wire timer1_event=(tmod[1:0]==2'b11)?timer0_split_overflow:timer1_internal_overflow;
 wire serial_rx_irq=1'b0,serial_tx_irq=1'b0;
 localparam integer DIV_W=(TIMER_CLK_DIV<=1)?1:$clog2(TIMER_CLK_DIV);
 reg [DIV_W-1:0] timer_div_count;
 wire timer_tick=(TIMER_CLK_DIV<=1)?1'b1:(timer_div_count==TIMER_CLK_DIV-1);
 always @(posedge clk or negedge rst_n)
  if(!rst_n)timer_div_count<=0;
  else if(run_enable)begin
   if(timer_tick)timer_div_count<=0;
   else timer_div_count<=timer_div_count+1'b1;
  end
 // Enable-qualified requests. Global EA and CPU priority arbitration are external.
 assign irq_pending={eicon[3]&eicon[0],exif[7]&eie[7],exif[6]&eie[6],
  exif[5]&eie[5],exif[4]&eie[4],serial1_irq&ie[6],eicon[4]&eicon[5],
  timer2_irq&ie[5],(scon[0]|scon[1])&ie[4],tcon[7]&ie[3],
  tcon[3]&ie[2],tcon[5]&ie[1],tcon[1]&ie[0]};
    mcu8051_gpio #(.EXTENDED(1)) u_gpio (
        .clk(clk), .rst_n(rst_n), .sfr_addr(sfr_bus_addr),
        .sfr_write_data(sfr_bus_wr_data), .sfr_write_enable(timer_write),
        .sfr_rmw(mem_rmw), .p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
        .p0_in(p0_in), .p1_in(p1_in),
        .p2_in(p2_in), .p3_in(p3_in), .ext_int0_n(int0_n),
        .ext_int1_n(int1_n), .ext_t0(t0_pin), .ext_t1(t1_pin),
        .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
        .t2_output_enable(t2_output_enable),.t2_out(t2_out),
        .serial_txd(serial_txd_pin), .serial_rxd_out(serial_rxd_out),
        .serial_rxd_oe(serial_rxd_oe), .p0_out(p0_out), .p1_out(p1_out),
        .p2_out(p2_out), .p3_out(p3_out), .port_read_data(gpio_read_data),
        .int0_n(effective_int0_n), .int1_n(effective_int1_n),
        .t0_pin(effective_t0), .t1_pin(effective_t1), .serial_rxd(serial_rxd_pin)
    );

    mcu8051_timer0 u_timer0 (
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[3]?peripheral_enable:timer_tick & peripheral_enable)),
        .t0_pin(effective_t0), .int0_n(effective_int0_n), .tmod(tmod[3:0]),
        .tr0(tcon[4]), .tr1(tcon[6]),
        .write_tl(timer_write && sfr_bus_addr == 8'h8A),
        .write_th(timer_write && sfr_bus_addr == 8'h8C), .write_data(sfr_bus_wr_data),
        .tl0(tl0), .th0(th0), .overflow0(timer0_internal_overflow),
        .overflow1_split(timer0_split_overflow)
    );

    mcu8051_timer1 u_timer1 (
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[4]?peripheral_enable:timer_tick & peripheral_enable)),
        .t1_pin(effective_t1), .int1_n(effective_int1_n), .tmod(tmod[7:4]),
        .tr1(tcon[6]), .timer0_split_mode(tmod[1:0] == 2'b11),
        .write_tl(timer_write && sfr_bus_addr == 8'h8B),
        .write_th(timer_write && sfr_bus_addr == 8'h8D), .write_data(sfr_bus_wr_data),
        .tl1(tl1), .th1(th1), .overflow1(timer1_internal_overflow)
    );

    mcu8051_serial #(
        .SEPARATE_BAUD(1),
        .VARIABLE_BAUD_DIV(SERIAL_VARIABLE_BAUD_DIV),
        .MODE2_BAUD_DIV(SERIAL_MODE2_BAUD_DIV),
        .MODE0_BAUD_DIV(SERIAL_MODE0_BAUD_DIV)
    ) u_serial (
        .clk(clk), .rst_n(rst_n), .clock_enable(peripheral_enable),
        .scon(scon), .smod(pcon[7]),
        .timer1_overflow(timer1_internal_overflow),
        .rx_baud_overflow(t2_rx_select?t2_rx_tick:timer1_internal_overflow),
        .tx_baud_overflow(t2_tx_select?t2_tx_tick:timer1_internal_overflow),
        .rx_use_timer2(t2_rx_select),.tx_use_timer2(t2_tx_select),.rxd(serial_rxd_pin),
        .sbuf_write(timer_write && sfr_bus_addr == 8'h99),
        .sbuf_write_data(sfr_bus_wr_data), .sbuf_read_data(serial_sbuf),
        .txd(serial_txd_pin), .rxd_out(serial_rxd_out),
        .rxd_output_enable(serial_rxd_oe), .ri_set(serial_ri_set),
        .ti_set(serial_ti_set), .rb8_write(serial_rb8_write),
        .rb8_data(serial_rb8_data), .tx_busy(serial_tx_busy), .rx_busy(serial_rx_busy)
    );

    // ------------------------------------------------------------------------
    // 2. 實例化獨立 SFR 暫存器庫 (mcu8051_sfr_bank)
    // ------------------------------------------------------------------------
    mcu8051_sfr_bank u_sfr_bank (
        .clk           (clk),
        .rst_n         (rst_n),
		
        // 指令總線存取介面
        .sfr_addr      (sfr_bus_addr),
        .sfr_wr_data   (sfr_bus_wr_data),
        .sfr_rd_data   (base_sfr_rd_data),
        .sfr_wr_en     (sfr_bus_wr_en),
        .sfr_rmw       (mem_rmw),
        .int0_n        (effective_int0_n), .int1_n(effective_int1_n),
        .timer0_overflow(timer0_event), .timer1_overflow(timer1_event),
        .timer0_tl(tl0), .timer0_th(th0),
        .timer1_tl(tl1), .timer1_th(th1),
        .serial_rx_irq (serial_ri_set | (serial_rx_irq === 1'b1)),
        .serial_tx_irq (serial_ti_set | (serial_tx_irq === 1'b1)),
        .serial_sbuf(serial_sbuf), .serial_rb8_write(serial_rb8_write),
        .serial_rb8_data(serial_rb8_data),
        .irq_ack       (core_irq_ack), .irq_ack_source(core_irq_source),

        // ALU 硬體強制寫入介面
        .core_psw_we(1'b0),
        .core_psw_data(8'h00),
        .core_acc_we(1'b0),
        .core_acc_data(8'h00),
        .core_b_we(1'b0),
        .core_b_data(8'h00),
        .core_sp_we(1'b0),
        .core_sp_data(8'h00),

		.core_dptr_we(1'b0),
		.core_dptr_data(16'h0000),


        // Core 暫存器輸出
        .acc(),
        .b(),
        .psw(),
        .sp(),
        .dpl(),
        .dph(),
        .dptr(),.dps_out(),.dp0_value(),.dp1_value(),
        .ie             (ie), .ip(ip), .tcon(tcon), .tmod(tmod), .scon(scon),
        .pcon           (pcon),

        // GPIO readback is supplied by the independent port block.
        .port_read_data(gpio_read_data)
    );

    // ------------------------------------------------------------------------

    mcu8051_extended u_extended (
     .clk(clk),.rst_n(rst_n),.run_enable(peripheral_enable),.timer_tick(timer_tick),
     .addr(sfr_bus_addr),.wdata(sfr_bus_wr_data),.wr(sfr_bus_wr_en),
     .rdata(extended_sfr_data),.selected(extended_sfr_select),.p1(p1_in),
     .timer1_overflow(timer1_internal_overflow),.ie(ie),
     .ckcon(ckcon),.spc_fnc(spc_fnc),.mpage(mpage),.eie(eie),.exif(exif),.eicon(eicon),
     .timer2_irq(timer2_irq),.serial1_irq(serial1_irq),
     .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
     .t2_out(t2_out),.t2_output_enable(t2_output_enable),
     .uart0_rx_tick(t2_rx_tick),.uart0_tx_tick(t2_tx_tick),
     .uart0_use_rx_t2(t2_rx_select),.uart0_use_tx_t2(t2_tx_select),
     .adc_miso(adc_miso),.adc_sclk(adc_sclk),.adc_mosi(adc_mosi),.adc_cs_n(adc_cs_n),
     .export_a(export_a),.export_b(export_b),.export_c(export_c),.export_d(export_d),
     .export_b_oe(export_b_oe),.export_c_oe(export_c_oe),.export_d_oe(export_d_oe),
     .export_a_in(export_a_in),.export_b_in(export_b_in),.export_c_in(export_c_in),.export_d_in(export_d_in)
    );

endmodule
