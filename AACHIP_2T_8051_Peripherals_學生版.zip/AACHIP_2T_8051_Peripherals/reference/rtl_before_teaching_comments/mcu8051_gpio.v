`timescale 1ns / 1ps

// M1/M0: 00 quasi, 01 push-pull, 10 input, 11 open-drain.
// Physical weak pull-ups remain controlled by Quartus/board configuration.
module mcu8051_gpio #(parameter EXTENDED=0) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] sfr_addr,
    input  wire [7:0] sfr_write_data,
    input  wire       sfr_write_enable,
    input  wire       sfr_rmw,
    output wire [7:0] p0_oe, p1_oe, p2_oe, p3_oe,
    input  wire [7:0] p0_in, input wire [7:0] p1_in,
    input  wire [7:0] p2_in, input wire [7:0] p3_in,
    input  wire       ext_int0_n, input wire ext_int1_n,
    input  wire       ext_t0, input wire ext_t1,
    input wire uart1_txd,uart1_rxd_out,uart1_rxd_oe,t2_output_enable,t2_out,
    input  wire       serial_txd,
    input  wire       serial_rxd_out,
    input  wire       serial_rxd_oe,
    output wire [7:0] p0_out, output wire [7:0] p1_out,
    output wire [7:0] p2_out, output wire [7:0] p3_out,
    output reg  [7:0] port_read_data,
    output wire       int0_n, output wire int1_n,
    output wire       t0_pin, output wire t1_pin,
    output wire       serial_rxd
);
    reg [7:0] p0_latch,p1_latch,p2_latch,p3_latch;
    reg [7:0] p0_m1,p0_m0,p1_m1,p1_m0,p2_m1,p2_m0,p3_m1,p3_m0;
    wire ext_i0 = (ext_int0_n === 1'b0) ? 1'b0 : 1'b1;
    wire ext_i1 = (ext_int1_n === 1'b0) ? 1'b0 : 1'b1;
    wire ext_c0 = (ext_t0 === 1'b0) ? 1'b0 : 1'b1;
    wire ext_c1 = (ext_t1 === 1'b0) ? 1'b0 : 1'b1;
    assign p0_out=p0_latch;
    assign p1_out={p1_latch[7:4],p1_latch[3]&(EXTENDED?uart1_txd:1'b1),
      p1_latch[2]&((EXTENDED&&uart1_rxd_oe)?uart1_rxd_out:1'b1),p1_latch[1],
      (EXTENDED&&t2_output_enable)?t2_out:p1_latch[0]};
    assign p2_out=p2_latch;
    assign p3_out={p3_latch[7:2],p3_latch[1]&serial_txd,
                   p3_latch[0]&(serial_rxd_oe ? serial_rxd_out : 1'b1)};
    assign p0_oe = (~p0_m1 & p0_m0) | (~p0_out & ~(p0_m1 & ~p0_m0));
    assign p1_oe = (~p1_m1 & p1_m0) | (~p1_out & ~(p1_m1 & ~p1_m0));
    assign p2_oe = (~p2_m1 & p2_m0) | (~p2_out & ~(p2_m1 & ~p2_m0));
    assign p3_oe = (~p3_m1 & p3_m0) | (~p3_out & ~(p3_m1 & ~p3_m0));
    assign int0_n=ext_i0 & p3_in[2];
    assign int1_n=ext_i1 & p3_in[3];
    assign t0_pin=ext_c0 & p3_in[4];
    assign t1_pin=ext_c1 & p3_in[5];
    assign serial_rxd=p3_in[0];
    always @(posedge clk or negedge rst_n) begin
      if(!rst_n) begin p0_latch<=8'hff;p1_latch<=8'hff;p2_latch<=8'hff;p3_latch<=8'hff;
        p0_m1<=0; p0_m0<=0;
        p1_m1<=0; p1_m0<=0;
        p2_m1<=0; p2_m0<=0;
        p3_m1<=0; p3_m0<=0;
      end
      else if(sfr_write_enable) case(sfr_addr)
        8'h80:p0_latch<=sfr_write_data; 8'h90:p1_latch<=sfr_write_data;
        8'ha0:p2_latch<=sfr_write_data; 8'hb0:p3_latch<=sfr_write_data;
        8'he1:p0_m1<=sfr_write_data; 8'he2:p0_m0<=sfr_write_data;
        8'he3:p1_m1<=sfr_write_data; 8'he4:p1_m0<=sfr_write_data;
        8'he5:p2_m1<=sfr_write_data; 8'he6:p2_m0<=sfr_write_data;
        8'hf1:p3_m1<=sfr_write_data; 8'hf2:p3_m0<=sfr_write_data;
      endcase
    end
    always @(*) case(sfr_addr)
      8'h80:port_read_data=sfr_rmw?p0_latch:p0_in;
      8'h90:port_read_data=sfr_rmw?p1_latch:p1_in;
      8'ha0:port_read_data=sfr_rmw?p2_latch:p2_in;
      8'hb0:port_read_data=sfr_rmw?p3_latch:p3_in;
      8'he1:port_read_data=p0_m1; 8'he2:port_read_data=p0_m0;
      8'he3:port_read_data=p1_m1; 8'he4:port_read_data=p1_m0;
      8'he5:port_read_data=p2_m1; 8'he6:port_read_data=p2_m0;
      8'hf1:port_read_data=p3_m1; 8'hf2:port_read_data=p3_m0;
      default:port_read_data=8'hff;
    endcase
endmodule
