`timescale 1ns/1ps

// Cyclone IV pin-level wrapper for the rewritten 8051 plus FT2232H debugger.
// Standard 8051 P3 alternate functions:
//   P3.0=RXD, P3.1=TXD, P3.2=INT0_n, P3.3=INT1_n,
//   P3.4=T0 counter input, P3.5=T1 counter input.
// P3.6/P3.7 remain GPIO because MOVX uses the internal XRAM in this system.
module cyclone4_8051_top #(
    parameter ROM_INIT_FILE = "",
    parameter integer EMULATOR = 0,
    parameter integer PROGRAM_BYTES = 16384,
    parameter integer XRAM_BYTES = 256,
    parameter integer MOVX_RI_PAGED = 0,
    parameter integer TIMER_CLK_DIV = 1
) (
    input  wire       clk_40m,
    input  wire       reset_n,
    input wire i_SPI_MISO,
    output wire o_SPI_Clk,o_SPI_MOSI,o_SPI_CS_n,
    input  wire       ftdi_spi_cs,
    input  wire       ftdi_spi_sck,
    input  wire       ftdi_spi_mosi,
    output wire       ftdi_spi_miso,
    inout  wire [7:0] p0,
    inout  wire [7:0] p1,
    inout  wire [7:0] p2,
    inout  wire [7:0] p3,
    output wire       cpu_halted,
    output wire [15:0] debug_pc
);
    wire [7:0] p0_drive,p1_drive,p2_drive,p3_drive;
    wire [7:0] p0_oe,p1_oe,p2_oe,p3_oe;
    // Board oscillator remains 40 MHz on PIN_23; system runs at 20 MHz.
    reg system_clk20;
    always @(posedge clk_40m or negedge reset_n) begin
      if (!reset_n) system_clk20 <= 1'b0;
      else system_clk20 <= ~system_clk20;
    end

    // An 8051 port bit written as zero actively pulls the pin low.  A bit
    // written as one releases it, allowing the board pull-up or an external
    // device to drive it.  Quartus implements these tri-states in FPGA I/O cells.
    genvar bit_index;
    generate for(bit_index=0;bit_index<8;bit_index=bit_index+1) begin: g_port_io
      assign p0[bit_index] = p0_oe[bit_index] ? p0_drive[bit_index] : 1'bz;
      assign p1[bit_index] = p1_oe[bit_index] ? p1_drive[bit_index] : 1'bz;
      assign p2[bit_index] = p2_oe[bit_index] ? p2_drive[bit_index] : 1'bz;
      assign p3[bit_index] = p3_oe[bit_index] ? p3_drive[bit_index] : 1'bz;
    end endgenerate

    mcu8051_spi_debug_system #(.ROM_INIT_FILE(ROM_INIT_FILE),
      .EMULATOR(EMULATOR), .PROGRAM_BYTES(PROGRAM_BYTES),
      .XRAM_BYTES(XRAM_BYTES), .MOVX_RI_PAGED(MOVX_RI_PAGED),
      .TIMER_CLK_DIV(TIMER_CLK_DIV)) u_system (
      .osc40m(system_clk20),.rst_n(reset_n),
      .adc_miso(i_SPI_MISO),.adc_sclk(o_SPI_Clk),.adc_mosi(o_SPI_MOSI),.adc_cs_n(o_SPI_CS_n),
      .spi_cs(ftdi_spi_cs),.spi_sck(ftdi_spi_sck),
      .spi_mosi(ftdi_spi_mosi),.spi_miso(ftdi_spi_miso),
      .p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
      .p0_in(p0),.p0_out(p0_drive),.p1_in(p1),.p1_out(p1_drive),
      .p2_in(p2),.p2_out(p2_drive),.p3_in(p3),.p3_out(p3_drive),
      .pc_out(debug_pc),.cpu_halted(cpu_halted)
    );
endmodule
