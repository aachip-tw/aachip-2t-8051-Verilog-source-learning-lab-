module mcu8051_alu (
    input  wire [4:0] alu_op,   // 5-bit 操作碼
    input  wire [7:0] src_a,
    input  wire [7:0] src_b,
    input  wire       cy_in,
    output reg  [7:0] alu_out,
    output reg        cy_out,
    output reg        ac_out,
    output reg        ov_out
);

    // 將 DA A 暫存變數移至模組層級宣告，避免 case 分支內的編譯錯誤
    reg [7:0] da_step1;
    reg [8:0] da_step2;

    always @(*) begin
        // 預設旗標狀態
        // Combinational temporaries must be assigned on every path.
        da_step1 = 8'h00;
        da_step2 = 9'h000;
        cy_out = cy_in;
        ac_out = 1'b0;
        ov_out = 1'b0;

        case (alu_op)
            5'd0: alu_out = src_a;                                                // ALU_NOP
            5'd1: alu_out = src_b;                                                // ALU_PASS
            
            5'd2: begin                                                           // ALU_ADD
                {cy_out, alu_out} = src_a + src_b;
                ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} > 5'h0F);
                ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7]);
            end
            
            5'd3: begin                                                           // ALU_ADDC
                {cy_out, alu_out} = src_a + src_b + cy_in;
                ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} + cy_in > 5'h0F);
                ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7]);
            end
            
            5'd4: begin                                                           // ALU_SUBB
                // 8051 CY after SUBB is BORROW, not the MSB of a truncated
                // subtraction result.
                alu_out = src_a - src_b - cy_in;
                cy_out  = ({1'b0, src_a} < ({1'b0, src_b} + cy_in));
                ac_out  = ({1'b0, src_a[3:0]} < ({1'b0, src_b[3:0]} + cy_in));
                ov_out  = (src_a[7] != src_b[7]) && (alu_out[7] != src_a[7]);
            end
            
            5'd5: alu_out = src_a + 1'b1;                                         // ALU_INC
            5'd6: alu_out = src_a - 1'b1;                                         // ALU_DEC
            5'd7: alu_out = src_a & src_b;                                        // ALU_ANL
            5'd8: alu_out = src_a | src_b;                                        // ALU_ORL
            5'd9: alu_out = src_a ^ src_b;                                        // ALU_XRL
            5'd10: alu_out = src_a * src_b;                                       // ALU_MUL
            5'd11: alu_out = (src_b != 8'h00) ? (src_a / src_b) : 8'hFF;          // ALU_DIV
            
            5'd12: begin                                                          // ALU_DA (DA A)
                // 階段 1：若低 4 位大於 9 則低位加 0x06
                da_step1 = (src_a[3:0] > 4'h9) ? (src_a + 8'h06) : src_a;
                
                // 階段 2：若高 4 位大於 9 或有 CY 旗標，高位加 0x60 並更新 CY
                if ((da_step1[7:4] > 4'h9) || cy_in) begin
                    da_step2 = {1'b0, da_step1} + 9'h060;
                    alu_out  = da_step2[7:0];
                    cy_out   = 1'b1;
                end else begin
                    alu_out  = da_step1;
                    cy_out   = cy_in;
                end
            end
            
            5'd13: alu_out = {src_a[6:0], src_a[7]};                              // ALU_RL
            
            5'd14: begin                                                          // ALU_RLC
                alu_out = {src_a[6:0], cy_in};
                cy_out  = src_a[7];
            end
            
            5'd15: alu_out = {src_a[0], src_a[7:1]};                              // ALU_RR
            
            5'd16: begin                                                          // ALU_RRC
                alu_out = {cy_in, src_a[7:1]};
                cy_out  = src_a[0];
            end


            5'd17: begin                                                          // ALU_CMP (CJNE)
                // CJNE compares unsigned operands and does NOT subtract CY-in.
                // alu_out is used only for equality/branch decision.
                alu_out = src_a - src_b;
                cy_out  = (src_a < src_b);
                ac_out  = 1'b0;
                ov_out  = 1'b0;
            end
            
            default: alu_out = src_b;
        endcase
    end
endmodule