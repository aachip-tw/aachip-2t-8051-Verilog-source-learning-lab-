// ============================================================================
// Module Name : mcu8051_ucode_rom
// Description : Optimized 8051 Microcode Decoder ROM
// Architecture: Hybrid Decoding (Special Case Exception + Bit Pattern Matrix)
// ============================================================================
module mcu8051_ucode_rom (
    input  wire [7:0]  opcode,
    output reg  [1:0]  bytes,         // Instruction length (1~3 bytes)
    output reg         ram_rd,        // Internal/External RAM Read Enable
    output reg         ram_wr,        // Internal/External RAM Write Enable
    output reg  [4:0]  alu_op,        // ALU Operation Select 擴充為 5 bits
    output reg  [3:0]  src_sel,       // Source Operand Select
    output reg  [3:0]  dst_sel,       // Destination Operand Select
    output reg         cy_we,         // Carry Flag Write Enable
    output reg  [2:0]  jmp_type       // Branch / Jump Type
);

    // ------------------------------------------------------------------------
    // ALU Operation Encodings
    // ------------------------------------------------------------------------
    localparam ALU_NOP  = 5'd0, ALU_PASS = 5'd1, ALU_ADD  = 5'd2, ALU_ADDC = 5'd3,
               ALU_SUBB = 5'd4, ALU_INC  = 5'd5, ALU_DEC  = 5'd6, ALU_ANL  = 5'd7,
               ALU_ORL  = 5'd8, ALU_XRL  = 5'd9, ALU_MUL  = 5'd10, ALU_DIV = 5'd11,
               ALU_DA   = 5'd12, ALU_RL  = 5'd13, ALU_RLC = 5'd14, ALU_RR  = 5'd15, 
               ALU_RRC  = 5'd16, ALU_CMP = 5'd17;

    // ------------------------------------------------------------------------
    // Operand Source / Destination Encodings
    // ------------------------------------------------------------------------
    localparam SEL_NONE = 4'd0, SEL_ACC = 4'd1, SEL_REG = 4'd2, SEL_IND = 4'd3, 
               SEL_DIR  = 4'd4, SEL_IMM = 4'd5, SEL_DPTR = 4'd6, SEL_PC = 4'd7, 
               SEL_BIT  = 4'd8, SEL_EXT = 4'd9;

    // ------------------------------------------------------------------------
    // Jump / Control Encodings
    // ------------------------------------------------------------------------
    localparam JMP_NONE = 3'd0, JMP_SJMP = 3'd1, JMP_AJMP = 3'd2, JMP_LJMP = 3'd3, 
               JMP_CJNE = 3'd4, JMP_DJNZ = 3'd5, JMP_RET = 3'd6, JMP_CALL = 3'd7;

    always @(*) begin
        // 預設控制信號 (Default NOP-like State)
        bytes    = 2'd1;
        ram_rd   = 1'b0;
        ram_wr   = 1'b0; 
        alu_op   = ALU_NOP;
        src_sel  = SEL_NONE;
        dst_sel  = SEL_NONE;
        cy_we    = 1'b0;
        jmp_type = JMP_NONE;

        // --------------------------------------------------------------------
        // 第一層：優先處理不規則 / 特殊指令例外 (Exceptions)
        // --------------------------------------------------------------------
        case (opcode)
            8'h00: begin bytes = 2'd1; alu_op = ALU_NOP; end // NOP
            8'h02: begin bytes = 2'd3; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_LJMP; end // LJMP addr16
            8'h03: begin bytes = 2'd1; alu_op = ALU_RR; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // RR A
            8'h10: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JBC
            8'h12: begin bytes = 2'd3; ram_rd = 1'b1; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_CALL; end // LCALL
            8'h13: begin bytes = 2'd1; alu_op = ALU_RRC; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // RRC A
            8'h20: begin bytes = 2'd3; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JB
            8'h22: begin bytes = 2'd1; ram_rd = 1'b1; dst_sel = SEL_PC; jmp_type = JMP_RET; end // RET
            8'h23: begin bytes = 2'd1; alu_op = ALU_RL; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // RL A
            8'h30: begin bytes = 2'd3; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNB
            8'h32: begin bytes = 2'd1; ram_rd = 1'b1; dst_sel = SEL_PC; jmp_type = JMP_RET; end // RETI
            8'h33: begin bytes = 2'd1; alu_op = ALU_RLC; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // RLC A
            8'h40: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JC
            8'h42: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ORL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            8'h43: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ORL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            8'h50: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNC
            8'h52: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ANL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            8'h53: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ANL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            8'h60: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JZ
            8'h62: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_XRL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            8'h63: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_XRL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            8'h70: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNZ
            8'h72: begin bytes = 2'd2; alu_op = ALU_ORL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'h73: begin bytes = 2'd1; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JMP @A+DPTR
            8'h80: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // SJMP
            8'h82: begin bytes = 2'd2; alu_op = ALU_ANL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'h83: begin bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_EXT; dst_sel = SEL_ACC; end
            8'h84: begin bytes = 2'd1; ram_rd = 1'b1; alu_op = ALU_DIV; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // DIV AB
            8'h85: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_DIR; end
            8'h90: begin bytes = 2'd3; alu_op = ALU_PASS; src_sel = SEL_IMM; dst_sel = SEL_DPTR; end
            8'h92: begin bytes = 2'd2; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'h93: begin bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_EXT; dst_sel = SEL_ACC; end
            8'hA0: begin bytes = 2'd2; alu_op = ALU_ORL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'hA2: begin bytes = 2'd2; alu_op = ALU_PASS; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'hA4: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_MUL; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // MUL AB
            8'hA5: begin bytes = 2'd1; alu_op = ALU_NOP; end
            8'hB0: begin bytes = 2'd2; alu_op = ALU_ANL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            8'hB2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // CPL bit
            8'hB3: begin bytes = 2'd1; dst_sel = SEL_BIT; end // CPL C
            8'hC2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // CLR bit
            8'hC3: begin bytes = 2'd1; dst_sel = SEL_BIT; end // CLR C
            8'hD4: begin bytes = 2'd1; alu_op = ALU_DA; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // DA A (影響 Carry)
            
            // ----------------------------------------------------------------
            // 第二層：矩陣規律拆解 (Matrix Rules)
            // ----------------------------------------------------------------
            default: begin
                // [規律 1] AJMP / ACALL (所有低 4 位為 0x1 之指令)
                if (opcode[3:0] == 4'h1) begin
                    bytes    = 2'd2;
                    src_sel  = SEL_IMM;
                    dst_sel  = SEL_PC;
                    jmp_type = opcode[4] ? JMP_CALL : JMP_AJMP;
                end

                // [規律 2] 標準算術與邏輯群組 (ADD, ADDC, ORL, ANL, XRL, SUBB)
                else if (((opcode[7:4] >= 4'h2 && opcode[7:4] <= 4'h6) || opcode[7:4] == 4'h9) && opcode[3:0] >= 4'h4) begin
                    dst_sel = SEL_ACC;
                    
                    case (opcode[7:4])
                        4'h2: begin alu_op = ALU_ADD; cy_we = 1'b1; end   // ADD 需更新 Carry
                        4'h3: begin alu_op = ALU_ADDC; cy_we = 1'b1; end  // ADDC 需更新 Carry
                        4'h4: alu_op = ALU_ORL;
                        4'h5: alu_op = ALU_ANL;
                        4'h6: alu_op = ALU_XRL;
                        4'h9: begin alu_op = ALU_SUBB; cy_we = 1'b1; end  // SUBB 需更新 Carry
                        default: alu_op = ALU_NOP;
                    endcase

                    case (opcode[3:0])
                        4'h4:       begin bytes = 2'd2; src_sel = SEL_IMM; end                  // #data
                        4'h5:       begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_DIR; end   // direct
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_IND; end   // @Ri
                        default:    begin bytes = 2'd1; src_sel = SEL_REG; end                  // R0 ~ R7
                    endcase
                end

               // [規律 3] 遞增 / 遞減指令 (INC / DEC)
                else if (opcode[7:4] == 4'h0 || opcode[7:4] == 4'h1) begin
                    alu_op = (opcode[7:4] == 4'h0) ? ALU_INC : ALU_DEC;
                    case (opcode[3:0])
                        4'h4: begin bytes = 2'd1; src_sel = SEL_ACC; dst_sel = SEL_ACC; end 
                        4'h5: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_DIR; dst_sel = SEL_DIR; end                       
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_IND; dst_sel = SEL_IND; end
                        default: begin bytes = 2'd1; src_sel = SEL_REG; dst_sel = SEL_REG; end // INC Rn
                    endcase
                end

                // [規律 4] MOV A, src 數據讀取群組 (0xE_)
                else if (opcode[7:4] == 4'hE) begin
                    alu_op  = ALU_PASS;
                    dst_sel = SEL_ACC;
                    case (opcode[3:0])
                        4'h0:       begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_EXT; end
                        4'h2, 4'h3: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_EXT; end
                        4'h4:       begin bytes = 2'd1; src_sel = SEL_NONE; end // CLR A
                        4'h5:       begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_DIR; end
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_IND; end
                        default:    begin bytes = 2'd1; src_sel = SEL_REG; end
                    endcase
                end

                // [規律 5] MOV dest, A 數據寫入群組 (0xF_)
                else if (opcode[7:4] == 4'hF) begin
                    alu_op  = ALU_PASS;
                    src_sel = SEL_ACC;
                    case (opcode[3:0])
                        4'h0:       begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_EXT; end
                        4'h2, 4'h3: begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_EXT; end
                        4'h4:       begin bytes = 2'd1; dst_sel = SEL_ACC; end // CPL A
                        4'h5:       begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_DIR; end
                        4'h6, 4'h7: begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_IND; end
                        default:    begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_REG; end // MOV Rn, A
                    endcase
                end

                // [規律 6] CJNE 條件跳轉指令 (0xB4 ~ 0xBF)
                else if (opcode[7:4] == 4'hB && opcode[3:0] >= 4'h4) begin
                    bytes    = 2'd3;
                    jmp_type = JMP_CJNE;
                    alu_op   = ALU_CMP;   // CJNE 比較不可受舊 CY 影響
                    cy_we    = 1'b1;      // operand1 < operand2 時 CY=1

                    case (opcode[3:0])
                        4'h4: begin // B4: CJNE A,#data,rel
                            ram_rd = 1'b0;
                            dst_sel = SEL_ACC;   // lhs = A
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        end

                        4'h5: begin // B5: CJNE A,direct,rel
                            ram_rd = 1'b1;
                            dst_sel = SEL_ACC;   // lhs = A
                            src_sel = SEL_DIR;   // rhs = direct
                        end

                        4'h6, 4'h7: begin // B6/B7: CJNE @R0/@R1,#data,rel
                            ram_rd = 1'b1;
                            dst_sel = SEL_IND;   // lhs = @Ri
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        end

                        default: begin // B8~BF: CJNE Rn,#data,rel
                            ram_rd = 1'b1;
                            dst_sel = SEL_REG;   // lhs = Rn
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        end
                    endcase
                end
                
                // [規律 7] DJNZ 減一跳轉指令 (0xD5, 0xD8~0xDF)
                else if (opcode[7:4] == 4'hD && (opcode[3:0] == 4'h5 || opcode[3:0] >= 4'h8)) begin
                    alu_op   = ALU_DEC;
                    jmp_type = JMP_DJNZ; 
                    if (opcode[3:0] == 4'h5) begin
                        bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_DIR; dst_sel = SEL_DIR;
                    end else begin
                        bytes = 2'd2; src_sel = SEL_REG; dst_sel = SEL_REG;
                    end
                end

                // [規律 8] MOV dest, #data 立即數寫入群組 (0x74 ~ 0x7F)
                else if (opcode[7:4] == 4'h7 && opcode[3:0] >= 4'h4) begin
                    alu_op  = ALU_PASS;
                    src_sel = SEL_IMM;
                    case (opcode[3:0])
                        4'h4:       begin bytes = 2'd2; dst_sel = SEL_ACC; end // MOV A, #data
                        4'h5: begin // MOV direct, #data (0x75)
                            bytes    = 2'd3;
                            // MOV 必須直接寫入 immediate，不能把目的位址舊值加進來。
                            // ALU_PASS 會輸出 src_b，而 SEL_IMM/3-byte 指令的 src_b = op2。
                            alu_op   = ALU_PASS;
                            src_sel  = SEL_IMM; 
                            dst_sel  = SEL_DIR; 
                            ram_wr   = 1'b1;
                        end 
                        4'h6, 4'h7: begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_IND; end
                        default:    begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_REG; end
                    endcase
                end

                // [規律 9] MOV direct, src 直接定址寫入群組 (0x86 ~ 0x8F)
                else if (opcode[7:4] == 4'h8 && opcode[3:0] >= 4'h6) begin
                    alu_op  = ALU_PASS;
                    dst_sel = SEL_DIR;
                    ram_wr  = 1'b1;
                    case (opcode[3:0])
                        4'h6, 4'h7: begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_IND; end
                        default:    begin bytes = 2'd2; src_sel = SEL_REG; end
                    endcase
                end

                // [規律 10] MOV dest, direct 與 INC DPTR 群組 (0xA3, 0xA6 ~ 0xAF)
                else if (opcode[7:4] == 4'hA) begin
                    if (opcode == 8'hA3) begin // INC DPTR
                        bytes   = 2'd1;
                        alu_op  = ALU_INC; 
                        src_sel = SEL_DPTR;
                        dst_sel = SEL_DPTR;
                    end else if (opcode[3:0] >= 4'h6) begin
                        alu_op  = ALU_PASS;
                        ram_rd  = 1'b1;
                        ram_wr  = 1'b1;
                        src_sel = SEL_DIR;
                        case (opcode[3:0])
                            4'h6, 4'h7: begin bytes = 2'd2; dst_sel = SEL_IND; end // MOV @Ri, direct
                            default:    begin bytes = 2'd2; dst_sel = SEL_REG; end // MOV Rn, direct
                        endcase
                    end
                end

                // [規律 11] PUSH, SWAP, XCH 群組 (0xC0, 0xC4 ~ 0xCF)
                else if (opcode[7:4] == 4'hC) begin
                    case (opcode[3:0])
                        4'h0: begin // PUSH direct
                            bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_IND;
                        end
                        4'h4: begin // SWAP A
                            bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_ACC; dst_sel = SEL_ACC;
                        end
                        4'h5: begin // XCH A, direct
                            bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_ACC;
                        end
                        4'h6, 4'h7: begin // XCH A, @Ri
                            bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_ACC;
                        end
                        default: begin // XCH A, Rn
                            if (opcode[3:0] >= 4'h8) begin
                                bytes = 2'd1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_REG; dst_sel = SEL_ACC;
                            end
                        end
                    endcase
                end

                // [規律 12] POP, XCHD 與 SETB 群組 (0xD0, 0xD2, 0xD3, 0xD6, 0xD7)
                else if (opcode[7:4] == 4'hD) begin
                    case (opcode[3:0])
                        4'h0: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_DIR; end // POP
                        4'h2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // SETB bit
                        4'h3: begin bytes = 2'd1; dst_sel = 4'd8; end // SETB C
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_ACC; end // XCHD
                        default: begin bytes = 2'd1; alu_op = ALU_NOP; src_sel = SEL_NONE; dst_sel = SEL_NONE; end
                    endcase
                end
            end
        endcase
    end
endmodule