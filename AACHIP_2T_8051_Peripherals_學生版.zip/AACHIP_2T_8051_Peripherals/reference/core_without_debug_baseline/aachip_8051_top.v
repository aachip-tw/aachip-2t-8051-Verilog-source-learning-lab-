`timescale 1ns/1ps
module aachip_8051_top #(
    parameter integer TIMER_CLK_DIV=12,
    parameter integer RAM_PIPELINED=0
)(
    input wire clk,rst_n,
    output wire [15:0] rom_addr,
    input wire [7:0] rom_data,
    output wire [15:0] ext_ram_addr,
    output wire [7:0] ext_ram_wr_data,
    input wire [7:0] ext_ram_rd_data,
    output wire ext_ram_wr_en,ext_ram_rd_en,
    input wire [7:0] p0_in,p1_in,p2_in,p3_in,
    output wire [7:0] p0_out,p1_out,p2_out,p3_out,
    output wire [7:0] p0_oe,p1_oe,p2_oe,p3_oe
);
    wire [7:0] mem_addr,mem_wr_data,mem_rd_data,iram_rd_data,sfr_rd_data;
    wire mem_wr_en,mem_rd_en,mem_rmw,mem_indirect;
    wire sel_iram=!mem_addr[7] || mem_indirect;
    wire sfr_wr_en=mem_wr_en && !sel_iram;
    assign mem_rd_data=sel_iram?iram_rd_data:sfr_rd_data;
    wire core_acc_we,core_b_we,core_sp_we,core_psw_we,core_dptr_we;
    wire [7:0] core_acc_data,core_b_data,core_sp_data,core_psw_data;
    wire [15:0] core_dptr_data;
    wire [7:0] acc,b,sp,psw,ie,ip,tcon,tmod,scon,pcon;
    wire [15:0] dptr,pc;
    wire irq_ack,irq_ack_priority,reti_complete;
    wire [3:0] irq_ack_source;
    wire [7:0] gpio_read_data,tl0,th0,tl1,th1,serial_sbuf;
    wire int0_n,int1_n,t0_pin,t1_pin,serial_rxd,serial_txd;
    wire serial_rxd_out,serial_rxd_oe,ri_set,ti_set,rb8_write,rb8_data;
    wire overflow0,overflow1,overflow1_split;
    wire tf1_event=(tmod[1:0]==2'b11)?overflow1_split:overflow1;
    localparam integer DIV_W=(TIMER_CLK_DIV<=1)?1:$clog2(TIMER_CLK_DIV);
    reg [DIV_W-1:0] timer_div_count;
    wire timer_tick=(TIMER_CLK_DIV<=1)||(timer_div_count==TIMER_CLK_DIV-1);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) timer_div_count<=0;
        else if(timer_tick) timer_div_count<=0;
        else timer_div_count<=timer_div_count+1'b1;
    end
    wire [4:0] requests={((scon[0]|scon[1])&ie[4]),tcon[7]&ie[3],
                        tcon[3]&ie[2],tcon[5]&ie[1],tcon[1]&ie[0]};
    wire [4:0] high_requests=requests & ip[4:0];
    wire [4:0] low_requests=requests & ~ip[4:0];
    reg active_low,active_high;
    wire effective_high=active_high && !reti_complete;
    wire effective_low=active_low && !(reti_complete && !active_high);
    reg irq_valid,irq_priority;
    reg [3:0] irq_source;
    wire [15:0] irq_vector={9'b0,irq_source,3'b011};
    reg [4:0] candidates;
    always @(*) begin
        irq_valid=0;irq_priority=0;irq_source=0;candidates=0;
        if(!irq_ack && ie[7] && !effective_high) begin
            if(|high_requests) begin
                candidates=high_requests;irq_valid=1;irq_priority=1;
            end else if(!effective_low && |low_requests) begin
                candidates=low_requests;irq_valid=1;
            end
        end
        if(candidates[0]) irq_source=0;
        else if(candidates[1]) irq_source=1;
        else if(candidates[2]) irq_source=2;
        else if(candidates[3]) irq_source=3;
        else if(candidates[4]) irq_source=4;
    end
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin active_low<=0;active_high<=0;end
        else begin
            if(reti_complete) begin
                if(active_high) active_high<=0;
                else active_low<=0;
            end
            if(irq_ack) begin
                if(irq_ack_priority) active_high<=1;
                else active_low<=1;
            end
        end
    end
    mcu8051_memory #(.DEPTH(128),.PIPELINED_READ(RAM_PIPELINED)) u_iram (
        .clk(clk),.rd_addr(mem_addr),.rd_data(iram_rd_data),
        .wr_en(rst_n && mem_wr_en && sel_iram),.wr_addr(mem_addr),.wr_data(mem_wr_data)
    );
    mcu8051_classic_sfr u_sfr (
        .clk(clk),.rst_n(rst_n),.sfr_addr(mem_addr),.sfr_wr_data(mem_wr_data),
        .sfr_rd_data(sfr_rd_data),.sfr_wr_en(sfr_wr_en),.sfr_rmw(mem_rmw),
        .core_acc_we(core_acc_we),.core_acc_data(core_acc_data),
        .core_b_we(core_b_we),.core_b_data(core_b_data),
        .core_sp_we(core_sp_we),.core_sp_data(core_sp_data),
        .core_psw_we(core_psw_we),.core_psw_data(core_psw_data),
        .core_dptr_we(core_dptr_we),.core_dptr_data(core_dptr_data),
        .int0_n(int0_n),.int1_n(int1_n),.timer0_overflow(overflow0),.timer1_overflow(tf1_event),
        .timer0_tl(tl0),.timer0_th(th0),.timer1_tl(tl1),.timer1_th(th1),
        .serial_sbuf(serial_sbuf),.serial_rb8_write(rb8_write),.serial_rb8_data(rb8_data),
        .serial_rx_irq(ri_set),.serial_tx_irq(ti_set),.irq_ack(irq_ack),.irq_ack_source(irq_ack_source),
        .acc(acc),.b(b),.psw(psw),.sp(sp),.dpl(),.dph(),.dptr(dptr),
        .ie(ie),.ip(ip),.tcon(tcon),.tmod(tmod),.scon(scon),.pcon(pcon),
        .port_read_data(gpio_read_data)
    );
    mcu8051_gpio #(.EXTENDED(0)) u_gpio (
        .clk(clk),.rst_n(rst_n),.sfr_addr(mem_addr),.sfr_write_data(mem_wr_data),
        .sfr_write_enable(sfr_wr_en && (mem_addr==8'h80 || mem_addr==8'h90 || mem_addr==8'ha0 || mem_addr==8'hb0)),
        .sfr_rmw(mem_rmw),.p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
        .p0_in(p0_in),.p1_in(p1_in),.p2_in(p2_in),.p3_in(p3_in),
        .p0_out(p0_out),.p1_out(p1_out),.p2_out(p2_out),.p3_out(p3_out),
        .ext_int0_n(1'b1),.ext_int1_n(1'b1),.ext_t0(1'b1),.ext_t1(1'b1),
        .uart1_txd(1'b1),.uart1_rxd_out(1'b1),.uart1_rxd_oe(1'b0),
        .t2_output_enable(1'b0),.t2_out(1'b1),
        .serial_txd(serial_txd),.serial_rxd_out(serial_rxd_out),.serial_rxd_oe(serial_rxd_oe),
        .port_read_data(gpio_read_data),.int0_n(int0_n),.int1_n(int1_n),
        .t0_pin(t0_pin),.t1_pin(t1_pin),.serial_rxd(serial_rxd)
    );
    mcu8051_timer0 u_timer0 (
        .clk(clk),.rst_n(rst_n),.timer_tick(timer_tick),.t0_pin(t0_pin),.int0_n(int0_n),
        .tmod(tmod[3:0]),.tr0(tcon[4]),.tr1(tcon[6]),
        .write_tl(sfr_wr_en && mem_addr==8'h8a),.write_th(sfr_wr_en && mem_addr==8'h8c),
        .write_data(mem_wr_data),.tl0(tl0),.th0(th0),.overflow0(overflow0),.overflow1_split(overflow1_split)
    );
    mcu8051_timer1 u_timer1 (
        .clk(clk),.rst_n(rst_n),.timer_tick(timer_tick),.t1_pin(t1_pin),.int1_n(int1_n),
        .tmod(tmod[7:4]),.tr1(tcon[6]),.timer0_split_mode(tmod[1:0]==2'b11),
        .write_tl(sfr_wr_en && mem_addr==8'h8b),.write_th(sfr_wr_en && mem_addr==8'h8d),
        .write_data(mem_wr_data),.tl1(tl1),.th1(th1),.overflow1(overflow1)
    );
    mcu8051_serial u_uart0 (
        .clk(clk),.rst_n(rst_n),.clock_enable(1'b1),.scon(scon),.smod(pcon[7]),
        .timer1_overflow(overflow1),.rx_baud_overflow(1'b0),.tx_baud_overflow(1'b0),
        .rx_use_timer2(1'b0),.tx_use_timer2(1'b0),.rxd(serial_rxd),
        .sbuf_write(sfr_wr_en && mem_addr==8'h99),.sbuf_write_data(mem_wr_data),
        .sbuf_read_data(serial_sbuf),.txd(serial_txd),.rxd_out(serial_rxd_out),
        .rxd_output_enable(serial_rxd_oe),.ri_set(ri_set),.ti_set(ti_set),
        .rb8_write(rb8_write),.rb8_data(rb8_data),.tx_busy(),.rx_busy()
    );
    mcu8051_core #(.RAM_PIPELINED(RAM_PIPELINED),.MOVX_RI_PAGED(1)) u_core (
        .clk(clk),.rst_n(rst_n),.clock_enable(1'b1),.movx_page(p2_out),
        .rom_addr(rom_addr),.rom_data(rom_data),.pc(pc),
        .ram_addr(mem_addr),.ram_wr_data(mem_wr_data),.ram_rd_data(mem_rd_data),
        .ram_wr_en(mem_wr_en),.ram_rd_en(mem_rd_en),.ram_rmw(mem_rmw),.ram_indirect(mem_indirect),.ram_cs(),
        .ext_ram_addr(ext_ram_addr),.ext_ram_wr_data(ext_ram_wr_data),.ext_ram_rd_data(ext_ram_rd_data),
        .ext_ram_wr_en(ext_ram_wr_en),.ext_ram_rd_en(ext_ram_rd_en),
        .core_acc_we(core_acc_we),.core_acc_data(core_acc_data),
        .core_b_we(core_b_we),.core_b_data(core_b_data),
        .core_sp_we(core_sp_we),.core_sp_data(core_sp_data),
        .core_psw_we(core_psw_we),.core_psw_data(core_psw_data),
        .core_dptr_we(core_dptr_we),.core_dptr_data(core_dptr_data),
        .acc_in(acc),.b_in(b),.psw_in(psw),.sp_in(sp),.dptr_in(dptr),
        .irq_valid(irq_valid),.irq_vector(irq_vector),.irq_priority(irq_priority),.irq_source(irq_source),
        .irq_ack(irq_ack),.irq_ack_priority(irq_ack_priority),.irq_ack_source(irq_ack_source),
        .reti_complete(reti_complete)
    );
endmodule
