`timescale 1ns/1ps

// Byte RAM with a rising-edge write port and falling-edge read address port.
// PIPELINED_READ=0 returns data for the next rising edge.  PIPELINED_READ=1
// registers the M9K output on that rising edge; the CPU inserts a read wait
// state before consuming it. RAM contents survive CPU/system reset.
module mcu8051_memory #(
    parameter integer PIPELINED_READ = 0,
    parameter integer ADDR_WIDTH = 8,
    parameter integer DEPTH = 256,
    parameter INIT_FILE = ""
) (
    input wire clk,
    input wire [ADDR_WIDTH-1:0] rd_addr,
    output wire [7:0] rd_data,
    input wire wr_en,
    input wire [ADDR_WIDTH-1:0] wr_addr,
    input wire [7:0] wr_data
);
    generate if (1) begin: g_sim
        reg [7:0] mem [0:DEPTH-1];
        reg [7:0] read_data;
        reg [ADDR_WIDTH-1:0] read_addr_b;
        reg read_valid_b;
        integer i;
        initial begin
            read_data = 8'h00;
            read_addr_b = {ADDR_WIDTH{1'b0}};
            read_valid_b = 1'b0;
            for (i=0; i<DEPTH; i=i+1) mem[i] = 8'h00;
            if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
        end
        always @(posedge clk)
            if (wr_en && wr_addr < DEPTH) mem[wr_addr] <= wr_data;
        if (PIPELINED_READ == 0) begin: g_unregistered_read
            always @(negedge clk)
                read_data <= (rd_addr < DEPTH) ? mem[rd_addr] : 8'h00;
        end else begin: g_registered_read
            always @(negedge clk) begin
                read_addr_b <= rd_addr;
                read_valid_b <= (rd_addr < DEPTH);
            end
            always @(posedge clk)
                read_data <= read_valid_b ? mem[read_addr_b] : 8'h00;
        end
        assign rd_data = read_data;
    end endgenerate
endmodule
