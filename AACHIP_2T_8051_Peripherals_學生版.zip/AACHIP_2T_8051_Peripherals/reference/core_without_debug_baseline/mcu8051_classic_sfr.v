module mcu8051_classic_sfr (
    input  wire        clk,
    input  wire        rst_n,

    // ------------------------------------------------------------------------
    // 1. CPU 總線讀寫介面 (指令讀寫 SFR 專用，位址 0x80 ~ 0xFF)
    // ------------------------------------------------------------------------
    input  wire [7:0]  sfr_addr,
    input  wire [7:0]  sfr_wr_data,
    output reg  [7:0]  sfr_rd_data,
    input  wire        sfr_wr_en,
    input  wire        sfr_rmw,

    // ------------------------------------------------------------------------
    // 2. ALU/Core 硬體優先覆寫介面 (如 ALU 計算自動更新 PSW / ACC)
    // ------------------------------------------------------------------------
    input  wire        core_psw_we,
    input  wire [7:0]  core_psw_data,
    input  wire        core_acc_we,
    input  wire [7:0]  core_acc_data,
    input  wire        core_b_we,
    input  wire [7:0]  core_b_data,
    input  wire        core_sp_we,
    input  wire [7:0]  core_sp_data,
    input  wire        core_dptr_we,
    input  wire [15:0]  core_dptr_data,
    input  wire         int0_n,
    input  wire         int1_n,
    input  wire         timer0_overflow,
    input  wire         timer1_overflow,
    input  wire [7:0]   timer0_tl,
    input  wire [7:0]   timer0_th,
    input  wire [7:0]   timer1_tl,
    input  wire [7:0]   timer1_th,
    input  wire [7:0]   serial_sbuf,
    input  wire         serial_rb8_write,
    input  wire         serial_rb8_data,
    input  wire         serial_rx_irq,
    input  wire         serial_tx_irq,
    input  wire         irq_ack,
    input  wire [3:0]   irq_ack_source,
    // ------------------------------------------------------------------------
    // 3. 核心暫存器直接輸出 (直接接回 Core / ALU 供組合邏輯運算)
    // ------------------------------------------------------------------------
    output reg  [7:0]  acc,
    output reg  [7:0]  b,
    output reg  [7:0]  psw,
    output reg  [7:0]  sp,
    output wire [7:0]  dpl,
    output wire [7:0]  dph,
    output reg  [7:0]  ie,
    output reg  [7:0]  ip,
    output reg  [7:0]  tcon,
    output reg  [7:0]  tmod,
    output reg  [7:0]  scon,
    output reg  [7:0]  pcon,
    output wire [15:0] dptr,

    // ------------------------------------------------------------------------
    // 4. 外設 / GPIO Ports 界面
    // ------------------------------------------------------------------------
    input  wire [7:0]  port_read_data
);

    // SFR 位址映射定義
    localparam ADDR_P0  = 8'h80;
    localparam ADDR_SP  = 8'h81;
    localparam ADDR_DPL = 8'h82;
    localparam ADDR_DPH = 8'h83;
    localparam ADDR_PCON= 8'h87;
    localparam ADDR_P1  = 8'h90;
    localparam ADDR_TCON= 8'h88;
    localparam ADDR_TMOD= 8'h89;
    localparam ADDR_TL0 = 8'h8A;
    localparam ADDR_TL1 = 8'h8B;
    localparam ADDR_TH0 = 8'h8C;
    localparam ADDR_TH1 = 8'h8D;
    localparam ADDR_SCON= 8'h98;
    localparam ADDR_SBUF= 8'h99;
    localparam ADDR_IE  = 8'hA8;
    localparam ADDR_IP  = 8'hB8;
    localparam ADDR_P2  = 8'hA0;
    localparam ADDR_P3  = 8'hB0;
    localparam ADDR_PSW = 8'hD0;
    localparam ADDR_ACC = 8'hE0;
    localparam ADDR_B   = 8'hF0;

    reg [15:0] dp0;
    assign dptr=dp0;
    assign dpl=dp0[7:0];
    assign dph=dp0[15:8];

    reg int0_n_d, int1_n_d;
    wire int0_low = (int0_n === 1'b0);
    wire int1_low = (int1_n === 1'b0);
    wire int0_fall = int0_n_d && int0_low;
    wire int1_fall = int1_n_d && int1_low;
    wire timer0_event = (timer0_overflow === 1'b1);
    wire timer1_event = (timer1_overflow === 1'b1);
    wire serial_rx_event = (serial_rx_irq === 1'b1);
    wire serial_tx_event = (serial_tx_irq === 1'b1);
    wire bus_writes_acc = sfr_wr_en && (sfr_addr == ADDR_ACC) && !core_acc_we;
    wire [7:0] effective_acc = core_acc_we ? core_acc_data :
                               bus_writes_acc ? sfr_wr_data : acc;
    wire effective_parity = ^effective_acc;

    // ------------------------------------------------------------------------
    // SFR 時脈同步寫入邏輯 (包含硬體強制寫入優先權處理)
    // ------------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sp     <= 8'h07; // 8051 Reset 預設值
            acc    <= 8'h00;
            b      <= 8'h00;
            psw    <= 8'h00;
            dp0<=0;
            ie     <= 8'h00;
            ip     <= 8'h00;
            tcon   <= 8'h00;
            tmod   <= 8'h00;
            scon   <= 8'h00;
            pcon   <= 8'h00;
            int0_n_d <= 1'b1;
            int1_n_d <= 1'b1;
        end else begin
            int0_n_d <= !int0_low;
            int1_n_d <= !int1_low;

            // 最高優先權：ALU/Core 直接硬體更新
            if (core_psw_we) psw <= {core_psw_data[7:1], effective_parity};
            if (core_acc_we) acc <= core_acc_data;
            if (core_b_we)   b  <= core_b_data;
            if (core_sp_we)  sp <= core_sp_data;
			if (core_dptr_we) dp0<=core_dptr_data;
            // 次要優先權：指令總線寫入 (如 MOV direct, A)
            if (sfr_wr_en) begin
                case (sfr_addr)
                    ADDR_SP:  if (!core_sp_we) sp <= sfr_wr_data;
                    ADDR_DPL: dp0[7:0]<=sfr_wr_data;
                    ADDR_DPH: dp0[15:8]<=sfr_wr_data;
                    ADDR_B:   if (!core_b_we) b <= sfr_wr_data;
                    ADDR_TCON:tcon   <= sfr_wr_data;
                    ADDR_TMOD:tmod   <= sfr_wr_data;
                    ADDR_SCON:scon   <= sfr_wr_data;
                    ADDR_PCON:pcon <= sfr_wr_data & 8'h8f;
                    ADDR_IE:  ie     <= sfr_wr_data & 8'h9f;
                    ADDR_IP: ip <= sfr_wr_data & 8'h1f;
                    ADDR_PSW: if (!core_psw_we) psw <= {sfr_wr_data[7:1], effective_parity};
                    ADDR_ACC: if (!core_acc_we) acc <= sfr_wr_data;
                    default: ; // 未定義 SFR 位址寫入忽略
                endcase
            end
            // Hardware flag changes take priority over a simultaneous software
            // write to TCON/SCON, so an event cannot be lost at an instruction
            // writeback edge.
            if (irq_ack) begin
                case (irq_ack_source)
                    3'd0: if (tcon[0]) tcon[1] <= 1'b0;
                    3'd1: tcon[5] <= 1'b0;
                    3'd2: if (tcon[2]) tcon[3] <= 1'b0;
                    3'd3: tcon[7] <= 1'b0;
                    default: ;
                endcase
            end
            if (tcon[0]) begin
                if (int0_fall) tcon[1] <= 1'b1;
            end else tcon[1] <= int0_low;
            if (tcon[2]) begin
                if (int1_fall) tcon[3] <= 1'b1;
            end else tcon[3] <= int1_low;
            if (timer0_event) tcon[5] <= 1'b1;
            if (timer1_event) tcon[7] <= 1'b1;
            if (serial_rx_event) scon[0] <= 1'b1;
            if (serial_tx_event) scon[1] <= 1'b1;
            if (serial_rb8_write) scon[2] <= serial_rb8_data;
            // P is always the odd-parity indication of the effective ACC.
            if ((core_acc_we || bus_writes_acc) && !core_psw_we &&
                !(sfr_wr_en && sfr_addr == ADDR_PSW))
                psw[0] <= effective_parity;
        end
    end

    // ------------------------------------------------------------------------
    // SFR 組合邏輯讀取多路複用器 (Read MUX)
    // ------------------------------------------------------------------------
    always @(*) begin
        case (sfr_addr)
            ADDR_P0:  sfr_rd_data = port_read_data;
            ADDR_P1:  sfr_rd_data = port_read_data;
            ADDR_TCON:sfr_rd_data = tcon;
            ADDR_TMOD:sfr_rd_data = tmod;
            ADDR_TL0: sfr_rd_data = timer0_tl;
            ADDR_TL1: sfr_rd_data = timer1_tl;
            ADDR_TH0: sfr_rd_data = timer0_th;
            ADDR_TH1: sfr_rd_data = timer1_th;
            ADDR_SCON:sfr_rd_data = scon;
            ADDR_SBUF:sfr_rd_data = serial_sbuf;
            ADDR_PCON:sfr_rd_data = pcon;
            ADDR_IE:  sfr_rd_data = ie;
            ADDR_IP:  sfr_rd_data = ip;
            ADDR_P2:  sfr_rd_data = port_read_data;
            ADDR_P3:  sfr_rd_data = port_read_data;
            ADDR_SP:  sfr_rd_data = sp;
            ADDR_DPL: sfr_rd_data = dp0[7:0];
            ADDR_DPH: sfr_rd_data = dp0[15:8];
            ADDR_PSW: sfr_rd_data = psw;
            ADDR_ACC: sfr_rd_data = acc;
            ADDR_B:   sfr_rd_data = b;
            // Match the IDE reset image: unimplemented SFR slots read zero.
            default:  sfr_rd_data = 8'h00;
        endcase
    end

endmodule
