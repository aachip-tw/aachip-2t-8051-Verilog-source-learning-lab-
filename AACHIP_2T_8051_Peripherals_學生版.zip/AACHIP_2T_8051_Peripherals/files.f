rtl/mcu8051_gpio.v
rtl/mcu8051_timer0.v
rtl/mcu8051_timer1.v
rtl/mcu8051_serial.v
rtl/mcu8051_extended.v
rtl/mcu8051_sfr_bank.v
rtl/aachip_8051_peripherals.v
