#ifndef AACHIP_GPIO_MODES_H
#define AACHIP_GPIO_MODES_H
/* Byte-addressed mode SFRs; EIE is at E8; P3M1/P3M0 are F1/F2 (mode bytes use byte accesses). */
#define P0M1_ADDR 0xE1
#ifdef __SDCC_mcs51
__sfr __at (P0M1_ADDR) P0M1;
#endif
#define P0M0_ADDR 0xE2
#ifdef __SDCC_mcs51
__sfr __at (P0M0_ADDR) P0M0;
#endif
#define P1M1_ADDR 0xE3
#ifdef __SDCC_mcs51
__sfr __at (P1M1_ADDR) P1M1;
#endif
#define P1M0_ADDR 0xE4
#ifdef __SDCC_mcs51
__sfr __at (P1M0_ADDR) P1M0;
#endif
#define P2M1_ADDR 0xE5
#ifdef __SDCC_mcs51
__sfr __at (P2M1_ADDR) P2M1;
#endif
#define P2M0_ADDR 0xE6
#ifdef __SDCC_mcs51
__sfr __at (P2M0_ADDR) P2M0;
#endif
#define P3M1_ADDR 0xF1
#ifdef __SDCC_mcs51
__sfr __at (P3M1_ADDR) P3M1;
#endif
#define P3M0_ADDR 0xF2
#ifdef __SDCC_mcs51
__sfr __at (P3M0_ADDR) P3M0;
#endif
/* Per pin (M1,M0): 00 quasi; 01 push-pull; 10 input; 11 open-drain. */
#endif
