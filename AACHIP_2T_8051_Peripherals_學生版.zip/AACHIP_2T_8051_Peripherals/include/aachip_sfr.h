#ifndef AACHIP_SFR_H
#define AACHIP_SFR_H
/* Unified SFR byte addresses. EIE=E8, P3M1=F1, P3M0=F2. EIE supports bit access.
 * Use this header instead of a vendor 8051 header to avoid SFR name conflicts.
 * SDCC and Keil C51 declarations are supported. */
#if defined(__SDCC_mcs51)
#define AACHIP_SFR(name,addr) __sfr __at (addr) name
#elif defined(__C51__)
#define AACHIP_SFR(name,addr) sfr name = addr
#else
#define AACHIP_SFR(name,addr)
#endif
#define P0_ADDR 0x80
AACHIP_SFR(P0,P0_ADDR);
#define SP_ADDR 0x81
AACHIP_SFR(SP,SP_ADDR);
#define DPL0_ADDR 0x82
AACHIP_SFR(DPL0,DPL0_ADDR);
#define DPH0_ADDR 0x83
AACHIP_SFR(DPH0,DPH0_ADDR);
#define DPL1_ADDR 0x84
AACHIP_SFR(DPL1,DPL1_ADDR);
#define DPH1_ADDR 0x85
AACHIP_SFR(DPH1,DPH1_ADDR);
#define DPS_ADDR 0x86
AACHIP_SFR(DPS,DPS_ADDR);
#define PCON_ADDR 0x87
AACHIP_SFR(PCON,PCON_ADDR);
#define TCON_ADDR 0x88
AACHIP_SFR(TCON,TCON_ADDR);
#define TMOD_ADDR 0x89
AACHIP_SFR(TMOD,TMOD_ADDR);
#define TL0_ADDR 0x8A
AACHIP_SFR(TL0,TL0_ADDR);
#define TL1_ADDR 0x8B
AACHIP_SFR(TL1,TL1_ADDR);
#define TH0_ADDR 0x8C
AACHIP_SFR(TH0,TH0_ADDR);
#define TH1_ADDR 0x8D
AACHIP_SFR(TH1,TH1_ADDR);
#define CKCON_ADDR 0x8E
AACHIP_SFR(CKCON,CKCON_ADDR);
#define SPC_FNC_ADDR 0x8F
AACHIP_SFR(SPC_FNC,SPC_FNC_ADDR);
#define P1_ADDR 0x90
AACHIP_SFR(P1,P1_ADDR);
#define EXIF_ADDR 0x91
AACHIP_SFR(EXIF,EXIF_ADDR);
#define MPAGE_ADDR 0x92
AACHIP_SFR(MPAGE,MPAGE_ADDR);
#define SCON0_ADDR 0x98
AACHIP_SFR(SCON0,SCON0_ADDR);
#define SBUF0_ADDR 0x99
AACHIP_SFR(SBUF0,SBUF0_ADDR);
#define P2_ADDR 0xA0
AACHIP_SFR(P2,P2_ADDR);
#define IE_ADDR 0xA8
AACHIP_SFR(IE,IE_ADDR);
#define P3_ADDR 0xB0
AACHIP_SFR(P3,P3_ADDR);
#define IP_ADDR 0xB8
AACHIP_SFR(IP,IP_ADDR);
#define SCON1_ADDR 0xC0
AACHIP_SFR(SCON1,SCON1_ADDR);
#define SBUF1_ADDR 0xC1
AACHIP_SFR(SBUF1,SBUF1_ADDR);
#define ADCRL_ADDR 0xC2
AACHIP_SFR(ADCRL,ADCRL_ADDR);
#define ADCRH_ADDR 0xC3
AACHIP_SFR(ADCRH,ADCRH_ADDR);
#define T2CON_ADDR 0xC8
AACHIP_SFR(T2CON,T2CON_ADDR);
#define T2MOD_ADDR 0xC9
AACHIP_SFR(T2MOD,T2MOD_ADDR);
#define RCAP2L_ADDR 0xCA
AACHIP_SFR(RCAP2L,RCAP2L_ADDR);
#define RCAP2H_ADDR 0xCB
AACHIP_SFR(RCAP2H,RCAP2H_ADDR);
#define TL2_ADDR 0xCC
AACHIP_SFR(TL2,TL2_ADDR);
#define TH2_ADDR 0xCD
AACHIP_SFR(TH2,TH2_ADDR);
#define PSW_ADDR 0xD0
AACHIP_SFR(PSW,PSW_ADDR);
#define EICON_ADDR 0xD8
AACHIP_SFR(EICON,EICON_ADDR);
#define ACC_ADDR 0xE0
AACHIP_SFR(ACC,ACC_ADDR);
#define P0M1_ADDR 0xE1
AACHIP_SFR(P0M1,P0M1_ADDR);
#define P0M0_ADDR 0xE2
AACHIP_SFR(P0M0,P0M0_ADDR);
#define P1M1_ADDR 0xE3
AACHIP_SFR(P1M1,P1M1_ADDR);
#define P1M0_ADDR 0xE4
AACHIP_SFR(P1M0,P1M0_ADDR);
#define P2M1_ADDR 0xE5
AACHIP_SFR(P2M1,P2M1_ADDR);
#define P2M0_ADDR 0xE6
AACHIP_SFR(P2M0,P2M0_ADDR);
#define P3M1_ADDR 0xF1
AACHIP_SFR(P3M1,P3M1_ADDR);
#define P3M0_ADDR 0xF2
AACHIP_SFR(P3M0,P3M0_ADDR);
#define EIE_ADDR 0xE8
AACHIP_SFR(EIE,EIE_ADDR);
#define B_ADDR 0xF0
AACHIP_SFR(B,B_ADDR);
#define ADCCON0_ADDR 0xF8
AACHIP_SFR(ADCCON0,ADCCON0_ADDR);
#define EXPORTA_ADDR 0xF9
AACHIP_SFR(EXPORTA,EXPORTA_ADDR);
#define EXDDRB_ADDR 0xFA
AACHIP_SFR(EXDDRB,EXDDRB_ADDR);
#define EXPORTB_ADDR 0xFB
AACHIP_SFR(EXPORTB,EXPORTB_ADDR);
#define EXDDRC_ADDR 0xFC
AACHIP_SFR(EXDDRC,EXDDRC_ADDR);
#define EXPORTC_ADDR 0xFD
AACHIP_SFR(EXPORTC,EXPORTC_ADDR);
#define EXDDRD_ADDR 0xFE
AACHIP_SFR(EXDDRD,EXDDRD_ADDR);
#define EXPORTD_ADDR 0xFF
AACHIP_SFR(EXPORTD,EXPORTD_ADDR);
#define DPL DPL0
#define DPH DPH0
#define SCON SCON0
#define SBUF SBUF0
#define ADCS_MASK 0x40
#define ADCF_MASK 0x80

/* EIE byte E8: PX2..PX5 bits0..3, EX2..EX5 bits4..7. */
#define EIE_PX2_BIT_ADDR 0xE8
#if defined(__SDCC_mcs51)
__sbit __at (0xE8) EIE_PX2;
#elif defined(__C51__)
sbit EIE_PX2 = EIE ^ 0;
#endif
#define EIE_PX3_BIT_ADDR 0xE9
#if defined(__SDCC_mcs51)
__sbit __at (0xE9) EIE_PX3;
#elif defined(__C51__)
sbit EIE_PX3 = EIE ^ 1;
#endif
#define EIE_PX4_BIT_ADDR 0xEA
#if defined(__SDCC_mcs51)
__sbit __at (0xEA) EIE_PX4;
#elif defined(__C51__)
sbit EIE_PX4 = EIE ^ 2;
#endif
#define EIE_PX5_BIT_ADDR 0xEB
#if defined(__SDCC_mcs51)
__sbit __at (0xEB) EIE_PX5;
#elif defined(__C51__)
sbit EIE_PX5 = EIE ^ 3;
#endif
#define EIE_EX2_BIT_ADDR 0xEC
#if defined(__SDCC_mcs51)
__sbit __at (0xEC) EIE_EX2;
#elif defined(__C51__)
sbit EIE_EX2 = EIE ^ 4;
#endif
#define EIE_EX3_BIT_ADDR 0xED
#if defined(__SDCC_mcs51)
__sbit __at (0xED) EIE_EX3;
#elif defined(__C51__)
sbit EIE_EX3 = EIE ^ 5;
#endif
#define EIE_EX4_BIT_ADDR 0xEE
#if defined(__SDCC_mcs51)
__sbit __at (0xEE) EIE_EX4;
#elif defined(__C51__)
sbit EIE_EX4 = EIE ^ 6;
#endif
#define EIE_EX5_BIT_ADDR 0xEF
#if defined(__SDCC_mcs51)
__sbit __at (0xEF) EIE_EX5;
#elif defined(__C51__)
sbit EIE_EX5 = EIE ^ 7;
#endif
#endif
