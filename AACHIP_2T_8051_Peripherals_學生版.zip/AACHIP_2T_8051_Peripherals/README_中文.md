# AACHIP 2T 8051 周邊 RTL 獨立套件

## 學生先從這裡開始

**雙擊 `START_HERE.bat`**，依序檢查工具、編譯模擬、開啟 GTKWave。九個 C 範例已改用獨立的 AACHIP 教學 C Compiler 與 Python 組譯器，與先前 IDE 產物逐 byte 比對相同；不再包含完整 IDE DLL、授權或 USB 元件。

- [完整操作手冊：C → ASM → ROM → Verilog → GTKWave，以及一般邏輯合成](docs/8051實驗操作手冊.md)
- [九個範例、自動驗證結果與教材修正](docs/九個範例與驗證結果.md)
- [精簡教學引擎、交付內容與稽核範圍](docs/精簡教學引擎.md)
- `01_BUILD_SIM_ALL.bat`：重新編譯並驗證全部九例；`03_RUN_ONE.bat`：選一例並開啟波形。
- `02_OPEN_ALL_WAVES.bat`：開啟已成功產生的波形，每例都有 CLK、PC、ROM_ADDR、ROM_DATA、opcode 與相關周邊訊號。
- `04_SYNTHESIZE.bat`：Yosys 一般邏輯合成；`05_VERIFY_RTL.bat`：CPU／周邊回歸測試。

教材預設使用快速延遲設定，會重新編譯 C，並驗證完整動作。正式產物集中在 `build/lessons/`。學生版已移除歷史波形、舊編譯器測試副本、Proteus 工程、C# 編譯器來源與建置暫存；保留最新九課波形，可直接開啟。

本次一般邏輯合成已通過，但尚未進行特定 FPGA 的佈局繞線、時序分析或實板驗證。以下原有 CPU／周邊文件仍適用。

Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan. All rights reserved.

**僅供本公司內部員工學習與訓練使用。未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。** 詳見 [內部使用聲明](NOTICE_內部學習使用.txt)。

來源：`C:\20261031 8051 ip\20260911_aachip_2t_8051`。周邊整理：2026-11-10；新增基本核心整合：2026-11-11。

本套件提供兩種組裝：原周邊獨立套件，以及新加入的基本 8051 CPU 整合。兩者都沒有除錯器。周邊套件抽出 GPIO、Timer0／Counter0、Timer1／Counter1、UART0，以及擴充模組內的 Timer2／Counter2、UART1、ADC SPI、擴充 IO、外部中斷旗標；基本 CPU 整合則使用單 DPTR、128-byte IRAM、四 port、兩 timer、一 UART 與五個中斷來源。

**要組成基本 8051，請使用 `files_8051.f`，頂層選 `aachip_8051_top`，執行 `verify_8051.ps1`。** 詳見 [8051 核心與組裝說明](docs/8051核心與組裝說明.md)。程式 ROM 與 MOVX XRAM 由外層邏輯介面接入，內附 LED 程式與自我檢查韌體。此配置不含原 40-pin 的 ALE/PSEN 外接匯流排時序或 PCON 睡眠／停振，完整範圍及驗證限制見組裝說明。

## 目錄

| 路徑 | 用途 |
|---|---|
| rtl/ | 十三份加逐行中文教學註解的周邊、核心與整合 RTL |
| docs/RTL_詳細中文說明.md | 逐模組原理、介面、SFR、時序與限制 |
| reference/ | 原 CPU 頂層與板級頂層，僅供對照連線，不在 files.f |
| include/ | 原始 C 與組語 SFR 定義；含 CPU 專用定義，依用途選用 |
| files.f | 可直接用於 Icarus Verilog 的編譯清單 |
| files_8051.f | 基本 8051 核心整合編譯清單，排除擴充周邊 |
| tests/ | 獨立封裝的功能模擬 |
| source_manifest.json | 六份原始 RTL 的來源、目的地與 SHA-256 |
| build/ | 編譯及模擬紀錄 |
| verify.ps1 | 比對 RTL 雜湊、編譯、執行模擬 |
| verify_8051.ps1 | 基本配置無除錯控制檢查、兩種 RAM 配置的 CPU 整合模擬 |
| examples/ | P1.0 LED 範例組語及 readmemh 機器碼 |

原始六份周邊 RTL 初次抽出時逐位元組複製，只把含空白前綴的 `module mcu8051_sfr_bank.v` 改檔名為 `mcu8051_sfr_bank.v`，module 名稱未改。原周邊七檔的加註前版本保存在 `reference/rtl_before_teaching_comments/`，六份來源 RTL 的原始雜湊仍可核對；核心整合六檔的功能基準則保存在 `reference/core_without_debug_baseline/`。目前十三檔均有中文逐行註解，對應基準的程式行保持不變。新增的 `aachip_8051_peripherals.v` 提供不含 CPU 的 SFR 匯流排，`aachip_8051_top.v` 則提供基本 CPU 整合。原來源目錄沒有修改。

教學使用請先閱讀 [學生閱讀指南](docs/學生閱讀指南.md)，再從 `rtl/mcu8051_timer0.v` 開始。每個非空程式行正上方的 `// 【教學】` 說明該行用途、語法或為何需要這個條件；同一行原本包含多個敘述時，註解一併說明。空白行保留作分段，不重複註解既有中文標題與分隔線。

## 使用

在本目錄執行：

```powershell
.\verify.ps1
iverilog -g2012 -s aachip_8051_peripherals -o build/peripherals.vvp -c files.f
```

整合時選 `aachip_8051_peripherals` 為周邊頂層。`clk` 為唯一輸入時鐘，`rst_n` 為低有效非同步重置。SFR 讀取為組合邏輯，寫入在上升沿生效。`sfr_we` 應為單週期寫入脈波，位址及資料須符合 setup/hold。`sfr_rmw=1` 時 GPIO 讀鎖存值，一般讀取設 0。此介面不含 ready、wait 或 AXI/APB 協定；接 RISC-V 等主機時須自行加入位址映射與匯流排轉接。

一般連線將 `run_enable=1`。未使用獨立 `int0_n/int1_n/t0_pin/t1_pin` 時接 1，P3 輸入仍可提供相同功能。未使用的數位輸入應明確連接固定值。GPIO 的 `pN_out` 與 `pN_oe` 接到 FPGA 頂層 I/O 三態緩衝：

```verilog
assign p0[0] = p0_oe[0] ? p0_out[0] : 1'bz;
assign p0_in = p0;
```

須對各位元重複或使用 generate。準雙向／開漏模式放開腳位後，需要板上或 FPGA 設定的上拉。複用腳位的 latch 必須允許輸出，且 GPIO 模式也必須適合該功能。

`irq_pending` 是各來源已經個別 enable 篩選的請求；尚未套用全域 `IE[7]`，也沒有 CPU 優先權仲裁、跳轉向量或 RETI 狀態。接收端必須自行處理。詳見詳細說明。

## 驗證範圍

`verify.ps1` 先由 `verify_teaching.py` 核對十三份加註前基準、六份原周邊來源雜湊、2524 行非空程式碼的註解覆蓋與程式行完全一致，再編譯並模擬原周邊功能。`verify_8051.ps1` 另外驗證基本 CPU 整合與五個中斷向量。需要 Python、iverilog、vvp；詳細範圍請看各組裝文件。

這些是功能抽查，未宣稱已涵蓋所有 UART 接收相位、Timer 模式或 ADC 真實晶片交易。已新增 Yosys 一般邏輯合成並通過結構檢查；未執行 Quartus 綜合、佈局繞線、時序分析與實板驗證。原 SFR 檔案未定義 timescale，模擬器會顯示繼承 timescale 警告，不影響本次結果。
