// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns/1ps
// 【教學】這是透過同步 SFR 寫入介面使用的周邊，不包含 CPU 指令執行器。
// CPU-independent synchronous SFR peripheral subsystem.
// 【教學】這是新增封裝；其餘模組原始碼已加教學註解，Verilog token 與原始快照一致。
// Added wrapper; leaf RTL is a byte-identical snapshot of the source project.
// 【教學】宣告可重複使用的硬體模組 aachip_8051_peripherals，後面列出它對外的腳位；#(...) 的參數可在建立實例時決定硬體配置。
module aachip_8051_peripherals #(
 // 【教學】可覆寫的整數參數 TIMER_CLK_DIV：幾個有效 clk 才產生一次 timer_tick；預設 1，不能只憑 2T 名稱推定除 2；不是軟體運行中可寫的暫存器。
 parameter integer TIMER_CLK_DIV=1,
 // 【教學】可覆寫的整數參數 SERIAL_VARIABLE_BAUD_DIV：UART0 可變鮑率要累積的 timer 溢位數，預設 32；不是軟體運行中可寫的暫存器。
 parameter integer SERIAL_VARIABLE_BAUD_DIV=32,
 // 【教學】可覆寫的整數參數 SERIAL_MODE2_BAUD_DIV：UART0 Mode2 固定鮑率的 clk 分頻，預設 64；不是軟體運行中可寫的暫存器。
 parameter integer SERIAL_MODE2_BAUD_DIV=64,
 // 【教學】可覆寫的整數參數 SERIAL_MODE0_BAUD_DIV：UART0 Mode0 的半週期分頻，預設 1；不是軟體運行中可寫的暫存器。
 parameter integer SERIAL_MODE0_BAUD_DIV=1
// 【教學】結束參數清單並開始對外埠清單；參數決定配置，埠是運作時的訊號。
)(
 // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯；rst_n：低有效非同步重置，_n 表示 0 有效；run_enable：周邊運作使能；並非所有模組的總暫停開關。
 input wire clk,rst_n,run_enable,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_addr：8-bit SFR 位址，決定讀寫哪個控制暫存器；sfr_wdata：主機寫入 byte。
 input wire [7:0] sfr_addr,sfr_wdata,
 // 【教學】input 由外部驅動，模組只讀取。sfr_we：主機單拍寫入使能；sfr_rmw：讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
 input wire sfr_we,sfr_rmw,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_rdata：主機組合讀回資料。
 output wire [7:0] sfr_rdata,
 // 【教學】input 由外部驅動，模組只讀取。irq_ack：主機已接受中斷的確認脈波。
 input wire irq_ack,
 // 【教學】input 由外部驅動，模組只讀取；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。irq_ack_source：已接受的 0～12 中斷來源編號。
 input wire [3:0] irq_ack_source,
 // 【教學】output 將內部結果接給外層；[12:0] 指定向量位元範圍，例如 [7:0] 共 8 位。irq_pending：13 個分別經來源 enable 篩選的中斷請求，尚未套 EA。
 output wire [12:0] irq_pending,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ie：基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用；ip：基本中斷優先權設定；eie：擴充中斷允許／優先權；eicon：擴充控制與事件位，bit7 也作 UART1 SMOD。
 output wire [7:0] ie,ip,eie,eicon,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_in：P0 實際腳位輸入，與 latch 不同；p1_in：P1 實際腳位輸入，與 latch 不同；p2_in：P2 實際腳位輸入，與 latch 不同；p3_in：P3 實際腳位輸入，與 latch 不同。
 input wire [7:0] p0_in,p1_in,p2_in,p3_in,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_out：P0 送到腳位緩衝的輸出資料；p1_out：P1 送到腳位緩衝的輸出資料；p2_out：P2 送到腳位緩衝的輸出資料；p3_out：P3 送到腳位緩衝的輸出資料。
 output wire [7:0] p0_out,p1_out,p2_out,p3_out,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_oe：P0 每位輸出使能，1 驅動、0 釋放；p1_oe：P1 每位輸出使能，1 驅動、0 釋放；p2_oe：P2 每位輸出使能，1 驅動、0 釋放；p3_oe：P3 每位輸出使能，1 驅動、0 釋放。
 output wire [7:0] p0_oe,p1_oe,p2_oe,p3_oe,
 // 【教學】input 由外部驅動，模組只讀取。int0_n：低有效 INT0 輸入／合併後訊號；int1_n：低有效 INT1 輸入／合併後訊號；t0_pin：Counter0 外部下降沿輸入；t1_pin：Counter1 外部下降沿輸入。
 input wire int0_n,int1_n,t0_pin,t1_pin,
 // 【教學】input 由外部驅動，模組只讀取。adc_miso：ADC 回傳的序列資料。
 input wire adc_miso,
 // 【教學】output 將內部結果接給外層。adc_sclk：ADC SPI 時鐘，idle 高；adc_mosi：送到 ADC 的序列命令；adc_cs_n：低有效 ADC 晶片選取。
 output wire adc_sclk,adc_mosi,adc_cs_n,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_a_in：擴充 port A 外部輸入值；export_b_in：擴充 port B 外部輸入值；export_c_in：擴充 port C 外部輸入值；export_d_in：擴充 port D 外部輸入值。
 input wire [7:0] export_a_in,export_b_in,export_c_in,export_d_in,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_a：擴充 port A 輸出 latch 的資料；export_b：擴充 port B 輸出 latch 的資料；export_c：擴充 port C 輸出 latch 的資料；export_d：擴充 port D 輸出 latch 的資料。
 output wire [7:0] export_a,export_b,export_c,export_d,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_b_oe：擴充 port B 輸出使能，1 輸出、0 輸入；export_c_oe：擴充 port C 輸出使能，1 輸出、0 輸入；export_d_oe：擴充 port D 輸出使能，1 輸出、0 輸入。
 output wire [7:0] export_b_oe,export_c_oe,export_d_oe
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
 // 【教學】把外部地址／資料接成原頂層使用的內部名稱，以沿用已核對的周邊接線；wire 宣告時的 = 是持續接線，不是只在上電賦值一次。
 wire [7:0] sfr_bus_addr=sfr_addr,sfr_bus_wr_data=sfr_wdata;
 // 【教學】將主機寫入使能接到共用 SFR 匯流排；只有寫入那拍才應為 1，否則同一資料會連續重寫。
 wire sfr_bus_wr_en=sfr_we;
 // 【教學】把主機的讀改寫意圖傳給 GPIO，讓它在讀 pin 與讀 latch 間作正確選擇。
 wire mem_rmw=sfr_rmw;
 // 【教學】把主機允許運作的訊號接到 timer/UART enable；這只是接線，不會以 AND 閘直接切割 clk。
 wire peripheral_enable=run_enable;
 // 【教學】建立原頂層沿用的寫入名稱；它還會在各子模組接線處與自己的 SFR 位址比對，不是任一寫入都改 timer。
 wire timer_write=sfr_we;
 // 【教學】原 CPU 的中斷確認現在改由外部主機提供；轉接名稱以沿用 SFR bank 的清旗標接線。
 wire core_irq_ack=irq_ack;
 // 【教學】保留完整四位中斷來源編號，可表示 0～12；若只接三位，來源 8 以上就會與基本中斷混淆。
 wire [3:0] core_irq_source=irq_ack_source;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。base_sfr_rd_data：基本 SFR bank 的讀回資料；extended_sfr_data：擴充模組的讀回資料。
 wire [7:0] base_sfr_rd_data,extended_sfr_data;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。extended_sfr_select：讀位址由擴充模組負責時為 1。
 wire extended_sfr_select;
 // 【教學】讀位址歸 extended 所有時優先選擴充讀值，否則回基本 bank；這樣兩組模組可共用同一 byte SFR 空間。
 assign sfr_rdata=extended_sfr_select?extended_sfr_data:base_sfr_rd_data;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ckcon：時鐘與原 CPU 等待控制；spc_fnc：原系統特殊功能控制，獨立套件只保留暫存器；mpage：原 CPU MOVX 分頁值，獨立套件不操作記憶體；exif：擴充外部中斷事件旗標；tcon：T0/T1 啟動及外部／計時中斷旗標；tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；scon：UART 模式、REN、SM2、TB8 和 RI/TI/RB8；pcon：電源／控制影像，bit7 是 UART0 SMOD。
 wire [7:0] ckcon,spc_fnc,mpage,exif,tcon,tmod,scon,pcon;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。timer2_irq：Timer2 TF2 或 EXF2 請求；serial1_irq：UART1 RI 或 TI 請求；uart1_txd：UART1 傳送值，後續接 P1.3；uart1_rxd_out：UART1 Mode0 同步資料輸出；uart1_rxd_oe：UART1 Mode0 輸出使能。
 wire timer2_irq,serial1_irq,uart1_txd,uart1_rxd_out,uart1_rxd_oe;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。t2_output_enable：Timer2 可複用到 P1.0 的允許；t2_out：Timer2 clock-out 方波資料；t2_rx_tick：T2 送到 UART0 RX 的溢位事件；t2_tx_tick：T2 送到 UART0 TX 的溢位事件；t2_rx_select：RCLK 控制 UART0 RX 是否用 T2；t2_tx_select：TCLK 控制 UART0 TX 是否用 T2。
 wire t2_output_enable,t2_out,t2_rx_tick,t2_tx_tick,t2_rx_select,t2_tx_select;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tl0：Timer0 低 byte 的儲存值；th0：Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer；tl1：Timer1 低 byte 的儲存值；th1：Timer1 高 byte／Mode2 重載值；gpio_read_data：GPIO 已完成 RMW/pin 選擇的讀值；serial_sbuf：UART0 接收 byte。
 wire [7:0] tl0,th0,tl1,th1,gpio_read_data,serial_sbuf;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。effective_int0_n：GPIO 合併獨立輸入與 P3.2 後的低有效 INT0；effective_int1_n：GPIO 合併獨立輸入與 P3.3 後的低有效 INT1；effective_t0：GPIO 合併獨立 T0 與 P3.4 後的計數輸入；effective_t1：GPIO 合併獨立 T1 與 P3.5 後的計數輸入。
 wire effective_int0_n,effective_int1_n,effective_t0,effective_t1;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。serial_rxd_pin：由 GPIO 送到 UART0 的實際 RXD；serial_txd_pin：由 UART0 送到 GPIO 的 TXD 資料；serial_rxd_out：UART0 Mode0 資料供 P3.0 複用；serial_rxd_oe：UART0 Mode0 資料輸出允許。
 wire serial_rxd_pin,serial_txd_pin,serial_rxd_out,serial_rxd_oe;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。serial_ri_set：UART0 要求將 SCON.RI 設 1 的事件；serial_ti_set：UART0 要求將 SCON.TI 設 1 的事件；serial_rb8_write：UART0 要求更新 RB8 的事件；serial_rb8_data：UART0 RB8 的新值。
 wire serial_ri_set,serial_ti_set,serial_rb8_write,serial_rb8_data;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。serial_tx_busy：UART0 傳送忙碌監測線；serial_rx_busy：UART0 接收忙碌監測線。
 wire serial_tx_busy,serial_rx_busy;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。timer0_internal_overflow：真正 Timer0 的溢位脈波；timer1_internal_overflow：真正 Timer1 的溢位脈波，亦供 UART 鮑率；timer0_split_overflow：T0 Mode3 中 TH0 的溢位脈波，外層用它設定 TF1。
 wire timer0_internal_overflow,timer1_internal_overflow,timer0_split_overflow;
 // 【教學】獨立套件只使用真實 Timer0 溢位，不再混入原 CPU 頂層額外的測試事件。
 wire timer0_event=timer0_internal_overflow;
 // 【教學】T0 Mode3 時架構上的 TF1 改由 TH0 溢位提供；真正 Timer1 溢位仍保留給 UART，不應混成同一事件。
 wire timer1_event=(tmod[1:0]==2'b11)?timer0_split_overflow:timer1_internal_overflow;
 // 【教學】原 CPU 允許額外注入序列事件；獨立周邊封裝沒有該外部輸入，因此接 0，只保留真實 UART 事件。
 wire serial_rx_irq=1'b0,serial_tx_irq=1'b0;
 // 【教學】用向上取 log2 算分頻計數器位寬，且至少留 1 位，避免參數=1 時出現 [-1:0] 的非法／反直覺範圍。
 localparam integer DIV_W=(TIMER_CLK_DIV<=1)?1:$clog2(TIMER_CLK_DIV);
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[DIV_W-1:0] 指定向量位元範圍，例如 [7:0] 共 8 位。timer_div_count：系統 timer_tick 的分頻相位計數。
 reg [DIV_W-1:0] timer_div_count;
 // 【教學】分頻=1 每拍允許，否則從 0 數到 DIV-1 時發 tick；這是計數使能，不是把邏輯輸出當新時鐘。
 wire timer_tick=(TIMER_CLK_DIV<=1)?1'b1:(timer_div_count==TIMER_CLK_DIV-1);
 // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
 always @(posedge clk or negedge rst_n)
  // 【教學】非同步低有效重置分頻相位，使第一次 tick 的等待長度可預期。
  if(!rst_n)timer_div_count<=0;
  // 【教學】未重置且 run_enable=1 才推進分頻相位；停用時保持原計數，而不是自行清零。
  else if(run_enable)begin
   // 【教學】到分頻終點就回 0，形成週期性計數；不是溢位後任由二進位自然回捲，因為 DIV 不一定是 2 的次方。
   if(timer_tick)timer_div_count<=0;
   // 【教學】還未到終點就加一；和前一行一起構成任意整數分頻的 clock-enable 產生器。
   else timer_div_count<=timer_div_count+1'b1;
  // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
  end
 // 【教學】每項請求先套個別 enable；全域 EA 與 CPU 優先權仲裁由外部主機負責。
 // Enable-qualified requests. Global EA and CPU priority arbitration are external.
 // 【教學】開始由高到低串接 13 個中斷來源：bit12 是 EICON 事件，bit11/10 為 EX5/EX4；每項先與自己的 enable 做 AND。
 assign irq_pending={eicon[3]&eicon[0],exif[7]&eie[7],exif[6]&eie[6],
  // 【教學】接續 bit9～6：EX3、EX2、UART1、EICON 事件；串接順序決定 irq_ack_source 編號，不能任意交換。
  exif[5]&eie[5],exif[4]&eie[4],serial1_irq&ie[6],eicon[4]&eicon[5],
  // 【教學】接續 bit5～3：T2、UART0、T1；UART0 的 RI/TI 先 OR 再套 IE[4]，任一旗標都可請求。
  timer2_irq&ie[5],(scon[0]|scon[1])&ie[4],tcon[7]&ie[3],
  // 【教學】最後是 bit2 INT1、bit1 T0、bit0 INT0；此處沒有套全域 EA=IE[7]，也不含優先權仲裁，主機需另外處理。
  tcon[3]&ie[2],tcon[5]&ie[1],tcon[1]&ie[0]};
    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。 EXTENDED=1 允許 P1 的 UART1/Timer2 複用。
    mcu8051_gpio #(.EXTENDED(1)) u_gpio (
        // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；sfr_addr(sfr_bus_addr)：把子模組的 sfr_addr 埠接到外層 sfr_bus_addr，用途為8-bit SFR 位址，決定讀寫哪個控制暫存器。
        .clk(clk), .rst_n(rst_n), .sfr_addr(sfr_bus_addr),
        // 【教學】具名接線不依埠的排列順序。sfr_write_data(sfr_bus_wr_data)：把子模組的 sfr_write_data 埠接到外層 sfr_bus_wr_data，用途為GPIO 寫入資料；sfr_write_enable(timer_write)：把子模組的 sfr_write_enable 埠接到外層 timer_write，用途為GPIO 寫入允許。
        .sfr_write_data(sfr_bus_wr_data), .sfr_write_enable(timer_write),
        // 【教學】具名接線不依埠的排列順序。sfr_rmw(mem_rmw)：把子模組的 sfr_rmw 埠接到外層 mem_rmw，用途為讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料；p0_oe(p0_oe)：把子模組的 p0_oe 埠接到外層 p0_oe，用途為P0 每位輸出使能，1 驅動、0 釋放；p1_oe(p1_oe)：把子模組的 p1_oe 埠接到外層 p1_oe，用途為P1 每位輸出使能，1 驅動、0 釋放；p2_oe(p2_oe)：把子模組的 p2_oe 埠接到外層 p2_oe，用途為P2 每位輸出使能，1 驅動、0 釋放；p3_oe(p3_oe)：把子模組的 p3_oe 埠接到外層 p3_oe，用途為P3 每位輸出使能，1 驅動、0 釋放。
        .sfr_rmw(mem_rmw), .p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
        // 【教學】具名接線不依埠的排列順序。p0_in(p0_in)：把子模組的 p0_in 埠接到外層 p0_in，用途為P0 實際腳位輸入，與 latch 不同；p1_in(p1_in)：把子模組的 p1_in 埠接到外層 p1_in，用途為P1 實際腳位輸入，與 latch 不同。
        .p0_in(p0_in), .p1_in(p1_in),
        // 【教學】具名接線不依埠的排列順序。p2_in(p2_in)：把子模組的 p2_in 埠接到外層 p2_in，用途為P2 實際腳位輸入，與 latch 不同；p3_in(p3_in)：把子模組的 p3_in 埠接到外層 p3_in，用途為P3 實際腳位輸入，與 latch 不同；ext_int0_n(int0_n)：把子模組的 ext_int0_n 埠接到外層 int0_n，用途為獨立 INT0 輸入，未用接 1。
        .p2_in(p2_in), .p3_in(p3_in), .ext_int0_n(int0_n),
        // 【教學】具名接線不依埠的排列順序。ext_int1_n(int1_n)：把子模組的 ext_int1_n 埠接到外層 int1_n，用途為獨立 INT1 輸入，未用接 1；ext_t0(t0_pin)：把子模組的 ext_t0 埠接到外層 t0_pin，用途為獨立 Counter0 輸入，未用接 1；ext_t1(t1_pin)：把子模組的 ext_t1 埠接到外層 t1_pin，用途為獨立 Counter1 輸入，未用接 1。
        .ext_int1_n(int1_n), .ext_t0(t0_pin), .ext_t1(t1_pin),
        // 【教學】具名接線不依埠的排列順序。uart1_txd(uart1_txd)：把子模組的 uart1_txd 埠接到外層 uart1_txd，用途為UART1 傳送值，後續接 P1.3；uart1_rxd_out(uart1_rxd_out)：把子模組的 uart1_rxd_out 埠接到外層 uart1_rxd_out，用途為UART1 Mode0 同步資料輸出；uart1_rxd_oe(uart1_rxd_oe)：把子模組的 uart1_rxd_oe 埠接到外層 uart1_rxd_oe，用途為UART1 Mode0 輸出使能。
        .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
        // 【教學】具名接線不依埠的排列順序。t2_output_enable(t2_output_enable)：把子模組的 t2_output_enable 埠接到外層 t2_output_enable，用途為Timer2 可複用到 P1.0 的允許；t2_out(t2_out)：把子模組的 t2_out 埠接到外層 t2_out，用途為Timer2 clock-out 方波資料。
        .t2_output_enable(t2_output_enable),.t2_out(t2_out),
        // 【教學】具名接線不依埠的排列順序。serial_txd(serial_txd_pin)：把子模組的 serial_txd 埠接到外層 serial_txd_pin，用途為UART0 傳送資料供 P3.1 複用；serial_rxd_out(serial_rxd_out)：把子模組的 serial_rxd_out 埠接到外層 serial_rxd_out，用途為UART0 Mode0 資料供 P3.0 複用。
        .serial_txd(serial_txd_pin), .serial_rxd_out(serial_rxd_out),
        // 【教學】具名接線不依埠的排列順序。serial_rxd_oe(serial_rxd_oe)：把子模組的 serial_rxd_oe 埠接到外層 serial_rxd_oe，用途為UART0 Mode0 資料輸出允許；p0_out(p0_out)：把子模組的 p0_out 埠接到外層 p0_out，用途為P0 送到腳位緩衝的輸出資料；p1_out(p1_out)：把子模組的 p1_out 埠接到外層 p1_out，用途為P1 送到腳位緩衝的輸出資料。
        .serial_rxd_oe(serial_rxd_oe), .p0_out(p0_out), .p1_out(p1_out),
        // 【教學】具名接線不依埠的排列順序。p2_out(p2_out)：把子模組的 p2_out 埠接到外層 p2_out，用途為P2 送到腳位緩衝的輸出資料；p3_out(p3_out)：把子模組的 p3_out 埠接到外層 p3_out，用途為P3 送到腳位緩衝的輸出資料；port_read_data(gpio_read_data)：把子模組的 port_read_data 埠接到外層 gpio_read_data，用途為GPIO 位址解碼後的讀回值。
        .p2_out(p2_out), .p3_out(p3_out), .port_read_data(gpio_read_data),
        // 【教學】具名接線不依埠的排列順序。int0_n(effective_int0_n)：把子模組的 int0_n 埠接到外層 effective_int0_n，用途為低有效 INT0 輸入／合併後訊號；int1_n(effective_int1_n)：把子模組的 int1_n 埠接到外層 effective_int1_n，用途為低有效 INT1 輸入／合併後訊號。
        .int0_n(effective_int0_n), .int1_n(effective_int1_n),
        // 【教學】具名接線不依埠的排列順序。t0_pin(effective_t0)：把子模組的 t0_pin 埠接到外層 effective_t0，用途為Counter0 外部下降沿輸入；t1_pin(effective_t1)：把子模組的 t1_pin 埠接到外層 effective_t1，用途為Counter1 外部下降沿輸入；serial_rxd(serial_rxd_pin)：把子模組的 serial_rxd 埠接到外層 serial_rxd_pin，用途為由 P3.0 取得的 UART0 接收資料。
        .t0_pin(effective_t0), .t1_pin(effective_t1), .serial_rxd(serial_rxd_pin)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
    mcu8051_timer0 u_timer0 (
        // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；timer_tick((ckcon[3]?peripheral_enable:timer_tick & peripheral_enable))：CKCON 選每拍或分頻 tick，再與運作允許結合；counter 外部邊沿路徑不受此 tick 封鎖。
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[3]?peripheral_enable:timer_tick & peripheral_enable)),
        // 【教學】具名接線不依埠的排列順序。t0_pin(effective_t0)：把子模組的 t0_pin 埠接到外層 effective_t0，用途為Counter0 外部下降沿輸入；int0_n(effective_int0_n)：把子模組的 int0_n 埠接到外層 effective_int0_n，用途為低有效 INT0 輸入／合併後訊號；tmod(tmod[3:0])：把子模組的 tmod 埠接到外層 tmod[3:0]，用途為計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
        .t0_pin(effective_t0), .int0_n(effective_int0_n), .tmod(tmod[3:0]),
        // 【教學】具名接線不依埠的排列順序。tr0(tcon[4])：把子模組的 tr0 埠接到外層 tcon[4]，用途為Timer0 啟動允許；tr1(tcon[6])：把子模組的 tr1 埠接到外層 tcon[6]，用途為Timer1 啟動；T0 Mode3 也用來控制 TH0。
        .tr0(tcon[4]), .tr1(tcon[6]),
        // 【教學】具名接線不依埠的排列順序。write_tl(timer_write && sfr_bus_addr == 8'h8A)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波。
        .write_tl(timer_write && sfr_bus_addr == 8'h8A),
        // 【教學】具名接線不依埠的排列順序。write_th(timer_write && sfr_bus_addr == 8'h8C)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波；write_data(sfr_bus_wr_data)：把子模組的 write_data 埠接到外層 sfr_bus_wr_data，用途為計數器寫入 byte。
        .write_th(timer_write && sfr_bus_addr == 8'h8C), .write_data(sfr_bus_wr_data),
        // 【教學】具名接線不依埠的排列順序。tl0(tl0)：把子模組的 tl0 埠接到外層 tl0，用途為Timer0 低 byte 的儲存值；th0(th0)：把子模組的 th0 埠接到外層 th0，用途為Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer；overflow0(timer0_internal_overflow)：把子模組的 overflow0 埠接到外層 timer0_internal_overflow，用途為Timer0 單拍溢位事件。
        .tl0(tl0), .th0(th0), .overflow0(timer0_internal_overflow),
        // 【教學】具名接線不依埠的排列順序。overflow1_split(timer0_split_overflow)：把子模組的 overflow1_split 埠接到外層 timer0_split_overflow，用途為Timer0 split 的 TH0 溢位，用於 TF1。
        .overflow1_split(timer0_split_overflow)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
    mcu8051_timer1 u_timer1 (
        // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；timer_tick((ckcon[4]?peripheral_enable:timer_tick & peripheral_enable))：CKCON 選每拍或分頻 tick，再與運作允許結合；counter 外部邊沿路徑不受此 tick 封鎖。
        .clk(clk), .rst_n(rst_n), .timer_tick((ckcon[4]?peripheral_enable:timer_tick & peripheral_enable)),
        // 【教學】具名接線不依埠的排列順序。t1_pin(effective_t1)：把子模組的 t1_pin 埠接到外層 effective_t1，用途為Counter1 外部下降沿輸入；int1_n(effective_int1_n)：把子模組的 int1_n 埠接到外層 effective_int1_n，用途為低有效 INT1 輸入／合併後訊號；tmod(tmod[7:4])：把子模組的 tmod 埠接到外層 tmod[7:4]，用途為計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
        .t1_pin(effective_t1), .int1_n(effective_int1_n), .tmod(tmod[7:4]),
        // 【教學】具名接線不依埠的排列順序。tr1(tcon[6])：把子模組的 tr1 埠接到外層 tcon[6]，用途為Timer1 啟動；T0 Mode3 也用來控制 TH0；timer0_split_mode(tmod[1:0] == 2'b11)：傳遞 split 狀態，但此 Timer1 版本內未使用該輸入。
        .tr1(tcon[6]), .timer0_split_mode(tmod[1:0] == 2'b11),
        // 【教學】具名接線不依埠的排列順序。write_tl(timer_write && sfr_bus_addr == 8'h8B)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波。
        .write_tl(timer_write && sfr_bus_addr == 8'h8B),
        // 【教學】具名接線不依埠的排列順序。write_th(timer_write && sfr_bus_addr == 8'h8D)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波；write_data(sfr_bus_wr_data)：把子模組的 write_data 埠接到外層 sfr_bus_wr_data，用途為計數器寫入 byte。
        .write_th(timer_write && sfr_bus_addr == 8'h8D), .write_data(sfr_bus_wr_data),
        // 【教學】具名接線不依埠的排列順序。tl1(tl1)：把子模組的 tl1 埠接到外層 tl1，用途為Timer1 低 byte 的儲存值；th1(th1)：把子模組的 th1 埠接到外層 th1，用途為Timer1 高 byte／Mode2 重載值；overflow1(timer1_internal_overflow)：把子模組的 overflow1 埠接到外層 timer1_internal_overflow，用途為Timer1 單拍溢位事件，也供 UART 鮑率使用。
        .tl1(tl1), .th1(th1), .overflow1(timer1_internal_overflow)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
    mcu8051_serial #(
        // 【教學】具名接線不依埠的排列順序。SEPARATE_BAUD(1)：覆寫子模組的參數，是否啟用 RX/TX 分開的鮑率來源，參數在 elaboration 決定硬體配置。
        .SEPARATE_BAUD(1),
        // 【教學】具名接線不依埠的排列順序。VARIABLE_BAUD_DIV(SERIAL_VARIABLE_BAUD_DIV)：覆寫子模組的參數，一般可變鮑率分頻；用 Timer2 時其衍生位寬必須容納 0～15。
        .VARIABLE_BAUD_DIV(SERIAL_VARIABLE_BAUD_DIV),
        // 【教學】具名接線不依埠的排列順序。MODE2_BAUD_DIV(SERIAL_MODE2_BAUD_DIV)：覆寫子模組的參數，Mode2 固定鮑率分頻，SMOD=1 再減半。
        .MODE2_BAUD_DIV(SERIAL_MODE2_BAUD_DIV),
        // 【教學】具名接線不依埠的排列順序。MODE0_BAUD_DIV(SERIAL_MODE0_BAUD_DIV)：覆寫子模組的參數，Mode0 半週期分頻；兩個事件才移一個 bit。
        .MODE0_BAUD_DIV(SERIAL_MODE0_BAUD_DIV)
    // 【教學】結束 UART0 參數覆寫，命名實例 u_serial，並開始連接它的訊號埠；這是在配置硬體而不是呼叫軟體副程式。
    ) u_serial (
        // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；clock_enable(peripheral_enable)：把子模組的 clock_enable 埠接到外層 peripheral_enable，用途為UART 的狀態推進允許。
        .clk(clk), .rst_n(rst_n), .clock_enable(peripheral_enable),
        // 【教學】具名接線不依埠的排列順序。scon(scon)：把子模組的 scon 埠接到外層 scon，用途為UART 模式、REN、SM2、TB8 和 RI/TI/RB8；smod(pcon[7])：把子模組的 smod 埠接到外層 pcon[7]，用途為鮑率倍增選擇，藉分頻減半達成。
        .scon(scon), .smod(pcon[7]),
        // 【教學】具名接線不依埠的排列順序。timer1_overflow(timer1_internal_overflow)：把子模組的 timer1_overflow 埠接到外層 timer1_internal_overflow，用途為Timer1 的單拍溢位，作 UART 鮑率來源。
        .timer1_overflow(timer1_internal_overflow),
        // 【教學】具名接線不依埠的排列順序。rx_baud_overflow(t2_rx_select?t2_rx_tick:timer1_internal_overflow)：由 T2 選擇位決定使用 T2 或真實 T1 溢位。
        .rx_baud_overflow(t2_rx_select?t2_rx_tick:timer1_internal_overflow),
        // 【教學】具名接線不依埠的排列順序。tx_baud_overflow(t2_tx_select?t2_tx_tick:timer1_internal_overflow)：由 T2 選擇位決定使用 T2 或真實 T1 溢位。
        .tx_baud_overflow(t2_tx_select?t2_tx_tick:timer1_internal_overflow),
        // 【教學】具名接線不依埠的排列順序。rx_use_timer2(t2_rx_select)：選擇是否採 Timer2 的固定除16，與鮑率來源一致；tx_use_timer2(t2_tx_select)：選擇是否採 Timer2 的固定除16，與鮑率來源一致；rxd(serial_rxd_pin)：把子模組的 rxd 埠接到外層 serial_rxd_pin，用途為串列接收輸入；Mode0 也是同步取樣資料。
        .rx_use_timer2(t2_rx_select),.tx_use_timer2(t2_tx_select),.rxd(serial_rxd_pin),
        // 【教學】具名接線不依埠的排列順序。sbuf_write(timer_write && sfr_bus_addr == 8'h99)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波。
        .sbuf_write(timer_write && sfr_bus_addr == 8'h99),
        // 【教學】具名接線不依埠的排列順序。sbuf_write_data(sfr_bus_wr_data)：把子模組的 sbuf_write_data 埠接到外層 sfr_bus_wr_data，用途為要送出的 byte；sbuf_read_data(serial_sbuf)：把子模組的 sbuf_read_data 埠接到外層 serial_sbuf，用途為最近收到的 byte，無 FIFO。
        .sbuf_write_data(sfr_bus_wr_data), .sbuf_read_data(serial_sbuf),
        // 【教學】具名接線不依埠的排列順序。txd(serial_txd_pin)：把子模組的 txd 埠接到外層 serial_txd_pin，用途為串列 TX 輸出，Mode0 改作同步移位時鐘；rxd_out(serial_rxd_out)：把子模組的 rxd_out 埠接到外層 serial_rxd_out，用途為Mode0 從 RXD 腳送出的資料。
        .txd(serial_txd_pin), .rxd_out(serial_rxd_out),
        // 【教學】具名接線不依埠的排列順序。rxd_output_enable(serial_rxd_oe)：把子模組的 rxd_output_enable 埠接到外層 serial_rxd_oe，用途為Mode0 允許 RXD 腳輸出資料；ri_set(serial_ri_set)：把子模組的 ri_set 埠接到外層 serial_ri_set，用途為要求外部 SCON 設 RI 的事件。
        .rxd_output_enable(serial_rxd_oe), .ri_set(serial_ri_set),
        // 【教學】具名接線不依埠的排列順序。ti_set(serial_ti_set)：把子模組的 ti_set 埠接到外層 serial_ti_set，用途為要求外部 SCON 設 TI 的事件；rb8_write(serial_rb8_write)：把子模組的 rb8_write 埠接到外層 serial_rb8_write，用途為RB8 資料有效更新事件。
        .ti_set(serial_ti_set), .rb8_write(serial_rb8_write),
        // 【教學】具名接線不依埠的排列順序。rb8_data(serial_rb8_data)：把子模組的 rb8_data 埠接到外層 serial_rb8_data，用途為接收第九位或 Mode1 的停止位；tx_busy(serial_tx_busy)：把子模組的 tx_busy 埠接到外層 serial_tx_busy，用途為正在傳送，阻止新資料覆蓋 frame；rx_busy(serial_rx_busy)：把子模組的 rx_busy 埠接到外層 serial_rx_busy，用途為正在接收 frame。
        .rb8_data(serial_rb8_data), .tx_busy(serial_tx_busy), .rx_busy(serial_rx_busy)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // ------------------------------------------------------------------------
    // 2. 實例化獨立 SFR 暫存器庫 (mcu8051_sfr_bank)
    // ------------------------------------------------------------------------
    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
    mcu8051_sfr_bank u_sfr_bank (
        // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯。
        .clk           (clk),
        // 【教學】具名接線不依埠的排列順序。rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效。
        .rst_n         (rst_n),
		
        // 指令總線存取介面
        // 【教學】具名接線不依埠的排列順序。sfr_addr(sfr_bus_addr)：把子模組的 sfr_addr 埠接到外層 sfr_bus_addr，用途為8-bit SFR 位址，決定讀寫哪個控制暫存器。
        .sfr_addr      (sfr_bus_addr),
        // 【教學】具名接線不依埠的排列順序。sfr_wr_data(sfr_bus_wr_data)：把子模組的 sfr_wr_data 埠接到外層 sfr_bus_wr_data，用途為SFR bank 寫入資料。
        .sfr_wr_data   (sfr_bus_wr_data),
        // 【教學】具名接線不依埠的排列順序。sfr_rd_data(base_sfr_rd_data)：把子模組的 sfr_rd_data 埠接到外層 base_sfr_rd_data，用途為基本 SFR 的組合讀回資料。
        .sfr_rd_data   (base_sfr_rd_data),
        // 【教學】具名接線不依埠的排列順序。sfr_wr_en(sfr_bus_wr_en)：把子模組的 sfr_wr_en 埠接到外層 sfr_bus_wr_en，用途為SFR bank 寫入允許。
        .sfr_wr_en     (sfr_bus_wr_en),
        // 【教學】具名接線不依埠的排列順序。sfr_rmw(mem_rmw)：把子模組的 sfr_rmw 埠接到外層 mem_rmw，用途為讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
        .sfr_rmw       (mem_rmw),
        // 【教學】具名接線不依埠的排列順序。int0_n(effective_int0_n)：把子模組的 int0_n 埠接到外層 effective_int0_n，用途為低有效 INT0 輸入／合併後訊號；int1_n(effective_int1_n)：把子模組的 int1_n 埠接到外層 effective_int1_n，用途為低有效 INT1 輸入／合併後訊號。
        .int0_n        (effective_int0_n), .int1_n(effective_int1_n),
        // 【教學】具名接線不依埠的排列順序。timer0_overflow(timer0_event)：把子模組的 timer0_overflow 埠接到外層 timer0_event，用途為Timer0 的溢位事件輸入；timer1_overflow(timer1_event)：把子模組的 timer1_overflow 埠接到外層 timer1_event，用途為Timer1 的單拍溢位，作 UART 鮑率來源。
        .timer0_overflow(timer0_event), .timer1_overflow(timer1_event),
        // 【教學】具名接線不依埠的排列順序。timer0_tl(tl0)：把子模組的 timer0_tl 埠接到外層 tl0，用途為Timer0 真實 TL0 讀值；timer0_th(th0)：把子模組的 timer0_th 埠接到外層 th0，用途為Timer0 真實 TH0 讀值。
        .timer0_tl(tl0), .timer0_th(th0),
        // 【教學】具名接線不依埠的排列順序。timer1_tl(tl1)：把子模組的 timer1_tl 埠接到外層 tl1，用途為Timer1 真實 TL1 讀值；timer1_th(th1)：把子模組的 timer1_th 埠接到外層 th1，用途為Timer1 真實 TH1 讀值。
        .timer1_tl(tl1), .timer1_th(th1),
        // 【教學】具名接線不依埠的排列順序。serial_rx_irq(serial_ri_set | (serial_rx_irq === 1'b1))：將真正 UART 事件與明確為 1 的額外事件合併，再送到旗標 bank。
        .serial_rx_irq (serial_ri_set | (serial_rx_irq === 1'b1)),
        // 【教學】具名接線不依埠的排列順序。serial_tx_irq(serial_ti_set | (serial_tx_irq === 1'b1))：將真正 UART 事件與明確為 1 的額外事件合併，再送到旗標 bank。
        .serial_tx_irq (serial_ti_set | (serial_tx_irq === 1'b1)),
        // 【教學】具名接線不依埠的排列順序。serial_sbuf(serial_sbuf)：把子模組的 serial_sbuf 埠接到外層 serial_sbuf，用途為UART0 接收 byte；serial_rb8_write(serial_rb8_write)：把子模組的 serial_rb8_write 埠接到外層 serial_rb8_write，用途為UART0 要求更新 RB8 的事件。
        .serial_sbuf(serial_sbuf), .serial_rb8_write(serial_rb8_write),
        // 【教學】具名接線不依埠的排列順序。serial_rb8_data(serial_rb8_data)：把子模組的 serial_rb8_data 埠接到外層 serial_rb8_data，用途為UART0 RB8 的新值。
        .serial_rb8_data(serial_rb8_data),
        // 【教學】具名接線不依埠的排列順序。irq_ack(core_irq_ack)：把子模組的 irq_ack 埠接到外層 core_irq_ack，用途為主機已接受中斷的確認脈波；irq_ack_source(core_irq_source)：把子模組的 irq_ack_source 埠接到外層 core_irq_source，用途為已接受的 0～12 中斷來源編號。
        .irq_ack       (core_irq_ack), .irq_ack_source(core_irq_source),

        // ALU 硬體強制寫入介面
        // 【教學】具名接線不依埠的排列順序。core_psw_we(1'b0)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_psw_we(1'b0),
        // 【教學】具名接線不依埠的排列順序。core_psw_data(8'h00)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_psw_data(8'h00),
        // 【教學】具名接線不依埠的排列順序。core_acc_we(1'b0)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_acc_we(1'b0),
        // 【教學】具名接線不依埠的排列順序。core_acc_data(8'h00)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_acc_data(8'h00),
        // 【教學】具名接線不依埠的排列順序。core_b_we(1'b0)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_b_we(1'b0),
        // 【教學】具名接線不依埠的排列順序。core_b_data(8'h00)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_b_data(8'h00),
        // 【教學】具名接線不依埠的排列順序。core_sp_we(1'b0)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_sp_we(1'b0),
        // 【教學】具名接線不依埠的排列順序。core_sp_data(8'h00)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
        .core_sp_data(8'h00),

		// 【教學】具名接線不依埠的排列順序。core_dptr_we(1'b0)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
		.core_dptr_we(1'b0),
		// 【教學】具名接線不依埠的排列順序。core_dptr_data(16'h0000)：沒有 CPU 直接寫回，將使能／資料固定為 0，避免浮接 X。
		.core_dptr_data(16'h0000),


        // Core 暫存器輸出
        // 【教學】具名接線不依埠的排列順序。acc()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .acc(),
        // 【教學】具名接線不依埠的排列順序。b()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .b(),
        // 【教學】具名接線不依埠的排列順序。psw()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .psw(),
        // 【教學】具名接線不依埠的排列順序。sp()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .sp(),
        // 【教學】具名接線不依埠的排列順序。dpl()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .dpl(),
        // 【教學】具名接線不依埠的排列順序。dph()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .dph(),
        // 【教學】具名接線不依埠的排列順序。dptr()：此輸出刻意不使用，省去外層連線；不是把輸入懸空；dps_out()：此輸出刻意不使用，省去外層連線；不是把輸入懸空；dp0_value()：此輸出刻意不使用，省去外層連線；不是把輸入懸空；dp1_value()：此輸出刻意不使用，省去外層連線；不是把輸入懸空。
        .dptr(),.dps_out(),.dp0_value(),.dp1_value(),
        // 【教學】具名接線不依埠的排列順序。ie(ie)：把子模組的 ie 埠接到外層 ie，用途為基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用；ip(ip)：把子模組的 ip 埠接到外層 ip，用途為基本中斷優先權設定；tcon(tcon)：把子模組的 tcon 埠接到外層 tcon，用途為T0/T1 啟動及外部／計時中斷旗標；tmod(tmod)：把子模組的 tmod 埠接到外層 tmod，用途為計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；scon(scon)：把子模組的 scon 埠接到外層 scon，用途為UART 模式、REN、SM2、TB8 和 RI/TI/RB8。
        .ie             (ie), .ip(ip), .tcon(tcon), .tmod(tmod), .scon(scon),
        // 【教學】具名接線不依埠的排列順序。pcon(pcon)：把子模組的 pcon 埠接到外層 pcon，用途為電源／控制影像，bit7 是 UART0 SMOD。
        .pcon           (pcon),

        // 【教學】GPIO 讀回由獨立 gpio 模組提供，SFR bank 只選它，不重複存一份 latch。
        // GPIO readback is supplied by the independent port block.
        // 【教學】具名接線不依埠的排列順序。port_read_data(gpio_read_data)：把子模組的 port_read_data 埠接到外層 gpio_read_data，用途為GPIO 位址解碼後的讀回值。
        .port_read_data(gpio_read_data)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // ------------------------------------------------------------------------

    // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
    mcu8051_extended u_extended (
     // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；run_enable(peripheral_enable)：把子模組的 run_enable 埠接到外層 peripheral_enable，用途為周邊運作使能；並非所有模組的總暫停開關；timer_tick(timer_tick)：CKCON 選每拍或分頻 tick，再與運作允許結合；counter 外部邊沿路徑不受此 tick 封鎖。
     .clk(clk),.rst_n(rst_n),.run_enable(peripheral_enable),.timer_tick(timer_tick),
     // 【教學】具名接線不依埠的排列順序。addr(sfr_bus_addr)：把子模組的 addr 埠接到外層 sfr_bus_addr，用途為本次 SFR byte 位址；wdata(sfr_bus_wr_data)：把子模組的 wdata 埠接到外層 sfr_bus_wr_data，用途為本次寫入的 8-bit 資料；wr(sfr_bus_wr_en)：把子模組的 wr 埠接到外層 sfr_bus_wr_en，用途為本拍寫入有效。
     .addr(sfr_bus_addr),.wdata(sfr_bus_wr_data),.wr(sfr_bus_wr_en),
     // 【教學】具名接線不依埠的排列順序。rdata(extended_sfr_data)：把子模組的 rdata 埠接到外層 extended_sfr_data，用途為擴充 SFR 的組合讀回值；selected(extended_sfr_select)：把子模組的 selected 埠接到外層 extended_sfr_select，用途為位址是否由 extended 模組負責；p1(p1_in)：把子模組的 p1 埠接到外層 p1_in，用途為P1 實際腳位取樣，供 T2/UART1/擴充中斷使用。
     .rdata(extended_sfr_data),.selected(extended_sfr_select),.p1(p1_in),
     // 【教學】具名接線不依埠的排列順序。timer1_overflow(timer1_internal_overflow)：把子模組的 timer1_overflow 埠接到外層 timer1_internal_overflow，用途為Timer1 的單拍溢位，作 UART 鮑率來源；ie(ie)：把子模組的 ie 埠接到外層 ie，用途為基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用。
     .timer1_overflow(timer1_internal_overflow),.ie(ie),
     // 【教學】具名接線不依埠的排列順序。ckcon(ckcon)：把子模組的 ckcon 埠接到外層 ckcon，用途為時鐘與原 CPU 等待控制；spc_fnc(spc_fnc)：把子模組的 spc_fnc 埠接到外層 spc_fnc，用途為原系統特殊功能控制，獨立套件只保留暫存器；mpage(mpage)：把子模組的 mpage 埠接到外層 mpage，用途為原 CPU MOVX 分頁值，獨立套件不操作記憶體；eie(eie)：把子模組的 eie 埠接到外層 eie，用途為擴充中斷允許／優先權；exif(exif)：把子模組的 exif 埠接到外層 exif，用途為擴充外部中斷事件旗標；eicon(eicon)：把子模組的 eicon 埠接到外層 eicon，用途為擴充控制與事件位，bit7 也作 UART1 SMOD。
     .ckcon(ckcon),.spc_fnc(spc_fnc),.mpage(mpage),.eie(eie),.exif(exif),.eicon(eicon),
     // 【教學】具名接線不依埠的排列順序。timer2_irq(timer2_irq)：把子模組的 timer2_irq 埠接到外層 timer2_irq，用途為Timer2 TF2 或 EXF2 請求；serial1_irq(serial1_irq)：把子模組的 serial1_irq 埠接到外層 serial1_irq，用途為UART1 RI 或 TI 請求。
     .timer2_irq(timer2_irq),.serial1_irq(serial1_irq),
     // 【教學】具名接線不依埠的排列順序。uart1_txd(uart1_txd)：把子模組的 uart1_txd 埠接到外層 uart1_txd，用途為UART1 傳送值，後續接 P1.3；uart1_rxd_out(uart1_rxd_out)：把子模組的 uart1_rxd_out 埠接到外層 uart1_rxd_out，用途為UART1 Mode0 同步資料輸出；uart1_rxd_oe(uart1_rxd_oe)：把子模組的 uart1_rxd_oe 埠接到外層 uart1_rxd_oe，用途為UART1 Mode0 輸出使能。
     .uart1_txd(uart1_txd),.uart1_rxd_out(uart1_rxd_out),.uart1_rxd_oe(uart1_rxd_oe),
     // 【教學】具名接線不依埠的排列順序。t2_out(t2_out)：把子模組的 t2_out 埠接到外層 t2_out，用途為Timer2 clock-out 方波資料；t2_output_enable(t2_output_enable)：把子模組的 t2_output_enable 埠接到外層 t2_output_enable，用途為Timer2 可複用到 P1.0 的允許。
     .t2_out(t2_out),.t2_output_enable(t2_output_enable),
     // 【教學】具名接線不依埠的排列順序。uart0_rx_tick(t2_rx_tick)：把子模組的 uart0_rx_tick 埠接到外層 t2_rx_tick，用途為Timer2 提供 UART0 RX 的溢位來源；uart0_tx_tick(t2_tx_tick)：把子模組的 uart0_tx_tick 埠接到外層 t2_tx_tick，用途為Timer2 提供 UART0 TX 的溢位來源。
     .uart0_rx_tick(t2_rx_tick),.uart0_tx_tick(t2_tx_tick),
     // 【教學】具名接線不依埠的排列順序。uart0_use_rx_t2(t2_rx_select)：把子模組的 uart0_use_rx_t2 埠接到外層 t2_rx_select，用途為UART0 RX 選 Timer2；uart0_use_tx_t2(t2_tx_select)：把子模組的 uart0_use_tx_t2 埠接到外層 t2_tx_select，用途為UART0 TX 選 Timer2。
     .uart0_use_rx_t2(t2_rx_select),.uart0_use_tx_t2(t2_tx_select),
     // 【教學】具名接線不依埠的排列順序。adc_miso(adc_miso)：把子模組的 adc_miso 埠接到外層 adc_miso，用途為ADC 回傳的序列資料；adc_sclk(adc_sclk)：把子模組的 adc_sclk 埠接到外層 adc_sclk，用途為ADC SPI 時鐘，idle 高；adc_mosi(adc_mosi)：把子模組的 adc_mosi 埠接到外層 adc_mosi，用途為送到 ADC 的序列命令；adc_cs_n(adc_cs_n)：把子模組的 adc_cs_n 埠接到外層 adc_cs_n，用途為低有效 ADC 晶片選取。
     .adc_miso(adc_miso),.adc_sclk(adc_sclk),.adc_mosi(adc_mosi),.adc_cs_n(adc_cs_n),
     // 【教學】具名接線不依埠的排列順序。export_a(export_a)：把子模組的 export_a 埠接到外層 export_a，用途為擴充 port A 輸出 latch 的資料；export_b(export_b)：把子模組的 export_b 埠接到外層 export_b，用途為擴充 port B 輸出 latch 的資料；export_c(export_c)：把子模組的 export_c 埠接到外層 export_c，用途為擴充 port C 輸出 latch 的資料；export_d(export_d)：把子模組的 export_d 埠接到外層 export_d，用途為擴充 port D 輸出 latch 的資料。
     .export_a(export_a),.export_b(export_b),.export_c(export_c),.export_d(export_d),
     // 【教學】具名接線不依埠的排列順序。export_b_oe(export_b_oe)：把子模組的 export_b_oe 埠接到外層 export_b_oe，用途為擴充 port B 輸出使能，1 輸出、0 輸入；export_c_oe(export_c_oe)：把子模組的 export_c_oe 埠接到外層 export_c_oe，用途為擴充 port C 輸出使能，1 輸出、0 輸入；export_d_oe(export_d_oe)：把子模組的 export_d_oe 埠接到外層 export_d_oe，用途為擴充 port D 輸出使能，1 輸出、0 輸入。
     .export_b_oe(export_b_oe),.export_c_oe(export_c_oe),.export_d_oe(export_d_oe),
     // 【教學】具名接線不依埠的排列順序。export_a_in(export_a_in)：把子模組的 export_a_in 埠接到外層 export_a_in，用途為擴充 port A 外部輸入值；export_b_in(export_b_in)：把子模組的 export_b_in 埠接到外層 export_b_in，用途為擴充 port B 外部輸入值；export_c_in(export_c_in)：把子模組的 export_c_in 埠接到外層 export_c_in，用途為擴充 port C 外部輸入值；export_d_in(export_d_in)：把子模組的 export_d_in 埠接到外層 export_d_in，用途為擴充 port D 外部輸入值。
     .export_a_in(export_a_in),.export_b_in(export_b_in),.export_c_in(export_c_in),.export_d_in(export_d_in)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
