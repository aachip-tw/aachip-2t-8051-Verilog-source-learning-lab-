// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns / 1ps

// 【教學】宣告 mcu8051_core 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module mcu8051_core #(
    // FPGA M9K read-data register requires one explicit FSM wait state.
    // 【教學】建構電路時設定的參數 RAM_PIPELINED：0 用下降沿讀值，1 多一個上升沿資料暫存，CPU 需加等待狀態。
    parameter integer RAM_PIPELINED = 0,
    // 【教學】建構電路時設定的參數 MOVX_RI_PAGED：1 時 MOVX @Ri 的高地址來自 movx_page；基本整合接 P2 latch。
    parameter integer MOVX_RI_PAGED = 0
// 【教學】結束參數清單並開始對外埠清單；參數決定配置，埠是運作時的訊號。
) (
    // 【教學】輸入由外層驅動。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire        clk,
    // 【教學】輸入由外層驅動。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire        rst_n,
    // 【教學】輸入由外層驅動。clock_enable：核心正常運作使能；基本頂層固定為 1，不提供外部暫停控制。
    input  wire        clock_enable,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。movx_page：MOVX @Ri 的高地址 byte；基本整合接 P2 latch。
    input wire [7:0] movx_page,

    // Program Memory (ROM) 介面
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。rom_addr：程式記憶體地址，與 MOVX 資料空間分開。
    output reg  [15:0] rom_addr,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。rom_data：程式記憶體讀出的 byte。
    input  wire [7:0]  rom_data,

    // Program Counter (PC) 輸出
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。pc：下一次／目前指令的十六位程式計數。
    output reg  [15:0] pc,

    // Internal RAM 介面
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ram_addr：共用資料地址，需由頂層區分 IRAM 與 SFR。
    output reg  [7:0]  ram_addr,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ram_wr_data：共用資料寫入值。
    output reg  [7:0]  ram_wr_data,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。ram_rd_data：頂層選回的 IRAM 或 SFR 資料。
    input  wire [7:0]  ram_rd_data,
    // 【教學】輸出供外層連接。ram_wr_en：CPU 發出一次資料寫入請求。
    output reg         ram_wr_en,
    // 【教學】輸出供外層連接。ram_rd_en：CPU 發出資料讀請求。
    output reg         ram_rd_en,
    // 【教學】輸出供外層連接。ram_rmw：讀改寫指令要求 GPIO 回讀 latch。
    output reg         ram_rmw,
    // 【教學】輸出供外層連接。ram_indirect：間接／堆疊存取標記；高地址不應誤寫 SFR。
    output reg         ram_indirect, // upper IRAM versus direct SFR address space
    // 【教學】輸出供外層連接。ram_cs：資料讀或寫任一有效的選取。
    output wire        ram_cs,

    // External RAM (XRAM) 介面
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。ext_ram_addr：MOVX 的十六位邏輯資料地址。
    output reg  [15:0] ext_ram_addr,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ext_ram_wr_data：MOVX 寫出的 byte。
    output reg  [7:0]  ext_ram_wr_data,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。ext_ram_rd_data：外部 XRAM 回傳的 byte。
    input  wire [7:0]  ext_ram_rd_data,
    // 【教學】輸出供外層連接。ext_ram_wr_en：一次 MOVX 寫使能。
    output reg         ext_ram_wr_en,
    // 【教學】輸出供外層連接。ext_ram_rd_en：MOVX 讀取使能，讀資料需在 capture 前穩定。
    output reg         ext_ram_rd_en,

    // SFR 控制輸出 (寫入)
    // 【教學】輸出供外層連接。core_acc_we：CPU 寫回 ACC 的單拍允許。
    output reg         core_acc_we,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。core_acc_data：CPU 寫回 ACC 的新值。
    output reg  [7:0]  core_acc_data,
    // 【教學】輸出供外層連接。core_b_we：CPU 寫回 B 的單拍允許。
    output reg         core_b_we,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。core_b_data：CPU 寫回 B 的新值。
    output reg  [7:0]  core_b_data,
    // 【教學】輸出供外層連接。core_sp_we：CPU 寫回 SP 的單拍允許。
    output reg         core_sp_we,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。core_sp_data：CPU 寫回 SP 的新值。
    output reg  [7:0]  core_sp_data,
    // 【教學】輸出供外層連接。core_psw_we：CPU 寫回 PSW 的單拍允許。
    output reg         core_psw_we,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。core_psw_data：CPU 寫回 PSW 的新值。
    output reg  [7:0]  core_psw_data,
    // 【教學】輸出供外層連接。core_dptr_we：CPU 寫回 DPTR 的單拍允許。
    output reg         core_dptr_we,     
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。core_dptr_data：CPU 寫回 DPTR 的新值。
    output reg  [15:0] core_dptr_data,   

    // SFR 狀態輸入 (讀取)
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。acc_in：目前 ACC 儲存值。
    input  wire [7:0]  acc_in,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。b_in：目前 B 儲存值。
    input  wire [7:0]  b_in,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。psw_in：目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。
    input  wire [7:0]  psw_in,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。sp_in：目前堆疊指標。
    input  wire [7:0]  sp_in,
    // 【教學】輸入由外層驅動；[15:0] 指定位元／陣列範圍。dptr_in：目前資料指標。
    input  wire [15:0] dptr_in,
    // 【教學】輸入由外層驅動。irq_valid：有可接受且已仲裁的中斷。
    input  wire         irq_valid,
    // 【教學】輸入由外層驅動；[15:0] 指定位元／陣列範圍。irq_vector：中斷入口地址。
    input  wire [15:0]  irq_vector,
    // 【教學】輸入由外層驅動。irq_priority：已選中斷的高／低等級。
    input  wire         irq_priority,
    // 【教學】輸入由外層驅動；[3:0] 指定位元／陣列範圍。irq_source：已選中斷來源編號。
    input  wire [3:0]   irq_source,
    // 【教學】輸出供外層連接。irq_ack：主機已接受中斷的確認脈波。
    output reg          irq_ack,
    // 【教學】輸出供外層連接。irq_ack_priority：CPU 回報已接受的中斷等級。
    output reg          irq_ack_priority,
    // 【教學】輸出供外層連接；[3:0] 指定位元／陣列範圍。irq_ack_source：已接受的 0～12 中斷來源編號。
    output reg  [3:0]   irq_ack_source,
    // One-cycle RETI notification used by the top-level priority tracker.
    // RET does not assert this output.
    // 【教學】輸出供外層連接。reti_complete：RETI 完成的單拍通知；RET 不產生它。
    output reg         reti_complete
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);

    // 【教學】ram_cs（資料讀或寫任一有效的選取）← ram_rd_en | ram_wr_en；ram_rd_en=CPU 發出資料讀請求；ram_wr_en=CPU 發出一次資料寫入請求；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    assign ram_cs = ram_rd_en | ram_wr_en;

    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。ucode_addr：本指令 opcode 鎖存值。
    reg [7:0] ucode_addr;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。op1：指令的第二 byte；op2：指令的第三 byte。
    reg [7:0] op1, op2;

    // Special two-stage operand storage for MOV @Ri,direct (0xA6/0xA7)
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。mov_ind_src_data：MOV @Ri,direct 的來源資料暫存，避免讀 Ri 後遺失。
    reg [7:0] mov_ind_src_data;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。return_high：RET/RETI 從堆疊先取回的高 byte。
    reg [7:0] return_high;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[15:0] 指定位元／陣列範圍。pending_irq_vector：已接受但尚未壓堆疊的中斷目標。
    reg [15:0] pending_irq_vector;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。pending_irq_priority：待處理中斷的優先等級。
    reg        pending_irq_priority;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[3:0] 指定位元／陣列範圍。pending_irq_source：待處理中斷來源編號。
    reg [3:0]  pending_irq_source;

    // 【教學】wire 由接線／組合表達式驅動；[1:0] 指定位元／陣列範圍。ucode_bytes：微碼解出的指令長度。
    wire [1:0] ucode_bytes;
    // 【教學】wire 由接線／組合表達式驅動。ucode_ram_rd：ucode_ram_rd。
    wire       ucode_ram_rd;
    // 【教學】wire 由接線／組合表達式驅動。ucode_ram_wr：ucode_ram_wr。
    wire       ucode_ram_wr;
    // 【教學】wire 由接線／組合表達式驅動；[4:0] 指定位元／陣列範圍。ucode_alu_op：本指令要求的 ALU 運算。
    wire [4:0] ucode_alu_op;
    // 【教學】wire 由接線／組合表達式驅動；[3:0] 指定位元／陣列範圍。ucode_src_sel：解碼後的來源定址方式。
    wire [3:0] ucode_src_sel;
    // 【教學】wire 由接線／組合表達式驅動；[3:0] 指定位元／陣列範圍。ucode_dst_sel：解碼後的目的定址方式。
    wire [3:0] ucode_dst_sel;
    // 【教學】wire 由接線／組合表達式驅動；[2:0] 指定位元／陣列範圍。ucode_jmp_type：解碼後的跳轉種類。
    wire [2:0] ucode_jmp_type;
    // 【教學】wire 由接線／組合表達式驅動。cy_we：此指令是否更新 CY。
    wire       cy_we;

    // 【教學】建立 mcu8051_ucode_rom 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_ucode_rom u_ucode_rom (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：opcode(ucode_addr)，原始八位指令操作碼。
        .opcode   (ucode_addr),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：bytes(ucode_bytes)，指令總 byte 數，供取指與 PC 推進使用。
        .bytes    (ucode_bytes),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ram_rd(ucode_ram_rd)，微碼記憶體讀需求。
        .ram_rd   (ucode_ram_rd),   
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ram_wr(ucode_ram_wr)，微碼記憶體寫需求。
        .ram_wr   (ucode_ram_wr),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：alu_op(ucode_alu_op)，ALU 運算選擇碼。
        .alu_op   (ucode_alu_op),   
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：src_sel(ucode_src_sel)，來源定址方式。
        .src_sel  (ucode_src_sel),  
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：dst_sel(ucode_dst_sel)，目的定址方式。
        .dst_sel  (ucode_dst_sel),  
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：cy_we(cy_we)，此指令是否更新 CY。
        .cy_we    (cy_we),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：jmp_type(ucode_jmp_type)，跳轉／呼叫種類。
        .jmp_type (ucode_jmp_type)  
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );

    // 【教學】wire 由接線／組合表達式驅動；[7:0] 指定位元／陣列範圍。alu_a：送入 ALU 左端的值；alu_b：送入 ALU 右端的值；alu_out：八位運算結果。
    wire [7:0] alu_a, alu_b, alu_out;
    // 【教學】wire 由接線／組合表達式驅動。alu_cy_out：ALU 新 CY；alu_ac_out：ALU 新 AC；alu_ov_out：ALU 新 OV。
    wire       alu_cy_out, alu_ac_out, alu_ov_out;
    // 【教學】mul_product（A 乘 B 的完整十六位結果）← acc_in * b_in；acc_in=目前 ACC 儲存值；b_in=目前 B 儲存值；= 是本組合求值的立即指派。
    wire [15:0] mul_product = acc_in * b_in;

    // DA A helper.  DA depends on the AC/CY generated by the preceding ADD/ADDC.
    // 【教學】da_add_low（DA A 是否應對低半 byte 加 6）← (acc_in[3:0] > 4'h9) || psw_in[6]；acc_in=目前 ACC 儲存值；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire       da_add_low  = (acc_in[3:0] > 4'h9) || psw_in[6];
    // 【教學】da_step_lo（A 低位 BCD 調整後的九位結果）← {1'b0, acc_in} + (da_add_low ? 9'h006 : 9'h000)；acc_in=目前 ACC 儲存值；da_add_low=DA A 是否應對低半 byte 加 6；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [8:0] da_step_lo  = {1'b0, acc_in} + (da_add_low ? 9'h006 : 9'h000);
    // 【教學】da_add_high（DA A 是否應對高半 byte 加 60h）← (da_step_lo[7:4] > 4'h9) || psw_in[7] || da_step_lo[8]；da_step_lo=A 低位 BCD 調整後的九位結果；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire       da_add_high = (da_step_lo[7:4] > 4'h9) || psw_in[7] || da_step_lo[8];
    // 【教學】da_result9（BCD 調整完成的九位值，最高位供 CY）← da_step_lo + (da_add_high ? 9'h060 : 9'h000)；da_step_lo=A 低位 BCD 調整後的九位結果；da_add_high=DA A 是否應對高半 byte 加 60h；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [8:0] da_result9  = da_step_lo + (da_add_high ? 9'h060 : 9'h000);
    // 【教學】fast_add9（快速 ADD 的九位結果，包含 CY）← {1'b0, acc_in} + {1'b0, op1}；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [8:0] fast_add9      = {1'b0, acc_in} + {1'b0, op1};
    // 【教學】fast_add4（快速 ADD 的五位低半結果，包含 AC）← {1'b0, acc_in[3:0]} + {1'b0, op1[3:0]}；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [4:0] fast_add4      = {1'b0, acc_in[3:0]} + {1'b0, op1[3:0]};
    // 【教學】fast_addc9（快速 ADDC 的九位結果，包含輸入 CY）← {1'b0, acc_in} + {1'b0, op1} + psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [8:0] fast_addc9     = {1'b0, acc_in} + {1'b0, op1} + psw_in[7];
    // 【教學】fast_addc4（快速 ADDC 低半五位結果）← {1'b0, acc_in[3:0]} + {1'b0, op1[3:0]} + psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [4:0] fast_addc4     = {1'b0, acc_in[3:0]} + {1'b0, op1[3:0]} + psw_in[7];
    // 【教學】fast_add_res（ADD 八位結果，供符號溢位判斷）← acc_in + op1；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [7:0] fast_add_res   = acc_in + op1;
    // 【教學】fast_addc_res（ADDC 八位結果，供符號溢位判斷）← acc_in + op1 + psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [7:0] fast_addc_res  = acc_in + op1 + psw_in[7];
    // 【教學】fast_subb_res（SUBB 八位結果，供符號溢位判斷）← acc_in - op1 - psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；減法依目前位寬截斷，旗標需另外計算；= 是本組合求值的立即指派。
    wire [7:0] fast_subb_res  = acc_in - op1 - psw_in[7];

    // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_NONE：沒有運算元；SEL_ACC：累加器 A；SEL_REG：目前 PSW bank 的 R0～R7
    localparam SEL_NONE = 4'd0, SEL_ACC = 4'd1, SEL_REG = 4'd2, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_IND：R0/R1 間接地址；SEL_DIR：直接 byte 地址；SEL_IMM：指令內立即數
               SEL_IND  = 4'd3, SEL_DIR = 4'd4, SEL_IMM = 4'd5, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_DPTR：十六位 DPTR；SEL_PC：程式計數 PC；SEL_BIT：位元位址運算元
               SEL_DPTR = 4'd6, SEL_PC = 4'd7, SEL_BIT = 4'd8; 
  
    // ------------------------------------------------------------------------
    // Bit-addressable internal RAM helper (bit addresses 00H~7FH)
    // 8051 mapping:
    //   bit 00H~7FH -> IRAM byte 20H~2FH
    //   byte address = 20H + bit_addr[6:3]
    //   bit index    = bit_addr[2:0]
    //
    // SFR bit addresses 80H~FFH need a separate SFR-bit path and are not
    // handled by this IRAM mapping.
    // ------------------------------------------------------------------------
    // 【教學】本行是持續接線或跨行表達式的一部分。bit_byte_addr=bit 位址換算成的 byte 位址；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
    wire [7:0] bit_byte_addr = op1[7] ? {op1[7:3], 3'b000} :
                                              // 【教學】本行是持續接線或跨行表達式的一部分。op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                              (8'h20 + {4'b0000, op1[6:3]});
    // 【教學】bit_index（byte 內 bit0～7 的位置）← op1[2:0]；op1=指令的第二 byte；= 是本組合求值的立即指派。
    wire [2:0] bit_index     = op1[2:0];
    // 【教學】bit_value（本次讀取的單一位元）← ram_rd_data[bit_index]；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；= 是本組合求值的立即指派。
    wire       bit_value     = ram_rd_data[bit_index];

    // 透過 ucode_dst_sel 乾淨地分配 ALU A 來源
    // 【教學】本行是持續接線或跨行表達式的一部分。alu_a=送入 ALU 左端的值；ucode_dst_sel=解碼後的目的定址方式；SEL_ACC=累加器 A；acc_in=目前 ACC 儲存值。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
    assign alu_a = (ucode_dst_sel == SEL_ACC) ? acc_in :
                   // 【教學】本行是持續接線或跨行表達式的一部分。ucode_dst_sel=解碼後的目的定址方式；SEL_DIR=直接 byte 地址；SEL_REG=目前 PSW bank 的 R0～R7；SEL_IND=R0/R1 間接地址；ram_rd_data=頂層選回的 IRAM 或 SFR 資料。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   (ucode_dst_sel == SEL_DIR || ucode_dst_sel == SEL_REG || ucode_dst_sel == SEL_IND) ? ram_rd_data : 
                   // 【教學】本行是持續接線或跨行表達式的一部分。acc_in=目前 ACC 儲存值。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   acc_in;

    // INC 與 DEC 強制 B 運算數為 1 的機制 (保留你原本精準的修正)
    // 【教學】接續前一行 opcode 的判斷／指令集合；is_inc_dec=是否為 INC/DEC，需把 ALU 右運算元強制為 1；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
    wire is_inc_dec = (ucode_addr >= 8'h04 && ucode_addr <= 8'h0F) || 
                      // 【教學】ucode_addr（本指令 opcode 鎖存值）← 8'h1F)；<= 讀本拍舊值並延後提交。
                      (ucode_addr >= 8'h14 && ucode_addr <= 8'h1F);

    // Immediate operand selection:
    //   Normal 3-byte immediate instructions (e.g. MOV direct,#data) use op2.
    //   CJNE B4/B6~BF format is opcode, #data, rel, so compare-data is op1.
    // 【教學】接續前一行 opcode 的判斷／指令集合；is_cjne_imm=是否為 CJNE 的立即值比較格式；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
    wire is_cjne_imm = (ucode_addr == 8'hB4) ||
                       // 【教學】ucode_addr（本指令 opcode 鎖存值）← 8'hBF)；<= 讀本拍舊值並延後提交。
                       (ucode_addr >= 8'hB6 && ucode_addr <= 8'hBF);
    // 【教學】接續前一行 opcode 的判斷／指令集合；direct_rmw=直接位址指令是否要讀輸出 latch 而非 IO pin；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
    wire direct_rmw = (ucode_addr == 8'h05) || (ucode_addr == 8'h15) ||
                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                      (ucode_addr == 8'h42) || (ucode_addr == 8'h43) ||
                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                      (ucode_addr == 8'h52) || (ucode_addr == 8'h53) ||
                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                      (ucode_addr == 8'h62) || (ucode_addr == 8'h63) ||
                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                      (ucode_addr == 8'hC5) || (ucode_addr == 8'hD5);

    // 【教學】本行是持續接線或跨行表達式的一部分。alu_b=送入 ALU 右端的值；is_inc_dec=是否為 INC/DEC，需把 ALU 右運算元強制為 1。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
    assign alu_b = is_inc_dec ? 8'h01 :
                   // 【教學】本行是持續接線或跨行表達式的一部分。ucode_src_sel=解碼後的來源定址方式；SEL_ACC=累加器 A；acc_in=目前 ACC 儲存值。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   (ucode_src_sel == SEL_ACC) ? acc_in :
                   // 【教學】本行是持續接線或跨行表達式的一部分。ucode_src_sel=解碼後的來源定址方式；SEL_IMM=指令內立即數；is_cjne_imm=是否為 CJNE 的立即值比較格式；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   (ucode_src_sel == SEL_IMM) ? (is_cjne_imm ? op1 :
                                                  // 【教學】本行是持續接線或跨行表達式的一部分。ucode_bytes=微碼解出的指令長度；op2=指令的第三 byte；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                                  ((ucode_bytes == 2'd3) ? op2 : op1)) :
                   // 【教學】本行是持續接線或跨行表達式的一部分。ucode_src_sel=解碼後的來源定址方式；SEL_DIR=直接 byte 地址；SEL_REG=目前 PSW bank 的 R0～R7；SEL_IND=R0/R1 間接地址；ram_rd_data=頂層選回的 IRAM 或 SFR 資料。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   (ucode_src_sel == SEL_DIR || ucode_src_sel == SEL_REG || ucode_src_sel == SEL_IND) ? ram_rd_data : 
                   // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                   8'h00;

    // 【教學】dptr_inc_out（DPTR 加一的十六位值）← dptr_in + 1'b1；dptr_in=目前資料指標；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [15:0] dptr_inc_out = dptr_in + 1'b1;
    // 【教學】pc_after_2（目前 PC 加二，供 AJMP/ACALL 頁面計算）← pc + 16'd2；pc=下一次／目前指令的十六位程式計數；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [15:0] pc_after_2      = pc + 16'd2;
    // 【教學】return_pc（本指令結束後的循序 PC，也作 CALL 的返回位址）← pc + {14'd0, ucode_bytes}；pc=下一次／目前指令的十六位程式計數；ucode_bytes=微碼解出的指令長度；增加固定寬度的計數／資料，超出位寬的進位須另行保存；= 是本組合求值的立即指派。
    wire [15:0] return_pc       = pc + {14'd0, ucode_bytes};
   
    // 【教學】建立 mcu8051_alu 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_alu u_alu (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：alu_op(ucode_alu_op)，ALU 運算選擇碼。
        .alu_op  (ucode_alu_op),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：src_a(alu_a)，ALU 左運算元。
        .src_a   (alu_a),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：src_b(alu_b)，ALU 右運算元。
        .src_b   (alu_b),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：cy_in(psw_in[7])，運算前 CY，ADDC 作進位、SUBB 作借位。
        .cy_in   (psw_in[7]),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：alu_out(alu_out)，八位運算結果。
        .alu_out (alu_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：cy_out(alu_cy_out)，進位／借位旗標。
        .cy_out  (alu_cy_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ac_out(alu_ac_out)，低四位的進位／借位旗標 AC。
        .ac_out  (alu_ac_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ov_out(alu_ov_out)，有號數溢位旗標 OV。
        .ov_out  (alu_ov_out)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );


    // ========================================================================
    // FAST 1-BYTE PATH
    //
    // These instructions do not need IRAM/XRAM/ROM lookup/stack access.
    // They can therefore finish in S_FETCH_B2 immediately after the opcode
    // was captured in S_FETCH_OP.
    //
    // Timing:
    //   CLK1 : S_FETCH_OP  - capture opcode
    //   CLK2 : S_FETCH_B2  - execute + advance PC + return to S_FETCH_OP
    //
    // This reduces these instructions from 4 CLK to 2 CLK without changing
    // any of the existing memory/control-flow FSM paths.
    // ========================================================================
    // 【教學】接續 PSW 或快速運算的跨行表達式；fast_1byte=能走兩拍快速路徑的單 byte 指令集合；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
    wire fast_1byte =
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h00) || // NOP
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h03) || // RR A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h04) || // INC A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h13) || // RRC A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h14) || // DEC A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h23) || // RL A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h33) || // RLC A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h73) || // JMP @A+DPTR
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h84) || // DIV AB
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hA3) || // INC DPTR
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hA4) || // MUL AB
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hB3) || // CPL C
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hC3) || // CLR C
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hC4) || // SWAP A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hD3) || // SETB C
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hD4) || // DA A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hE4) || // CLR A
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'hF4);   // CPL A


    // ========================================================================
    // FAST 2-BYTE PATH
    //
    // These instructions only need the opcode + one immediate/relative byte
    // and do not require IRAM/XRAM/stack accesses.
    //
    // Timing:
    //   CLK1 : S_FETCH_OP  - capture opcode
    //   CLK2 : S_FETCH_B2  - capture operand byte
    //   CLK3 : S_FAST_IMM_EXEC - execute + advance/jump + next fetch
    // ========================================================================
    // 【教學】接續 PSW 或快速運算的跨行表達式；fast_2byte=能走三拍快速路徑的立即值／相對跳轉集合；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
    wire fast_2byte =
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h24) || // ADD A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h34) || // ADDC A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h44) || // ORL A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h54) || // ANL A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h64) || // XRL A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h70) || // JNZ rel
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h74) || // MOV A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h80) || // SJMP rel
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h94) || // SUBB A,#data
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h40) || // JC rel
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h50) || // JNC rel
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           (ucode_addr == 8'h60);   // JZ rel


    // ========================================================================
    // FAST Rn PATH -- asynchronous IRAM/SFR reads, synchronous writes.
    // FETCH_OP -> FETCH_B2(address + optional rel capture) -> EXEC = 3 CLK.
    // MOV Rn,A issues its write directly in FETCH_B2 = 2 CLK.
    // Architectural writes commit on the following FETCH_OP edge.
    // ========================================================================
    // 【教學】接續 PSW 或快速運算的跨行表達式；fast_rn_read=可直接算出 Rn 地址再讀運算元的集合；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
    wire fast_rn_read =
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h08) && (ucode_addr <= 8'h0F)) || // INC Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h18) && (ucode_addr <= 8'h1F)) || // DEC Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h28) && (ucode_addr <= 8'h2F)) || // ADD A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h38) && (ucode_addr <= 8'h3F)) || // ADDC A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h48) && (ucode_addr <= 8'h4F)) || // ORL A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h58) && (ucode_addr <= 8'h5F)) || // ANL A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h68) && (ucode_addr <= 8'h6F)) || // XRL A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'h98) && (ucode_addr <= 8'h9F)) || // SUBB A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'hC8) && (ucode_addr <= 8'hCF)) || // XCH A,Rn
           // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
           ((ucode_addr >= 8'hD8) && (ucode_addr <= 8'hDF)) || // DJNZ Rn,rel
           // 【教學】ucode_addr（本指令 opcode 鎖存值）← 8'hEF))；<= 讀本拍舊值並延後提交。
           ((ucode_addr >= 8'hE8) && (ucode_addr <= 8'hEF));   // MOV A,Rn

    // 【教學】接續 PSW 或快速運算的跨行表達式；fast_rn_write=可直接把 A 寫到 Rn 的集合；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
    wire fast_rn_write =
           // 【教學】ucode_addr（本指令 opcode 鎖存值）← 8'hFF))；<= 讀本拍舊值並延後提交。
           ((ucode_addr >= 8'hF8) && (ucode_addr <= 8'hFF));   // MOV Rn,A

    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[4:0] 指定位元／陣列範圍。state：CPU 目前 FSM 狀態。
    reg [4:0] state;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[4:0] 指定位元／陣列範圍。state_after_ram_read：流水 RAM 額外等待一拍後應回到的狀態。
    reg [4:0] state_after_ram_read;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。S_RESET：建立 reset PC=0000，準備第一次取指
    localparam S_RESET           = 4'd0,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_FETCH_OP：取 opcode，或在指令邊界接受中斷
               S_FETCH_OP        = 4'd1,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_FETCH_B2：取第二 byte，或完成單 byte 快速指令
               S_FETCH_B2        = 4'd2,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_FETCH_B3：取第三 byte，之後進定址解碼
               S_FETCH_B3        = 4'd3,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_DECODE_ST：按指令來源／目的決定 IRAM、SFR、堆疊或外部存取
               S_DECODE_ST       = 4'd4,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_MOV_IND_SRC：保存 MOV @Ri,direct 的來源，再去取 Ri 指標
               S_MOV_IND_SRC     = 4'd5,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_RAM_WAIT：配合流水 RAM 多等一拍，避免使用上一筆讀值
               S_RAM_WAIT        = 4'd6,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_DECODE_IND：Ri 指標已讀出，準備讀寫它指向的地址
               S_DECODE_IND      = 4'd7,   
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_EXEC：一般指令運算、跳轉與產生寫回
               S_EXEC                = 4'd8,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_MOV_IND_PTR_CAPTURE：已取得 Ri 指標，將先前保存的來源寫到目的地址
               S_MOV_IND_PTR_CAPTURE    = 4'd10,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_MOVC_CAPTURE：取得第二次程式 ROM 讀值，作 MOVC 結果
               S_MOVC_CAPTURE           = 4'd12,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_XRAM_PTR_WAIT：取得 Ri 後組合 MOVX 外部地址
               S_XRAM_PTR_WAIT           = 4'd13,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_XRAM_WAIT：讓 XRAM 控制／資料保持完整週期
               S_XRAM_WAIT               = 4'd14,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_XRAM_CAPTURE：取回 MOVX 讀值並回到取指
               S_XRAM_CAPTURE            = 4'd15,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_FAST_IMM_EXEC：執行不需資料 RAM 的兩 byte 指令
               S_FAST_IMM_EXEC          = 5'd16,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_CALL_HIGH：CALL 已壓返回低 byte，再壓高 byte 並跳轉
               S_CALL_HIGH             = 5'd18,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_RET_HIGH：RET/RETI 先取堆疊高 byte，再讀低 byte
               S_RET_HIGH              = 5'd19,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_RET_LOW：合成返回 PC、調整 SP，必要時通知 RETI
               S_RET_LOW               = 5'd20,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_INT_LOW：中斷進入先準備壓 PC 低 byte
               S_INT_LOW               = 5'd21,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。S_INT_HIGH：再壓 PC 高 byte，跳向量並確認來源
               S_INT_HIGH              = 5'd22;

    // 【教學】宣告可重用的時序控制敘述 issue_ram_read，將設讀使能與選等待狀態集中，避免不同指令漏加 RAM 等待；不是額外 CPU 指令。
    task issue_ram_read;
        // 【教學】輸入由外層驅動；[4:0] 指定位元／陣列範圍。next_state：讀 RAM 完成後的目的狀態。
        input [4:0] next_state;
        // 【教學】開始程序敘述群組，讓 task 或其他語法可包含多行；begin 本身不會建立暫存器或多等一拍。
        begin
            // 【教學】ram_rd_en（CPU 發出資料讀請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ram_rd_en <= 1'b1;
            // 【教學】條件成立才走後續分支；RAM_PIPELINED=核心讀 RAM 是否加入流水等待狀態。沒有選此分支時依 else 或保持規則處理。
            if (RAM_PIPELINED != 0) begin
                // 【教學】state_after_ram_read 排定為 next_state（next_state=讀 RAM 完成後的目的狀態），下一個時鐘才依新狀態工作。
                state_after_ram_read <= next_state;
                // 【教學】state 排定為 S_RAM_WAIT（配合流水 RAM 多等一拍，避免使用上一筆讀值），下一個時鐘才依新狀態工作。
                state <= S_RAM_WAIT;
            // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
            end else begin
                // 【教學】state 排定為 next_state（next_state=讀 RAM 完成後的目的狀態），下一個時鐘才依新狀態工作。
                state <= next_state;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束 task 定義；task 在同一個時鐘區塊被展開使用，不能把它誤當獨立時鐘或軟體函式堆疊。
    endtask

    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
        if (!rst_n) begin
            // 【教學】rom_addr ← 16'h0000：讓程式位址與核心 PC 對齊。
            rom_addr        <= 16'h0000;
            // 【教學】pc ← 16'h0000：讓程式位址與核心 PC 對齊。
            pc              <= 16'h0000;
            // 【教學】ram_addr ← 8'h00：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
            ram_addr        <= 8'h00;
            // 【教學】ram_wr_data（共用資料寫入值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ram_wr_data     <= 8'h00;
            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ram_wr_en       <= 1'b0;
            // 【教學】ram_rd_en（CPU 發出資料讀請求）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ram_rd_en       <= 1'b0;
            // 【教學】ram_rmw 設為 1'b0；RMW 必須讀 GPIO latch，避免外部拉低 pin 改寫原本輸出值。
            ram_rmw         <= 1'b0;
            // 【教學】ram_indirect ← 1'b0；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
            ram_indirect    <= 1'b0;
            // 【教學】ext_ram_addr（MOVX 的十六位邏輯資料地址）← 16'h0000；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ext_ram_addr    <= 16'h0000;
            // 【教學】ext_ram_wr_data（MOVX 寫出的 byte）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ext_ram_wr_data <= 8'h00;
            // 【教學】ext_ram_wr_en（一次 MOVX 寫使能）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ext_ram_wr_en   <= 1'b0;
            // 【教學】ext_ram_rd_en（MOVX 讀取使能，讀資料需在 capture 前穩定）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ext_ram_rd_en   <= 1'b0;
            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_acc_we     <= 1'b0;
            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            core_acc_data   <= 8'h00;
            // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_b_we       <= 1'b0;
            // 【教學】core_b_data（CPU 寫回 B 的新值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            core_b_data     <= 8'h00;
            // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_sp_we      <= 1'b0;
            // 【教學】新 SP 取 8'h00，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
            core_sp_data    <= 8'h00;
            // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_psw_we     <= 1'b0;
            // 【教學】將 8'h00 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
            core_psw_data   <= 8'h00;
            // 【教學】core_dptr_we（CPU 寫回 DPTR 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_dptr_we    <= 1'b0;
            // 【教學】新 DPTR 取 16'h0000，用 16 位路徑避免只更新一半資料指標。
            core_dptr_data  <= 16'h0000;
            // 【教學】ucode_addr（本指令 opcode 鎖存值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ucode_addr      <= 8'h00;
            // 【教學】op1（指令的第二 byte）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            op1             <= 8'h00;
            // 【教學】op2（指令的第三 byte）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            op2             <= 8'h00;
            // 【教學】mov_ind_src_data（MOV @Ri,direct 的來源資料暫存，避免讀 Ri 後遺失）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            mov_ind_src_data <= 8'h00;
            // 【教學】return_high（RET/RETI 從堆疊先取回的高 byte）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            return_high     <= 8'h00;
            // 【教學】reti_complete（RETI 完成的單拍通知；RET 不產生它）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            reti_complete   <= 1'b0;
            // 【教學】irq_ack（主機已接受中斷的確認脈波）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            irq_ack         <= 1'b0;
            // 【教學】irq_ack_priority（CPU 回報已接受的中斷等級）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            irq_ack_priority<= 1'b0;
            // 【教學】irq_ack_source（已接受的 0～12 中斷來源編號）← 3'd0；<= 讀本拍舊值並延後提交。
            irq_ack_source  <= 3'd0;
            // 【教學】pending_irq_vector（已接受但尚未壓堆疊的中斷目標）← 16'd0；<= 讀本拍舊值並延後提交。
            pending_irq_vector <= 16'd0;
            // 【教學】pending_irq_priority（待處理中斷的優先等級）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            pending_irq_priority <= 1'b0;
            // 【教學】pending_irq_source（待處理中斷來源編號）← 3'd0；<= 讀本拍舊值並延後提交。
            pending_irq_source <= 3'd0;
            // 【教學】state_after_ram_read 排定為 S_RESET（建立 reset PC=0000，準備第一次取指），下一個時鐘才依新狀態工作。
            state_after_ram_read <= S_RESET;
            // 【教學】state 排定為 S_RESET（建立 reset PC=0000，準備第一次取指），下一個時鐘才依新狀態工作。
            state           <= S_RESET;
        // 【教學】條件成立才走後續分支；clock_enable=核心正常運作使能；基本頂層固定為 1，不提供外部暫停控制。else if 與先前分支互斥，先命中者優先。
        end else if (clock_enable) begin
            // 【教學】reti_complete（RETI 完成的單拍通知；RET 不產生它）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            reti_complete <= 1'b0;
            // 【教學】irq_ack（主機已接受中斷的確認脈波）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            irq_ack       <= 1'b0;
            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_acc_we   <= 1'b0;
            // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_b_we     <= 1'b0;
            // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_sp_we    <= 1'b0;
            // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_psw_we   <= 1'b0;
            // 【教學】core_dptr_we（CPU 寫回 DPTR 的單拍允許）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            core_dptr_we  <= 1'b0;
            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ram_wr_en     <= 1'b0;
            // 【教學】ram_rd_en（CPU 發出資料讀請求）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ram_rd_en     <= 1'b0;
            // 【教學】ext_ram_wr_en（一次 MOVX 寫使能）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ext_ram_wr_en <= 1'b0;
            // 【教學】ext_ram_rd_en（MOVX 讀取使能，讀資料需在 capture 前穩定）設為 1'b0；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
            ext_ram_rd_en <= 1'b0;

            // 【教學】依 state 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
            case (state)
                // 【教學】狀態 S_RESET：建立 reset PC=0000，準備第一次取指。後續列出本分支的指派，state 變更於下一拍生效。
                S_RESET: begin
                    // 【教學】rom_addr ← 16'h0000：讓程式位址與核心 PC 對齊。
                    rom_addr <= 16'h0000;
                    // 【教學】pc ← 16'h0000：讓程式位址與核心 PC 對齊。
                    pc       <= 16'h0000;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state    <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_FETCH_OP：取 opcode，或在指令邊界接受中斷。後續列出本分支的指派，state 變更於下一拍生效。
                S_FETCH_OP: begin
                    // 【教學】ram_rmw 設為 1'b0；RMW 必須讀 GPIO latch，避免外部拉低 pin 改寫原本輸出值。
                    ram_rmw <= 1'b0;
                    // 【教學】ram_indirect ← 1'b0；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b0;
                    // 【教學】條件成立才走後續分支；irq_valid=有可接受且已仲裁的中斷。沒有選此分支時依 else 或保持規則處理。
                    if (irq_valid) begin
                        // Defer stack access by one state so the preceding
                        // instruction's overlapping writeback has committed.
                        // 【教學】pending_irq_vector（已接受但尚未壓堆疊的中斷目標）← irq_vector；irq_vector=中斷入口地址；<= 讀本拍舊值並延後提交。
                        pending_irq_vector   <= irq_vector;
                        // 【教學】pending_irq_priority（待處理中斷的優先等級）← irq_priority；irq_priority=已選中斷的高／低等級；<= 讀本拍舊值並延後提交。
                        pending_irq_priority <= irq_priority;
                        // 【教學】pending_irq_source（待處理中斷來源編號）← irq_source；irq_source=已選中斷來源編號；<= 讀本拍舊值並延後提交。
                        pending_irq_source   <= irq_source;
                        // 【教學】state 排定為 S_INT_LOW（中斷進入先準備壓 PC 低 byte），下一個時鐘才依新狀態工作。
                        state                <= S_INT_LOW;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】ucode_addr（本指令 opcode 鎖存值）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                        ucode_addr <= rom_data;
                        // 【教學】rom_addr ← pc + 1'b1：讓程式位址與核心 PC 對齊。
                        rom_addr   <= pc + 1'b1;
                        // 【教學】state 排定為 S_FETCH_B2（取第二 byte，或完成單 byte 快速指令），下一個時鐘才依新狀態工作。
                        state      <= S_FETCH_B2;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_FETCH_B2：取第二 byte，或完成單 byte 快速指令。後續列出本分支的指派，state 變更於下一拍生效。
                S_FETCH_B2: begin
                    // =========================================================
                    // 2-CLK FAST PATH FOR SIMPLE 1-BYTE INSTRUCTIONS
                    // =========================================================
                    // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度；fast_1byte=能走兩拍快速路徑的單 byte 指令集合。沒有選此分支時依 else 或保持規則處理。
                    if ((ucode_bytes == 2'd1) && fast_1byte) begin

                        // Default sequential next instruction.
                        // 【教學】pc ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                        pc       <= pc + 16'd1;
                        // 【教學】rom_addr ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                        rom_addr <= pc + 16'd1;
                        // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                        state    <= S_FETCH_OP;

                        // 【教學】依 ucode_addr 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                        case (ucode_addr)

                            // -------------------------------------------------
                            // NOP
                            // -------------------------------------------------
                            // 【教學】命中 8'h00 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'h00: begin
                                // No architectural state change.
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // ACC ALU operations that already exist in ALU
                            // -------------------------------------------------
                            // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                            8'h03, // RR A
                            // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                            8'h04, // INC A
                            // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                            8'h14, // DEC A
                            // 【教學】命中 8'h23 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'h23: begin // RL A
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                                core_acc_data <= alu_out;
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                            8'h13, // RRC A
                            // 【教學】命中 8'h33 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'h33: begin // RLC A
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                                core_acc_data <= alu_out;

                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】將 {alu_cy_out, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                                core_psw_data <= {alu_cy_out, psw_in[6:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // JMP @A+DPTR
                            // -------------------------------------------------
                            // 【教學】命中 8'h73 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'h73: begin
                                // 【教學】pc ← dptr_in + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                                pc       <= dptr_in + {8'h00, acc_in};
                                // 【教學】rom_addr ← dptr_in + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                                rom_addr <= dptr_in + {8'h00, acc_in};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // DIV AB
                            // -------------------------------------------------
                            // 【教學】命中 8'h84 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'h84: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we <= 1'b1;
                                // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_b_we   <= 1'b1;

                                // 【教學】條件成立才走後續分支；b_in=目前 B 儲存值。沒有選此分支時依 else 或保持規則處理。
                                if (b_in != 8'h00) begin
                                    // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in / b_in；acc_in=目前 ACC 儲存值；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                                    core_acc_data <= acc_in / b_in;
                                    // 【教學】core_b_data（CPU 寫回 B 的新值）← acc_in % b_in；acc_in=目前 ACC 儲存值；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                                    core_b_data   <= acc_in % b_in;
                                // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                                end else begin
                                    // A/B result is undefined on divide-by-zero.
                                    // Preserve current values, assert OV.
                                    // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                                    core_acc_data <= acc_in;
                                    // 【教學】core_b_data（CPU 寫回 B 的新值）← b_in；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                                    core_b_data   <= b_in;
                                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                                end

                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                                core_psw_data <= {1'b0, psw_in[6:3],
                                                  // 【教學】本行是持續接線或跨行表達式的一部分。b_in=目前 B 儲存值。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                                  (b_in == 8'h00),
                                                  // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                                  psw_in[1:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // INC DPTR
                            // -------------------------------------------------
                            // 【教學】命中 8'hA3 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hA3: begin
                                // 【教學】core_dptr_we（CPU 寫回 DPTR 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_dptr_we   <= 1'b1;
                                // 【教學】新 DPTR 取 dptr_in + 16'd1，用 16 位路徑避免只更新一半資料指標。
                                core_dptr_data <= dptr_in + 16'd1;
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // MUL AB
                            // -------------------------------------------------
                            // 【教學】命中 8'hA4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hA4: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← mul_product[7:0]；mul_product=A 乘 B 的完整十六位結果；<= 讀本拍舊值並延後提交。
                                core_acc_data <= mul_product[7:0];

                                // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_b_we     <= 1'b1;
                                // 【教學】core_b_data（CPU 寫回 B 的新值）← mul_product[15:8]；mul_product=A 乘 B 的完整十六位結果；<= 讀本拍舊值並延後提交。
                                core_b_data   <= mul_product[15:8];

                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                                core_psw_data <= {1'b0, psw_in[6:3],
                                                  // 【教學】本行是持續接線或跨行表達式的一部分。mul_product=A 乘 B 的完整十六位結果。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                                  (mul_product[15:8] != 8'h00),
                                                  // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                                  psw_in[1:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // Carry operations
                            // -------------------------------------------------
                            // 【教學】命中 8'hB3 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hB3: begin // CPL C
                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】將 {~psw_in[7], psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                                core_psw_data <= {~psw_in[7], psw_in[6:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // 【教學】命中 8'hC3 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hC3: begin // CLR C
                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】將 {1'b0, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                                core_psw_data <= {1'b0, psw_in[6:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // 【教學】命中 8'hD3 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hD3: begin // SETB C
                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】將 {1'b1, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                                core_psw_data <= {1'b1, psw_in[6:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // SWAP A
                            // -------------------------------------------------
                            // 【教學】命中 8'hC4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hC4: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← {acc_in[3:0], acc_in[7:4]}；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                                core_acc_data <= {acc_in[3:0], acc_in[7:4]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // DA A
                            // -------------------------------------------------
                            // 【教學】命中 8'hD4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hD4: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← da_result9[7:0]；da_result9=BCD 調整完成的九位值，最高位供 CY；<= 讀本拍舊值並延後提交。
                                core_acc_data <= da_result9[7:0];

                                // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_psw_we   <= 1'b1;
                                // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                                core_psw_data <= {da_result9[8] | da_add_high,
                                                  // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                                  psw_in[6:0]};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // CLR A
                            // -------------------------------------------------
                            // 【教學】命中 8'hE4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hE4: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
                                core_acc_data <= 8'h00;
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // -------------------------------------------------
                            // CPL A
                            // -------------------------------------------------
                            // 【教學】命中 8'hF4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            8'hF4: begin
                                // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                                core_acc_we   <= 1'b1;
                                // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← ~acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                                core_acc_data <= ~acc_in;
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end

                            // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                            default: begin
                                // Should never occur because fast_1byte gates it.
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                        endcase

                    // 【教學】條件成立才走後續分支；fast_rn_read=可直接算出 Rn 地址再讀運算元的集合。else if 與先前分支互斥，先命中者優先。
                    end else if (fast_rn_read) begin
                        // DJNZ Rn is two bytes: capture rel while issuing read.
                        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。op1（指令的第二 byte）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                        if (ucode_bytes == 2'd2) op1 <= rom_data;
                        // 【教學】ram_addr ← {psw_in[4:3], ucode_addr[2:0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], ucode_addr[2:0]};
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度；fast_rn_write=可直接把 A 寫到 Rn 的集合。else if 與先前分支互斥，先命中者優先。
                    end else if ((ucode_bytes == 2'd1) && fast_rn_write) begin
                        // MOV Rn,A does not need to read the old Rn value.
                        // 【教學】ram_addr ← {psw_in[4:3], ucode_addr[2:0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr    <= {psw_in[4:3], ucode_addr[2:0]};
                        // 【教學】ram_wr_data（共用資料寫入值）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= acc_in;
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;
                        // 【教學】pc ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                        pc          <= pc + 16'd1;
                        // 【教學】rom_addr ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                        rom_addr    <= pc + 16'd1;
                        // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                        state       <= S_FETCH_OP;

                    // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度；fast_2byte=能走三拍快速路徑的立即值／相對跳轉集合。else if 與先前分支互斥，先命中者優先。
                    end else if ((ucode_bytes == 2'd2) && fast_2byte) begin
                        // Capture the only operand byte and execute next cycle.
                        // 【教學】op1（指令的第二 byte）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                        op1      <= rom_data;
                        // 【教學】state 排定為 S_FAST_IMM_EXEC（執行不需資料 RAM 的兩 byte 指令），下一個時鐘才依新狀態工作。
                        state    <= S_FAST_IMM_EXEC;

                    // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_bytes >= 2'd2) begin
                        // 【教學】op1（指令的第二 byte）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                        op1      <= rom_data;
                        // 【教學】rom_addr ← pc + 2'd2：讓程式位址與核心 PC 對齊。
                        rom_addr <= pc + 2'd2;
                        // 【教學】state 排定為 (ucode_bytes == 2'd3) ? S_FETCH_B3 : S_DECODE_ST（ucode_bytes=微碼解出的指令長度；S_FETCH_B3=取第三 byte，之後進定址解碼；S_DECODE_ST=按指令來源／目的決定 IRAM、SFR、堆疊或外部存取），下一個時鐘才依新狀態工作。
                        state    <= (ucode_bytes == 2'd3) ? S_FETCH_B3 : S_DECODE_ST;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】state 排定為 S_DECODE_ST（按指令來源／目的決定 IRAM、SFR、堆疊或外部存取），下一個時鐘才依新狀態工作。
                        state    <= S_DECODE_ST;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_FETCH_B3：取第三 byte，之後進定址解碼。後續列出本分支的指派，state 變更於下一拍生效。
                S_FETCH_B3: begin
                    // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_bytes == 2'd3) begin
                        // 【教學】op2（指令的第三 byte）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                        op2 <= rom_data;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】state 排定為 S_DECODE_ST（按指令來源／目的決定 IRAM、SFR、堆疊或外部存取），下一個時鐘才依新狀態工作。
                    state <= S_DECODE_ST;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_FAST_IMM_EXEC：執行不需資料 RAM 的兩 byte 指令。後續列出本分支的指派，state 變更於下一拍生效。
                S_FAST_IMM_EXEC: begin
                    // Default sequential next instruction after a 2-byte op.
                    // 【教學】pc ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                    pc       <= pc + 16'd2;
                    // 【教學】rom_addr ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                    rom_addr <= pc + 16'd2;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state    <= S_FETCH_OP;

                    // 【教學】依 ucode_addr 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (ucode_addr)

                        // 【教學】命中 8'h24 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h24: begin // ADD A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in + op1；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；增加固定寬度的計數／資料，超出位寬的進位須另行保存；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in + op1;

                            // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_psw_we <= 1'b1;
                            // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                            core_psw_data <= {
                                // 【教學】接續 PSW 或快速運算的跨行表達式；fast_add9=快速 ADD 的九位結果，包含 CY；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                fast_add9[8],
                                // 【教學】接續 PSW 或快速運算的跨行表達式；fast_add4=快速 ADD 的五位低半結果，包含 AC；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                fast_add4[4],
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[5:3],
                                // 【教學】本行是持續接線或跨行表達式的一部分。acc_in=目前 ACC 儲存值；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                ((acc_in[7] == op1[7]) &&
                                 // 【教學】接續 PSW 或快速運算的跨行表達式；fast_add_res=ADD 八位結果，供符號溢位判斷；acc_in=目前 ACC 儲存值；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                 (fast_add_res[7] != acc_in[7])),
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[1:0]
                            // 【教學】結束跨行的位元串接與指派；各段由高位排到低位，必須與左側位寬及 PSW 欄位位置一致。
                            };
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h34 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h34: begin // ADDC A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in + op1 + psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；增加固定寬度的計數／資料，超出位寬的進位須另行保存；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in + op1 + psw_in[7];

                            // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_psw_we <= 1'b1;
                            // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                            core_psw_data <= {
                                // 【教學】接續 PSW 或快速運算的跨行表達式；fast_addc9=快速 ADDC 的九位結果，包含輸入 CY；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                fast_addc9[8],
                                // 【教學】接續 PSW 或快速運算的跨行表達式；fast_addc4=快速 ADDC 低半五位結果；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                fast_addc4[4],
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[5:3],
                                // 【教學】本行是持續接線或跨行表達式的一部分。acc_in=目前 ACC 儲存值；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                ((acc_in[7] == op1[7]) &&
                                 // 【教學】接續 PSW 或快速運算的跨行表達式；fast_addc_res=ADDC 八位結果，供符號溢位判斷；acc_in=目前 ACC 儲存值；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                 (fast_addc_res[7] != acc_in[7])),
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[1:0]
                            // 【教學】結束跨行的位元串接與指派；各段由高位排到低位，必須與左側位寬及 PSW 欄位位置一致。
                            };
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h44 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h44: begin // ORL A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in | op1；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；逐位遮罩保留不應改變的位元；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in | op1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h54 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h54: begin // ANL A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in & op1；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；逐位遮罩保留不應改變的位元；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in & op1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h64 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h64: begin // XRL A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in ^ op1；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；XOR 可用來反相選定位或計算 parity；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in ^ op1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h74 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h74: begin // MOV A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← op1；op1=指令的第二 byte；<= 讀本拍舊值並延後提交。
                            core_acc_data <= op1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h94 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h94: begin // SUBB A,#data
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in - op1 - psw_in[7]；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；減法依目前位寬截斷，旗標需另外計算；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in - op1 - psw_in[7];

                            // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_psw_we <= 1'b1;
                            // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                            core_psw_data <= {
                                // 【教學】接續 PSW 或快速運算的跨行表達式；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                ({1'b0,acc_in} < ({1'b0,op1}+psw_in[7])),
                                // 【教學】接續 PSW 或快速運算的跨行表達式；acc_in=目前 ACC 儲存值；op1=指令的第二 byte；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                ({1'b0,acc_in[3:0]} < ({1'b0,op1[3:0]}+psw_in[7])),
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[5:3],
                                // 【教學】本行是持續接線或跨行表達式的一部分。acc_in=目前 ACC 儲存值；op1=指令的第二 byte。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                ((acc_in[7] != op1[7]) &&
                                 // 【教學】接續 PSW 或快速運算的跨行表達式；fast_subb_res=SUBB 八位結果，供符號溢位判斷；acc_in=目前 ACC 儲存值；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                 (fast_subb_res[7] != acc_in[7])),
                                // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                psw_in[1:0]
                            // 【教學】結束跨行的位元串接與指派；各段由高位排到低位，必須與左側位寬及 PSW 欄位位置一致。
                            };
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h80 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h80: begin // SJMP rel
                            // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd2 + {{8{op1[7]}},op1};
                            // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd2 + {{8{op1[7]}},op1};
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h40 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h40: begin // JC rel
                            // 【教學】條件成立才走後續分支；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。沒有選此分支時依 else 或保持規則處理。
                            if (psw_in[7]) begin
                                // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + 16'd2 + {{8{op1[7]}},op1};
                                // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + 16'd2 + {{8{op1[7]}},op1};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h50 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h50: begin // JNC rel
                            // 【教學】條件成立才走後續分支；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。沒有選此分支時依 else 或保持規則處理。
                            if (!psw_in[7]) begin
                                // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + 16'd2 + {{8{op1[7]}},op1};
                                // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + 16'd2 + {{8{op1[7]}},op1};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h60 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h60: begin // JZ rel
                            // 【教學】條件成立才走後續分支；acc_in=目前 ACC 儲存值。沒有選此分支時依 else 或保持規則處理。
                            if (acc_in == 8'h00) begin
                                // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + 16'd2 + {{8{op1[7]}},op1};
                                // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + 16'd2 + {{8{op1[7]}},op1};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 8'h70 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        8'h70: begin // JNZ rel
                            // 【教學】條件成立才走後續分支；acc_in=目前 ACC 儲存值。沒有選此分支時依 else 或保持規則處理。
                            if (acc_in != 8'h00) begin
                                // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + 16'd2 + {{8{op1[7]}},op1};
                                // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}},op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + 16'd2 + {{8{op1[7]}},op1};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        default: begin
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_DECODE_ST：按指令來源／目的決定 IRAM、SFR、堆疊或外部存取。後續列出本分支的指派，state 變更於下一拍生效。
                S_DECODE_ST: begin
                    // =========================================================
                    // 重要：讀取來源(Source)必須優先於目的(Destination)。
                    //
                    // 例如 0x88~0x8F = MOV direct,Rn：
                    //   src_sel = SEL_REG
                    //   dst_sel = SEL_DIR
                    // 若先判斷 dst_sel==SEL_DIR，會錯誤讀取 op1(destination)，
                    // 而不是讀取 Rn，造成寫入值變成 destination 原本的內容(常為 00)。
                    // =========================================================

                    // ---------------------------------------------------------
                    // POP direct: read the current top-of-stack first.
                    // ---------------------------------------------------------
                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_jmp_type == 3'd7) begin
                        // CALL pushes return low byte first, then high byte.
                        // 【教學】ram_addr ← sp_in + 8'd1：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                        ram_addr    <= sp_in + 8'd1;
                        // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                        ram_indirect <= 1'b1;
                        // 【教學】ram_wr_data（共用資料寫入值）← return_pc[7:0]；return_pc=本指令結束後的循序 PC，也作 CALL 的返回位址；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= return_pc[7:0];
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;
                        // 【教學】state 排定為 S_CALL_HIGH（CALL 已壓返回低 byte，再壓高 byte 並跳轉），下一個時鐘才依新狀態工作。
                        state       <= S_CALL_HIGH;
                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type == 3'd6) begin
                        // Stack top contains the return address high byte.
                        // 【教學】ram_addr ← sp_in：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                        ram_addr  <= sp_in;
                        // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                        ram_indirect <= 1'b1;
                        // 【教學】要求資料讀取後轉到 S_RET_HIGH；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_RET_HIGH);
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h75 || ucode_addr == 8'hF5 ||
                                 // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                 (ucode_addr >= 8'h78 && ucode_addr <= 8'h7F)) begin
                        // Pure writes never read the destination's old value.
                        // 【教學】開始跨行的時序指派。ram_addr ← (ucode_dst_sel == SEL_REG) ?：選定資料讀寫位址，之後由頂層區分 IRAM/SFR；後續行接完選擇式才構成完整右運算式。
                        ram_addr <= (ucode_dst_sel == SEL_REG) ?
                                    // 【教學】接續前一行 opcode 的判斷／指令集合；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；ucode_addr=本指令 opcode 鎖存值；op1=指令的第二 byte；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                    {3'b000, psw_in[4:3], ucode_addr[2:0]} : op1;
                        // 【教學】開始跨行的時序指派。ram_wr_data（共用資料寫入值）← (ucode_addr == 8'hF5) ? acc_in :；ucode_addr=本指令 opcode 鎖存值；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交；後續行接完選擇式才構成完整右運算式。
                        ram_wr_data <= (ucode_addr == 8'hF5) ? acc_in :
                                       // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；op2=指令的第三 byte；op1=指令的第二 byte；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                       (ucode_addr == 8'h75) ? op2 : op1;
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en <= 1'b1;
                        // 【教學】pc ← return_pc：讓程式位址與核心 PC 對齊。
                        pc        <= return_pc;
                        // 【教學】rom_addr ← return_pc：讓程式位址與核心 PC 對齊。
                        rom_addr  <= return_pc;
                        // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                        state     <= S_FETCH_OP;
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hD0) begin
                        // 【教學】ram_addr ← sp_in：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                        ram_addr  <= sp_in;
                        // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                        ram_indirect <= 1'b1;
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // ---------------------------------------------------------
                    // MOVX @DPTR
                    // ---------------------------------------------------------
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hE0 || ucode_addr == 8'hF0) begin
                        // 【教學】ext_ram_addr（MOVX 的十六位邏輯資料地址）← dptr_in；dptr_in=目前資料指標；<= 讀本拍舊值並延後提交。
                        ext_ram_addr <= dptr_in;

                        // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                        if (ucode_addr == 8'hE0) begin
                            // 【教學】ext_ram_rd_en（MOVX 讀取使能，讀資料需在 capture 前穩定）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ext_ram_rd_en <= 1'b1;
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】ext_ram_wr_data（MOVX 寫出的 byte）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                            ext_ram_wr_data <= acc_in;
                            // 【教學】ext_ram_wr_en（一次 MOVX 寫使能）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ext_ram_wr_en   <= 1'b1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                        // 【教學】state 排定為 S_XRAM_WAIT（讓 XRAM 控制／資料保持完整週期），下一個時鐘才依新狀態工作。
                        state <= S_XRAM_WAIT;

                    // ---------------------------------------------------------
                    // MOVX @R0/@R1: first read R0/R1 from selected register bank.
                    // Optional paging uses the P2 latch; legacy mode uses page zero.
                    // ---------------------------------------------------------
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hE2 || ucode_addr == 8'hE3 ||
                                 // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                 ucode_addr == 8'hF2 || ucode_addr == 8'hF3) begin
                        // 【教學】ram_addr ← {psw_in[4:3], 2'b00, ucode_addr[0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], 2'b00, ucode_addr[0]};
                        // 【教學】要求資料讀取後轉到 S_XRAM_PTR_WAIT；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_XRAM_PTR_WAIT);

                    // MOVC needs a second program-ROM access.
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h83) begin
                        // 【教學】rom_addr ← pc + 16'd1 + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                        rom_addr <= pc + 16'd1 + {8'h00, acc_in};
                        // 【教學】state 排定為 S_MOVC_CAPTURE（取得第二次程式 ROM 讀值，作 MOVC 結果），下一個時鐘才依新狀態工作。
                        state    <= S_MOVC_CAPTURE;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h93) begin
                        // 【教學】rom_addr ← dptr_in + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                        rom_addr <= dptr_in + {8'h00, acc_in};
                        // 【教學】state 排定為 S_MOVC_CAPTURE（取得第二次程式 ROM 讀值，作 MOVC 結果），下一個時鐘才依新狀態工作。
                        state    <= S_MOVC_CAPTURE;

                    // 0. Source 是 bit：先讀 bit-addressable IRAM 所在 byte
                    //    JBC/JB/JNB bit addresses 00H~7FH map to IRAM 20H~2FH.
                    // 【教學】條件成立才走後續分支；ucode_src_sel=解碼後的來源定址方式；SEL_BIT=位元位址運算元。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_src_sel == SEL_BIT) begin
                        // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr  <= bit_byte_addr;
                        // 【教學】開始跨行的時序指派。ram_rmw 設為 (ucode_addr == 8'h10 || ucode_addr == 8'h92 ||；RMW 必須讀 GPIO latch，避免外部拉低 pin 改寫原本輸出值；後續行接完選擇式才構成完整右運算式。
                        ram_rmw   <= (ucode_addr == 8'h10 || ucode_addr == 8'h92 ||
                                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                      ucode_addr == 8'hB2 || ucode_addr == 8'hC2 ||
                                      // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                      ucode_addr == 8'hD2);
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // 1. Source 是 indirect：先取得 R0/R1 指標，再讀真正資料
                    // 【教學】條件成立才走後續分支；ucode_src_sel=解碼後的來源定址方式；SEL_IND=R0/R1 間接地址。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_src_sel == SEL_IND) begin
                        // 【教學】ram_addr ← {psw_in[4:3], 2'b00, ucode_addr[0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], 2'b00, ucode_addr[0]};
                        // 【教學】要求資料讀取後轉到 S_DECODE_IND；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_DECODE_IND);

                    // 2. Source 是 register：MOV direct,Rn / ALU A,Rn 等
                    // 【教學】條件成立才走後續分支；ucode_src_sel=解碼後的來源定址方式；SEL_REG=目前 PSW bank 的 R0～R7。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_src_sel == SEL_REG) begin
                        // 【教學】ram_addr ← {psw_in[4:3], ucode_addr[2:0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], ucode_addr[2:0]};
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // 3. Source 是 direct：MOV direct,direct / ALU A,direct 等
                    //    0x85 的 op1 就是 source direct；write-back 時 op2 是 destination。
                    // 【教學】條件成立才走後續分支；ucode_src_sel=解碼後的來源定址方式；SEL_DIR=直接 byte 地址。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_src_sel == SEL_DIR) begin
                        // 【教學】ram_addr ← op1：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr  <= op1;
                        // 【教學】ram_rmw 設為 direct_rmw；RMW 必須讀 GPIO latch，避免外部拉低 pin 改寫原本輸出值。
                        ram_rmw   <= direct_rmw;
                        // 【教學】要求資料讀取後轉到 (ucode_addr == 8'hA6 || ucode_addr == 8'hA7；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read((ucode_addr == 8'hA6 || ucode_addr == 8'hA7) ?
                                       // 【教學】狀態 S_MOV_IND_SRC：保存 MOV @Ri,direct 的來源，再去取 Ri 指標。此分支沒有其他指派，沿用預設控制或保持時序舊值。
                                       S_MOV_IND_SRC : S_EXEC);

                    // 4. Source 不需 RAM，但 destination 是 indirect。
                    //    例如 MOV @Ri,A / MOV @Ri,#data，需要先取得 Ri 指標。
                    // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_IND=R0/R1 間接地址。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_dst_sel == SEL_IND) begin
                        // 【教學】ram_addr ← {psw_in[4:3], 2'b00, ucode_addr[0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], 2'b00, ucode_addr[0]};
                        // 【教學】要求資料讀取後轉到 S_DECODE_IND；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_DECODE_IND);

                    // 5. Destination 是 direct 且 operation 需要原值。
                    //    例如 ORL direct,A / ANL direct,A / INC direct。
                    // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_DIR=直接 byte 地址。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_dst_sel == SEL_DIR) begin
                        // 【教學】ram_addr ← op1：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr  <= op1;
                        // 【教學】ram_rmw 設為 direct_rmw；RMW 必須讀 GPIO latch，避免外部拉低 pin 改寫原本輸出值。
                        ram_rmw   <= direct_rmw;
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // 6. Destination 是 register 且 operation 需要原值。
                    //    例如 INC Rn / DEC Rn。
                    // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_REG=目前 PSW bank 的 R0～R7。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_dst_sel == SEL_REG) begin
                        // 【教學】ram_addr ← {psw_in[4:3], ucode_addr[2:0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                        ram_addr  <= {psw_in[4:3], ucode_addr[2:0]};
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);

                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】state 排定為 S_EXEC（一般指令運算、跳轉與產生寫回），下一個時鐘才依新狀態工作。
                        state <= S_EXEC;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_RAM_WAIT：配合流水 RAM 多等一拍，避免使用上一筆讀值。後續列出本分支的指派，state 變更於下一拍生效。
                S_RAM_WAIT: begin
                    // 【教學】state 排定為 state_after_ram_read（state_after_ram_read=流水 RAM 額外等待一拍後應回到的狀態），下一個時鐘才依新狀態工作。
                    state <= state_after_ram_read;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_DECODE_IND：Ri 指標已讀出，準備讀寫它指向的地址。後續列出本分支的指派，state 變更於下一拍生效。
                S_DECODE_IND: begin
                    // 【教學】ram_addr ← ram_rd_data：把先前讀出的 Ri 當指標，這是第二階段間接定址。
                    ram_addr <= ram_rd_data;
                    // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b1;
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'h76 || ucode_addr == 8'h77 ||
                        // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                        ucode_addr == 8'hF6 || ucode_addr == 8'hF7) begin
                        // Pointer is ready; MOV does not need pointed data.
                        // 【教學】ram_wr_data（共用資料寫入值）← alu_b；alu_b=送入 ALU 右端的值；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= alu_b;
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;
                        // 【教學】pc ← return_pc：讓程式位址與核心 PC 對齊。
                        pc          <= return_pc;
                        // 【教學】rom_addr ← return_pc：讓程式位址與核心 PC 對齊。
                        rom_addr    <= return_pc;
                        // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                        state       <= S_FETCH_OP;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】要求資料讀取後轉到 S_EXEC；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                        issue_ram_read(S_EXEC);
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_MOV_IND_SRC：保存 MOV @Ri,direct 的來源，再去取 Ri 指標。後續列出本分支的指派，state 變更於下一拍生效。
                S_MOV_IND_SRC: begin
                    // Preserve source before changing the single read address.
                    // 【教學】mov_ind_src_data（MOV @Ri,direct 的來源資料暫存，避免讀 Ri 後遺失）← ram_rd_data；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                    mov_ind_src_data <= ram_rd_data;
                    // 【教學】ram_addr ← {psw_in[4:3], 2'b00, ucode_addr[0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                    ram_addr <= {psw_in[4:3], 2'b00, ucode_addr[0]};
                    // 【教學】要求資料讀取後轉到 S_MOV_IND_PTR_CAPTURE；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                    issue_ram_read(S_MOV_IND_PTR_CAPTURE);
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_MOV_IND_PTR_CAPTURE：已取得 Ri 指標，將先前保存的來源寫到目的地址。後續列出本分支的指派，state 變更於下一拍生效。
                S_MOV_IND_PTR_CAPTURE: begin
                    // 【教學】ram_addr ← ram_rd_data：把先前讀出的 Ri 當指標，這是第二階段間接定址。
                    ram_addr    <= ram_rd_data;
                    // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b1;
                    // 【教學】ram_wr_data（共用資料寫入值）← mov_ind_src_data；mov_ind_src_data=MOV @Ri,direct 的來源資料暫存，避免讀 Ri 後遺失；<= 讀本拍舊值並延後提交。
                    ram_wr_data <= mov_ind_src_data;
                    // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    ram_wr_en   <= 1'b1;
                    // 【教學】pc ← return_pc：讓程式位址與核心 PC 對齊。
                    pc          <= return_pc;
                    // 【教學】rom_addr ← return_pc：讓程式位址與核心 PC 對齊。
                    rom_addr    <= return_pc;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state       <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_CALL_HIGH：CALL 已壓返回低 byte，再壓高 byte 並跳轉。後續列出本分支的指派，state 變更於下一拍生效。
                S_CALL_HIGH: begin
                    // Low write commits at this edge; issue high write now.
                    // 【教學】ram_addr ← ram_addr + 8'd1：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                    ram_addr     <= ram_addr + 8'd1;
                    // 【教學】ram_wr_data（共用資料寫入值）← return_pc[15:8]；return_pc=本指令結束後的循序 PC，也作 CALL 的返回位址；<= 讀本拍舊值並延後提交。
                    ram_wr_data  <= return_pc[15:8];
                    // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    ram_wr_en    <= 1'b1;
                    // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    core_sp_we   <= 1'b1;
                    // 【教學】新 SP 取 sp_in + 8'd2，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
                    core_sp_data <= sp_in + 8'd2;
                    // 【教學】開始跨行的時序指派。pc ← (ucode_addr == 8'h12) ? {op1, op2} :：高位在前、低位在後組成 16-bit 絕對目標；後續行接完選擇式才構成完整右運算式。
                    pc <= (ucode_addr == 8'h12) ? {op1, op2} :
                          // 【教學】接續前一行 opcode 的判斷／指令集合；pc_after_2=目前 PC 加二，供 AJMP/ACALL 頁面計算；ucode_addr=本指令 opcode 鎖存值；op1=指令的第二 byte；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                          {pc_after_2[15:11], ucode_addr[7:5], op1};
                    // 【教學】開始跨行的時序指派。rom_addr ← (ucode_addr == 8'h12) ? {op1, op2} :：高位在前、低位在後組成 16-bit 絕對目標；後續行接完選擇式才構成完整右運算式。
                    rom_addr <= (ucode_addr == 8'h12) ? {op1, op2} :
                                // 【教學】接續前一行 opcode 的判斷／指令集合；pc_after_2=目前 PC 加二，供 AJMP/ACALL 頁面計算；ucode_addr=本指令 opcode 鎖存值；op1=指令的第二 byte；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                                {pc_after_2[15:11], ucode_addr[7:5], op1};
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_INT_LOW：中斷進入先準備壓 PC 低 byte。後續列出本分支的指派，state 變更於下一拍生效。
                S_INT_LOW: begin
                    // 【教學】ram_addr ← sp_in + 8'd1：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                    ram_addr    <= sp_in + 8'd1;
                    // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b1;
                    // 【教學】ram_wr_data（共用資料寫入值）← pc[7:0]；pc=下一次／目前指令的十六位程式計數；<= 讀本拍舊值並延後提交。
                    ram_wr_data <= pc[7:0];
                    // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    ram_wr_en   <= 1'b1;
                    // 【教學】state 排定為 S_INT_HIGH（再壓 PC 高 byte，跳向量並確認來源），下一個時鐘才依新狀態工作。
                    state       <= S_INT_HIGH;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_INT_HIGH：再壓 PC 高 byte，跳向量並確認來源。後續列出本分支的指派，state 變更於下一拍生效。
                S_INT_HIGH: begin
                    // 【教學】ram_addr ← sp_in + 8'd2：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                    ram_addr         <= sp_in + 8'd2;
                    // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b1;
                    // 【教學】ram_wr_data（共用資料寫入值）← pc[15:8]；pc=下一次／目前指令的十六位程式計數；<= 讀本拍舊值並延後提交。
                    ram_wr_data      <= pc[15:8];
                    // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    ram_wr_en        <= 1'b1;
                    // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    core_sp_we       <= 1'b1;
                    // 【教學】新 SP 取 sp_in + 8'd2，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
                    core_sp_data     <= sp_in + 8'd2;
                    // 【教學】pc ← pending_irq_vector：讓程式位址與核心 PC 對齊。
                    pc               <= pending_irq_vector;
                    // 【教學】rom_addr ← pending_irq_vector：讓程式位址與核心 PC 對齊。
                    rom_addr         <= pending_irq_vector;
                    // 【教學】irq_ack（主機已接受中斷的確認脈波）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
                    irq_ack          <= 1'b1;
                    // 【教學】irq_ack_priority（CPU 回報已接受的中斷等級）← pending_irq_priority；pending_irq_priority=待處理中斷的優先等級；<= 讀本拍舊值並延後提交。
                    irq_ack_priority <= pending_irq_priority;
                    // 【教學】irq_ack_source（已接受的 0～12 中斷來源編號）← pending_irq_source；pending_irq_source=待處理中斷來源編號；<= 讀本拍舊值並延後提交。
                    irq_ack_source   <= pending_irq_source;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state            <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_RET_HIGH：RET/RETI 先取堆疊高 byte，再讀低 byte。後續列出本分支的指派，state 變更於下一拍生效。
                S_RET_HIGH: begin
                    // 【教學】return_high（RET/RETI 從堆疊先取回的高 byte）← ram_rd_data；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                    return_high <= ram_rd_data;
                    // 【教學】ram_addr ← sp_in - 8'd1：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                    ram_addr    <= sp_in - 8'd1;
                    // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                    ram_indirect <= 1'b1;
                    // 【教學】要求資料讀取後轉到 S_RET_LOW；task 依 RAM_PIPELINED 決定是否先走 S_RAM_WAIT，避免過早使用資料。
                    issue_ram_read(S_RET_LOW);
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_RET_LOW：合成返回 PC、調整 SP，必要時通知 RETI。後續列出本分支的指派，state 變更於下一拍生效。
                S_RET_LOW: begin
                    // 【教學】pc ← {return_high, ram_rd_data}：把堆疊讀回的高低 byte 拼成返回目標。
                    pc            <= {return_high, ram_rd_data};
                    // 【教學】rom_addr ← {return_high, ram_rd_data}：把堆疊讀回的高低 byte 拼成返回目標。
                    rom_addr      <= {return_high, ram_rd_data};
                    // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    core_sp_we    <= 1'b1;
                    // 【教學】新 SP 取 sp_in - 8'd2，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
                    core_sp_data  <= sp_in - 8'd2;
                    // 【教學】reti_complete（RETI 完成的單拍通知；RET 不產生它）← (ucode_addr == 8'h32)；ucode_addr=本指令 opcode 鎖存值；<= 讀本拍舊值並延後提交。
                    reti_complete <= (ucode_addr == 8'h32);
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state         <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_MOVC_CAPTURE：取得第二次程式 ROM 讀值，作 MOVC 結果。後續列出本分支的指派，state 變更於下一拍生效。
                S_MOVC_CAPTURE: begin
                    // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    core_acc_we   <= 1'b1;
                    // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← rom_data；rom_data=程式記憶體讀出的 byte；<= 讀本拍舊值並延後提交。
                    core_acc_data <= rom_data;
                    // 【教學】pc ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                    pc            <= pc + 16'd1;
                    // 【教學】rom_addr ← pc + 16'd1：讓程式位址與核心 PC 對齊。
                    rom_addr      <= pc + 16'd1;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state         <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_XRAM_PTR_WAIT：取得 Ri 後組合 MOVX 外部地址。後續列出本分支的指派，state 變更於下一拍生效。
                S_XRAM_PTR_WAIT: begin
                    // ram_rd_data is R0/R1 and forms the low XRAM address byte.
                    // 【教學】ext_ram_addr（MOVX 的十六位邏輯資料地址）← {MOVX_RI_PAGED ? movx_page : 8'h00, ram_rd_data}；MOVX_RI_PAGED=是否用 movx_page 提供 MOVX @Ri 的高地址；movx_page=MOVX @Ri 的高地址 byte；基本整合接 P2 latch；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                    ext_ram_addr <= {MOVX_RI_PAGED ? movx_page : 8'h00, ram_rd_data};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'hE2 || ucode_addr == 8'hE3) begin
                        // 【教學】ext_ram_rd_en（MOVX 讀取使能，讀資料需在 capture 前穩定）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ext_ram_rd_en <= 1'b1;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】ext_ram_wr_data（MOVX 寫出的 byte）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        ext_ram_wr_data <= acc_in;
                        // 【教學】ext_ram_wr_en（一次 MOVX 寫使能）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ext_ram_wr_en   <= 1'b1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】state 排定為 S_XRAM_WAIT（讓 XRAM 控制／資料保持完整週期），下一個時鐘才依新狀態工作。
                    state <= S_XRAM_WAIT;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_XRAM_WAIT：讓 XRAM 控制／資料保持完整週期。後續列出本分支的指派，state 變更於下一拍生效。
                S_XRAM_WAIT: begin
                    // Hold the external bus controls for a full cycle.
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'hE0 || ucode_addr == 8'hE2 || ucode_addr == 8'hE3) begin
                        // 【教學】ext_ram_rd_en（MOVX 讀取使能，讀資料需在 capture 前穩定）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ext_ram_rd_en <= 1'b1;
                        // 【教學】state 排定為 S_XRAM_CAPTURE（取回 MOVX 讀值並回到取指），下一個時鐘才依新狀態工作。
                        state         <= S_XRAM_CAPTURE;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // The write issued in decode/pointer state commits
                        // at this edge. Do not issue a duplicate bus write.
                        // 【教學】pc ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                        pc             <= pc + ucode_bytes;
                        // 【教學】rom_addr ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                        rom_addr       <= pc + ucode_bytes;
                        // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                        state          <= S_FETCH_OP;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_XRAM_CAPTURE：取回 MOVX 讀值並回到取指。後續列出本分支的指派，state 變更於下一拍生效。
                S_XRAM_CAPTURE: begin
                    // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                    core_acc_we   <= 1'b1;
                    // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← ext_ram_rd_data；ext_ram_rd_data=外部 XRAM 回傳的 byte；<= 讀本拍舊值並延後提交。
                    core_acc_data <= ext_ram_rd_data;
                    // 【教學】pc ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                    pc            <= pc + ucode_bytes;
                    // 【教學】rom_addr ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                    rom_addr      <= pc + ucode_bytes;
                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state         <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】狀態 S_EXEC：一般指令運算、跳轉與產生寫回。後續列出本分支的指派，state 變更於下一拍生效。
                S_EXEC: begin
                    // 1. 跳轉計算
                    //
                    // Bit branches are special because op1 is bit address and
                    // op2 is relative displacement.
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'h10) begin
                        // JBC bit,rel : jump if bit=1, and clear the bit
                        // 【教學】條件成立才走後續分支；bit_value=本次讀取的單一位元。沒有選此分支時依 else 或保持規則處理。
                        if (bit_value) begin
                            // 【教學】pc ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd3 + {{8{op2[7]}}, op2};
                            // 【教學】rom_addr ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd3 + {{8{op2[7]}}, op2};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd3;
                            // 【教學】rom_addr ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd3;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h20) begin
                        // JB bit,rel : jump if bit=1
                        // 【教學】條件成立才走後續分支；bit_value=本次讀取的單一位元。沒有選此分支時依 else 或保持規則處理。
                        if (bit_value) begin
                            // 【教學】pc ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd3 + {{8{op2[7]}}, op2};
                            // 【教學】rom_addr ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd3 + {{8{op2[7]}}, op2};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd3;
                            // 【教學】rom_addr ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd3;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h30) begin
                        // JNB bit,rel : jump if bit=0
                        // 【教學】條件成立才走後續分支；bit_value=本次讀取的單一位元。沒有選此分支時依 else 或保持規則處理。
                        if (!bit_value) begin
                            // 【教學】pc ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd3 + {{8{op2[7]}}, op2};
                            // 【教學】rom_addr ← pc + 16'd3 + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd3 + {{8{op2[7]}}, op2};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd3;
                            // 【教學】rom_addr ← pc + 16'd3：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd3;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h40) begin
                        // JC rel : jump only when CY=1
                        // 【教學】條件成立才走後續分支；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。沒有選此分支時依 else 或保持規則處理。
                        if (psw_in[7]) begin
                            // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd2 + {{8{op1[7]}}, op1};
                            // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd2 + {{8{op1[7]}}, op1};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd2;
                            // 【教學】rom_addr ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd2;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h50) begin
                        // JNC rel : jump only when CY=0
                        // 【教學】條件成立才走後續分支；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。沒有選此分支時依 else 或保持規則處理。
                        if (!psw_in[7]) begin
                            // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd2 + {{8{op1[7]}}, op1};
                            // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd2 + {{8{op1[7]}}, op1};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd2;
                            // 【教學】rom_addr ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd2;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h60) begin
                        // JZ rel : jump only when A==0
                        // 【教學】條件成立才走後續分支；acc_in=目前 ACC 儲存值。沒有選此分支時依 else 或保持規則處理。
                        if (acc_in == 8'h00) begin
                            // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd2 + {{8{op1[7]}}, op1};
                            // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd2 + {{8{op1[7]}}, op1};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd2;
                            // 【教學】rom_addr ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd2;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h70) begin
                        // JNZ rel : jump only when A!=0
                        // 【教學】條件成立才走後續分支；acc_in=目前 ACC 儲存值。沒有選此分支時依 else 或保持規則處理。
                        if (acc_in != 8'h00) begin
                            // 【教學】pc ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            pc       <= pc + 16'd2 + {{8{op1[7]}}, op1};
                            // 【教學】rom_addr ← pc + 16'd2 + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                            rom_addr <= pc + 16'd2 + {{8{op1[7]}}, op1};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            pc       <= pc + 16'd2;
                            // 【教學】rom_addr ← pc + 16'd2：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + 16'd2;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h73) begin
                        // 0x73 is JMP @A+DPTR (NOT LJMP addr16)
                        // 【教學】pc ← dptr_in + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                        pc       <= dptr_in + {8'h00, acc_in};
                        // 【教學】rom_addr ← dptr_in + {8'h00, acc_in}：讓程式位址與核心 PC 對齊。
                        rom_addr <= dptr_in + {8'h00, acc_in};

                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type == 3'd3) begin
                        // LJMP addr16 (opcode 0x02)
                        // 【教學】pc ← {op1, op2}：高位在前、低位在後組成 16-bit 絕對目標。
                        pc       <= {op1, op2};
                        // 【教學】rom_addr ← {op1, op2}：高位在前、低位在後組成 16-bit 絕對目標。
                        rom_addr <= {op1, op2};

                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type == 3'd2) begin
                        // AJMP addr11
                        // target = {(PC+2)[15:11], opcode[7:5], imm8}
                        // PC here is the address of the AJMP opcode.
                        // 【教學】pc ← {pc_after_2[15:11], ucode_addr[7:5], op1}：AJMP/ACALL 的頁面取 PC+2 高五位，再拼 opcode 三位與立即值八位。
                        pc       <= {pc_after_2[15:11], ucode_addr[7:5], op1};
                        // 【教學】rom_addr ← {pc_after_2[15:11], ucode_addr[7:5], op1}：AJMP/ACALL 的頁面取 PC+2 高五位，再拼 opcode 三位與立即值八位。
                        rom_addr <= {pc_after_2[15:11], ucode_addr[7:5], op1};

                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type == 3'd1) begin
                        // SJMP rel
                        // 【教學】pc ← pc + ucode_bytes + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                        pc       <= pc + ucode_bytes + {{8{op1[7]}}, op1};
                        // 【教學】rom_addr ← pc + ucode_bytes + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                        rom_addr <= pc + ucode_bytes + {{8{op1[7]}}, op1};

                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type == 3'd4 || ucode_jmp_type == 3'd5) begin
                        // CJNE / DJNZ
                        // 【教學】條件成立才走後續分支；alu_out=八位運算結果。沒有選此分支時依 else 或保持規則處理。
                        if (alu_out != 8'h00) begin
                            // 【教學】條件成立才走後續分支；ucode_bytes=微碼解出的指令長度。沒有選此分支時依 else 或保持規則處理。
                            if (ucode_bytes == 2'd3) begin
                                // 【教學】pc ← pc + ucode_bytes + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + ucode_bytes + {{8{op2[7]}}, op2};
                                // 【教學】rom_addr ← pc + ucode_bytes + {{8{op2[7]}}, op2}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + ucode_bytes + {{8{op2[7]}}, op2};
                            // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                            end else begin
                                // 【教學】pc ← pc + ucode_bytes + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                pc       <= pc + ucode_bytes + {{8{op1[7]}}, op1};
                                // 【教學】rom_addr ← pc + ucode_bytes + {{8{op1[7]}}, op1}：將 8-bit rel 的符號位複製到高八位，才能正確向後跳；相對基準是下一指令位址。
                                rom_addr <= pc + ucode_bytes + {{8{op1[7]}}, op1};
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】pc ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                            pc       <= pc + ucode_bytes;
                            // 【教學】rom_addr ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                            rom_addr <= pc + ucode_bytes;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】pc ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                        pc       <= pc + ucode_bytes;
                        // 【教學】rom_addr ← pc + ucode_bytes：讓程式位址與核心 PC 對齊。
                        rom_addr <= pc + ucode_bytes;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end

                    // 2. 寫回處理
                    //
                    // XCH / XCHD are special because BOTH sides must be written
                    // in the same instruction.  The generic microcode write-back
                    // only supports one destination, which caused:
                    //   XCH  : ACC got operand, but operand stayed unchanged
                    //   XCHD : ACC got whole operand, no nibble exchange
                    //
                    // At S_EXEC, ram_rd_data is already the old operand value and
                    // ram_addr is still pointing at direct/@Ri/Rn source.
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'hD0) begin
                        // POP direct: write current stack byte, then decrement SP.
                        // 【教學】ram_addr ← op1：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr    <= op1;
                        // 【教學】ram_indirect ← 1'b0；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                        ram_indirect <= 1'b0;
                        // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= ram_rd_data;
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;

                        // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_sp_we   <= 1'b1;
                        // 【教學】新 SP 取 sp_in - 8'h01，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
                        core_sp_data <= sp_in - 8'h01;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hD2) begin
                        // SETB bit
                        // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr    <= bit_byte_addr;
                        // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data | (8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= ram_rd_data | (8'h01 << bit_index);
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hD4) begin
                        // Decimal adjust after ADD/ADDC.
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← da_result9[7:0]；da_result9=BCD 調整完成的九位值，最高位供 CY；<= 讀本拍舊值並延後提交。
                        core_acc_data <= da_result9[7:0];

                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                        core_psw_data <= {da_result9[8] | da_add_high,
                                          // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                          psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hF4) begin
                        // CPL A
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← ~acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        core_acc_data <= ~acc_in;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hA0) begin
                        // ORL C,/bit
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {psw_in[7] | ~bit_value, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {psw_in[7] | ~bit_value, psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hB0) begin
                        // ANL C,/bit
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {psw_in[7] & ~bit_value, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {psw_in[7] & ~bit_value, psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hA2) begin
                        // MOV C,bit
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {bit_value, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {bit_value, psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hB2) begin
                        // CPL bit
                        // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr    <= bit_byte_addr;
                        // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data ^ (8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= ram_rd_data ^ (8'h01 << bit_index);
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hC2) begin
                        // CLR bit
                        // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr    <= bit_byte_addr;
                        // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data & ~(8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= ram_rd_data & ~(8'h01 << bit_index);
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hB3) begin
                        // CPL C
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {~psw_in[7], psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {~psw_in[7], psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hA4) begin
                        // MUL AB:
                        // product low byte -> A, high byte -> B
                        // CY=0, OV=1 when high byte != 0
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← mul_product[7:0]；mul_product=A 乘 B 的完整十六位結果；<= 讀本拍舊值並延後提交。
                        core_acc_data <= mul_product[7:0];
                        // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_b_we     <= 1'b1;
                        // 【教學】core_b_data（CPU 寫回 B 的新值）← mul_product[15:8]；mul_product=A 乘 B 的完整十六位結果；<= 讀本拍舊值並延後提交。
                        core_b_data   <= mul_product[15:8];

                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                        core_psw_data <= {1'b0, psw_in[6:3],
                                          // 【教學】本行是持續接線或跨行表達式的一部分。mul_product=A 乘 B 的完整十六位結果。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                                          (mul_product[15:8] != 8'h00),
                                          // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                          psw_in[1:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hC4) begin
                        // SWAP A
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← {acc_in[3:0], acc_in[7:4]}；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        core_acc_data <= {acc_in[3:0], acc_in[7:4]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hC0) begin
                        // PUSH direct:
                        // increment SP first, then write source byte to new SP.
                        // 【教學】core_sp_we（CPU 寫回 SP 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_sp_we   <= 1'b1;
                        // 【教學】新 SP 取 sp_in + 8'h01，與已安排的堆疊 byte 存取數量一致；不可只移地址而忘記更新架構 SP。
                        core_sp_data <= sp_in + 8'h01;

                        // 【教學】ram_addr ← sp_in + 8'h01：依 SP 找堆疊位置；8051 PUSH 先加 SP、POP/RET 先讀目前 SP。
                        ram_addr    <= sp_in + 8'h01;
                        // 【教學】ram_indirect ← 1'b1；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                        ram_indirect <= 1'b1;
                        // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                        ram_wr_data <= ram_rd_data;
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en   <= 1'b1;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h72) begin
                        // ORL C,bit
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {psw_in[7] | bit_value, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {psw_in[7] | bit_value, psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h82) begin
                        // ANL C,bit
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {psw_in[7] & bit_value, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {psw_in[7] & bit_value, psw_in[6:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h92) begin
                        // MOV bit,C
                        // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                        ram_addr <= bit_byte_addr;
                        // 【教學】條件成立才走後續分支；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2。沒有選此分支時依 else 或保持規則處理。
                        if (psw_in[7])
                            // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data | (8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= ram_rd_data | (8'h01 << bit_index);
                        // 【教學】前一個 if 不成立才執行下一個敘述；沒有 begin 時只包含緊接的一個敘述，縮排不能代替語法範圍。
                        else
                            // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data & ~(8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= ram_rd_data & ~(8'h01 << bit_index);
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en <= 1'b1;

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h84) begin
                        // DIV AB
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we <= 1'b1;
                        // 【教學】core_b_we（CPU 寫回 B 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_b_we   <= 1'b1;

                        // 【教學】條件成立才走後續分支；b_in=目前 B 儲存值。沒有選此分支時依 else 或保持規則處理。
                        if (b_in != 8'h00) begin
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in / b_in；acc_in=目前 ACC 儲存值；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in / b_in;
                            // 【教學】core_b_data（CPU 寫回 B 的新值）← acc_in % b_in；acc_in=目前 ACC 儲存值；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                            core_b_data   <= acc_in % b_in;
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                            core_acc_data <= acc_in;
                            // 【教學】core_b_data（CPU 寫回 B 的新值）← b_in；b_in=目前 B 儲存值；<= 讀本拍舊值並延後提交。
                            core_b_data   <= b_in;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // CY=0 always; OV=1 only on divide by zero.
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 {1'b0, psw_in[6:3], (b_in == 8'h00), psw_in[1:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= {1'b0, psw_in[6:3], (b_in == 8'h00), psw_in[1:0]};

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'h10) begin
                        // JBC clears the tested bit only when it was set.
                        // 【教學】條件成立才走後續分支；bit_value=本次讀取的單一位元。沒有選此分支時依 else 或保持規則處理。
                        if (bit_value) begin
                            // 【教學】ram_addr ← bit_byte_addr：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                            ram_addr    <= bit_byte_addr;
                            // 【教學】ram_wr_data（共用資料寫入值）← ram_rd_data & ~(8'h01 << bit_index)；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；bit_index=byte 內 bit0～7 的位置；左移 1 形成單一 bit 遮罩，只更新指定 bit；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= ram_rd_data & ~(8'h01 << bit_index);
                            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ram_wr_en   <= 1'b1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr >= 8'hC5 && ucode_addr <= 8'hCF) begin
                        // -----------------------------------------------------
                        // XCH A,direct / XCH A,@Ri / XCH A,Rn
                        // -----------------------------------------------------
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← ram_rd_data；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；<= 讀本拍舊值並延後提交。
                        core_acc_data <= ram_rd_data; // operand old value -> A

                        // 【教學】ram_wr_data（共用資料寫入值）← acc_in；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        ram_wr_data   <= acc_in;      // A old value -> operand
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en     <= 1'b1;

                        // ram_addr is already correct from decode:
                        // C5    : direct address
                        // C6/C7 : resolved @R0/@R1 address
                        // C8-CF : selected register address

                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hD6 || ucode_addr == 8'hD7) begin
                        // -----------------------------------------------------
                        // XCHD A,@Ri : exchange LOW nibbles only
                        //
                        // Example:
                        //   A=AB, @Ri=3C
                        //   A   -> AC
                        //   @Ri -> 3B
                        // -----------------------------------------------------
                        // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_acc_we   <= 1'b1;
                        // 【教學】新 A 取 {acc_in[7:4], ram_rd_data[3:0]}，以半 byte 串接實作 XCHD 等只交換低四位的指令，保留高四位。
                        core_acc_data <= {acc_in[7:4], ram_rd_data[3:0]};

                        // 【教學】ram_wr_data（共用資料寫入值）← {ram_rd_data[7:4], acc_in[3:0]}；ram_rd_data=頂層選回的 IRAM 或 SFR 資料；acc_in=目前 ACC 儲存值；<= 讀本拍舊值並延後提交。
                        ram_wr_data   <= {ram_rd_data[7:4], acc_in[3:0]};
                        // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        ram_wr_en     <= 1'b1;

                        // ram_addr is already the resolved indirect address.

                    // Filter CJNE so comparison result is not written back.
                    // 【教學】條件成立才走後續分支；ucode_jmp_type=解碼後的跳轉種類。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_jmp_type != 3'd4) begin
                        // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_ACC=累加器 A。沒有選此分支時依 else 或保持規則處理。
                        if (ucode_dst_sel == SEL_ACC) begin
                            // 【教學】core_acc_we（CPU 寫回 ACC 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_acc_we   <= 1'b1;
                            // 【教學】core_acc_data（CPU 寫回 ACC 的新值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                            core_acc_data <= alu_out;
                        // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_DIR=直接 byte 地址。else if 與先前分支互斥，先命中者優先。
                        end else if (ucode_dst_sel == SEL_DIR) begin
                            // 修正 0x85 (MOV direct, direct) 的寫入位址必須對準 op2
                            // 【教學】ram_addr ← (ucode_addr == 8'h85) ? op2 : op1：選定資料讀寫位址，之後由頂層區分 IRAM/SFR。
                            ram_addr    <= (ucode_addr == 8'h85) ? op2 : op1;
                            // 【教學】ram_indirect ← 1'b0；間接／堆疊必須選 IRAM，尤其地址 bit7=1 時不能誤選直接 SFR。
                            ram_indirect <= 1'b0;
                            // 【教學】ram_wr_data（共用資料寫入值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= alu_out;
                            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ram_wr_en   <= 1'b1;
                        // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_REG=目前 PSW bank 的 R0～R7。else if 與先前分支互斥，先命中者優先。
                        end else if (ucode_dst_sel == SEL_REG) begin
                            // 【教學】ram_addr ← {psw_in[4:3], ucode_addr[2:0]}：PSW.RS1/RS0 決定四組 register bank，再拼 Rn 的三位索引，不能固定只讀 bank0。
                            ram_addr    <= {psw_in[4:3], ucode_addr[2:0]};
                            // 【教學】ram_wr_data（共用資料寫入值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= alu_out;
                            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ram_wr_en   <= 1'b1;
                        // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_IND=R0/R1 間接地址。else if 與先前分支互斥，先命中者優先。
                        end else if (ucode_dst_sel == SEL_IND) begin
                            // S_DECODE_IND leaves the resolved address here.
                            // 【教學】ram_wr_data（共用資料寫入值）← alu_out；alu_out=八位運算結果；<= 讀本拍舊值並延後提交。
                            ram_wr_data <= alu_out;
                            // 【教學】ram_wr_en（CPU 發出一次資料寫入請求）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            ram_wr_en   <= 1'b1;
                        // 【教學】條件成立才走後續分支；ucode_dst_sel=解碼後的目的定址方式；SEL_DPTR=十六位 DPTR；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                        end else if (ucode_dst_sel == SEL_DPTR || ucode_addr == 8'hA3) begin
                            // 【教學】core_dptr_we（CPU 寫回 DPTR 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                            core_dptr_we   <= 1'b1;       
                            // 【教學】新 DPTR 取 (ucode_addr == 8'hA3) ? dptr_inc_out : {op1, op2}，用 16 位路徑避免只更新一半資料指標。
                            core_dptr_data <= (ucode_addr == 8'hA3) ? dptr_inc_out : {op1, op2};
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end

                    // 3. PSW 標誌位更新
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                    if (ucode_addr == 8'h72 || ucode_addr == 8'h82 ||
                        // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                        ucode_addr == 8'h84 || ucode_addr == 8'hA0 ||
                        // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                        ucode_addr == 8'hA2 || ucode_addr == 8'hA4 ||
                        // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                        ucode_addr == 8'hB0 || ucode_addr == 8'hB3 ||
                        // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                        ucode_addr == 8'hD4) begin
                        // already handled above
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hD3) begin
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 psw_in | 8'h80 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= psw_in | 8'h80;
                    // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。else if 與先前分支互斥，先命中者優先。
                    end else if (ucode_addr == 8'hC3) begin 
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we   <= 1'b1;
                        // 【教學】將 psw_in & 8'h7F 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                        core_psw_data <= psw_in & 8'h7F;
                    // 【教學】條件成立才走後續分支；cy_we=此指令是否更新 CY。else if 與先前分支互斥，先命中者優先。
                    end else if (cy_we) begin
                        // 【教學】core_psw_we（CPU 寫回 PSW 的單拍允許）設為 1'b1；正常每拍先清使能，再由命中的指令設 1，避免同一寫回連續提交多次。
                        core_psw_we <= 1'b1;

                        // ADD / ADDC / SUBB update CY, AC and OV.
                        // 【教學】條件成立才走後續分支；ucode_addr=本指令 opcode 鎖存值。沒有選此分支時依 else 或保持規則處理。
                        if ((ucode_addr >= 8'h24 && ucode_addr <= 8'h2F) ||
                            // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                            (ucode_addr >= 8'h34 && ucode_addr <= 8'h3F) ||
                            // 【教學】接續前一行 opcode 的判斷／指令集合；ucode_addr=本指令 opcode 鎖存值；|| 表示任一操作碼命中，&& 表示必須同時落在指定範圍。
                            (ucode_addr >= 8'h94 && ucode_addr <= 8'h9F)) begin
                            // 【教學】開始跨行串接新的 PSW：CY、AC、保留的 bank/狀態位、OV、其餘位由高到低排列；<= 在本拍求得完整結果後提交。
                            core_psw_data <= {alu_cy_out, alu_ac_out,
                                              // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；alu_ov_out=ALU 新 OV；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                              psw_in[5:3], alu_ov_out,
                                              // 【教學】接續 PSW 或快速運算的跨行表達式；psw_in=目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；串接需保留原本未更新的旗標，符號比較用來判斷 OV。
                                              psw_in[1:0]};
                        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                        end else begin
                            // Rotate/compare-style users only need CY.
                            // 【教學】將 {alu_cy_out, psw_in[6:0]} 排定為新 PSW；只替換此指令應更新的 CY/AC/OV 等位，其餘位要保留，P 在 SFR bank 由新 ACC 重算。
                            core_psw_data <= {alu_cy_out, psw_in[6:0]};
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end

                    // 【教學】state 排定為 S_FETCH_OP（取 opcode，或在指令邊界接受中斷），下一個時鐘才依新狀態工作。
                    state <= S_FETCH_OP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。state 排定為 S_RESET（建立 reset PC=0000，準備第一次取指），下一個時鐘才依新狀態工作。
                default: state <= S_RESET;
            // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
            endcase
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
