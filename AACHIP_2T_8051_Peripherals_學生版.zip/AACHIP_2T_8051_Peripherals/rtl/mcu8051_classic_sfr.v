// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// 【教學】宣告 mcu8051_classic_sfr 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module mcu8051_classic_sfr (
    // 【教學】輸入由外層驅動。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire        clk,
    // 【教學】輸入由外層驅動。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire        rst_n,

    // ------------------------------------------------------------------------
    // 1. CPU 總線讀寫介面 (指令讀寫 SFR 專用，位址 0x80 ~ 0xFF)
    // ------------------------------------------------------------------------
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。sfr_addr：8-bit SFR 位址，決定讀寫哪個控制暫存器。
    input  wire [7:0]  sfr_addr,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。sfr_wr_data：SFR bank 寫入資料。
    input  wire [7:0]  sfr_wr_data,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。sfr_rd_data：基本控制與架構暫存器讀值。
    output reg  [7:0]  sfr_rd_data,
    // 【教學】輸入由外層驅動。sfr_wr_en：僅 SFR 範圍直接定址寫入才有效。
    input  wire        sfr_wr_en,
    // 【教學】輸入由外層驅動。sfr_rmw：讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
    input  wire        sfr_rmw,

    // ------------------------------------------------------------------------
    // 2. ALU/Core 硬體優先覆寫介面 (如 ALU 計算自動更新 PSW / ACC)
    // ------------------------------------------------------------------------
    // 【教學】輸入由外層驅動。core_psw_we：CPU 寫回 PSW 的單拍允許。
    input  wire        core_psw_we,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。core_psw_data：CPU 寫回 PSW 的新值。
    input  wire [7:0]  core_psw_data,
    // 【教學】輸入由外層驅動。core_acc_we：CPU 寫回 ACC 的單拍允許。
    input  wire        core_acc_we,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。core_acc_data：CPU 寫回 ACC 的新值。
    input  wire [7:0]  core_acc_data,
    // 【教學】輸入由外層驅動。core_b_we：CPU 寫回 B 的單拍允許。
    input  wire        core_b_we,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。core_b_data：CPU 寫回 B 的新值。
    input  wire [7:0]  core_b_data,
    // 【教學】輸入由外層驅動。core_sp_we：CPU 寫回 SP 的單拍允許。
    input  wire        core_sp_we,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。core_sp_data：CPU 寫回 SP 的新值。
    input  wire [7:0]  core_sp_data,
    // 【教學】輸入由外層驅動。core_dptr_we：CPU 寫回 DPTR 的單拍允許。
    input  wire        core_dptr_we,
    // 【教學】輸入由外層驅動；[15:0] 指定位元／陣列範圍。core_dptr_data：CPU 寫回 DPTR 的新值。
    input  wire [15:0]  core_dptr_data,
    // 【教學】輸入由外層驅動。int0_n：低有效 INT0 輸入／合併後訊號。
    input  wire         int0_n,
    // 【教學】輸入由外層驅動。int1_n：低有效 INT1 輸入／合併後訊號。
    input  wire         int1_n,
    // 【教學】輸入由外層驅動。timer0_overflow：Timer0 的溢位事件輸入。
    input  wire         timer0_overflow,
    // 【教學】輸入由外層驅動。timer1_overflow：Timer1 的單拍溢位，作 UART 鮑率來源。
    input  wire         timer1_overflow,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。timer0_tl：Timer0 真實 TL0 讀值。
    input  wire [7:0]   timer0_tl,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。timer0_th：Timer0 真實 TH0 讀值。
    input  wire [7:0]   timer0_th,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。timer1_tl：Timer1 真實 TL1 讀值。
    input  wire [7:0]   timer1_tl,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。timer1_th：Timer1 真實 TH1 讀值。
    input  wire [7:0]   timer1_th,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。serial_sbuf：UART0 接收 byte。
    input  wire [7:0]   serial_sbuf,
    // 【教學】輸入由外層驅動。serial_rb8_write：UART0 要求更新 RB8 的事件。
    input  wire         serial_rb8_write,
    // 【教學】輸入由外層驅動。serial_rb8_data：UART0 RB8 的新值。
    input  wire         serial_rb8_data,
    // 【教學】輸入由外層驅動。serial_rx_irq：UART0 額外／真實接收事件。
    input  wire         serial_rx_irq,
    // 【教學】輸入由外層驅動。serial_tx_irq：UART0 額外／真實傳送事件。
    input  wire         serial_tx_irq,
    // 【教學】輸入由外層驅動。irq_ack：主機已接受中斷的確認脈波。
    input  wire         irq_ack,
    // 【教學】輸入由外層驅動；[3:0] 指定位元／陣列範圍。irq_ack_source：已接受的 0～12 中斷來源編號。
    input  wire [3:0]   irq_ack_source,
    // ------------------------------------------------------------------------
    // 3. 核心暫存器直接輸出 (直接接回 Core / ALU 供組合邏輯運算)
    // ------------------------------------------------------------------------
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。acc：8-bit 累加器影像，供保留的 SFR bank 使用。
    output reg  [7:0]  acc,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。b：乘除法 B 暫存器影像。
    output reg  [7:0]  b,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。psw：程式狀態字，bit0 是 ACC parity。
    output reg  [7:0]  psw,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。sp：8-bit 堆疊指標影像。
    output reg  [7:0]  sp,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。dpl：選定 DPTR 的低八位。
    output wire [7:0]  dpl,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。dph：選定 DPTR 的高八位。
    output wire [7:0]  dph,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ie：基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用。
    output reg  [7:0]  ie,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ip：基本中斷優先權設定。
    output reg  [7:0]  ip,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。tcon：T0/T1 啟動及外部／計時中斷旗標。
    output reg  [7:0]  tcon,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
    output reg  [7:0]  tmod,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。scon：UART 模式、REN、SM2、TB8 和 RI/TI/RB8。
    output reg  [7:0]  scon,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。pcon：電源／控制影像，bit7 是 UART0 SMOD。
    output reg  [7:0]  pcon,
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。dptr：選定的完整 16-bit DPTR。
    output wire [15:0] dptr,

    // ------------------------------------------------------------------------
    // 4. 外設 / GPIO Ports 界面
    // ------------------------------------------------------------------------
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。port_read_data：GPIO 位址解碼後的讀回值。
    input  wire [7:0]  port_read_data
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);

    // SFR 位址映射定義
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_P0  = 8'h80;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_SP  = 8'h81;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_DPL = 8'h82;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_DPH = 8'h83;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_PCON= 8'h87;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_P1  = 8'h90;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TCON= 8'h88;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TMOD= 8'h89;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TL0 = 8'h8A;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TL1 = 8'h8B;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TH0 = 8'h8C;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_TH1 = 8'h8D;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_SCON= 8'h98;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_SBUF= 8'h99;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_IE  = 8'hA8;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_IP  = 8'hB8;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_P2  = 8'hA0;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_P3  = 8'hB0;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_PSW = 8'hD0;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_ACC = 8'hE0;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam ADDR_B   = 8'hF0;

    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[15:0] 指定位元／陣列範圍。dp0：第一組 16-bit 資料指標。
    reg [15:0] dp0;
    // 【教學】dptr（選定的完整 16-bit DPTR）← dp0；= 是本組合求值的立即指派。
    assign dptr=dp0;
    // 【教學】dpl（選定 DPTR 的低八位）← dp0[7:0]；= 是本組合求值的立即指派。
    assign dpl=dp0[7:0];
    // 【教學】dph（選定 DPTR 的高八位）← dp0[15:8]；= 是本組合求值的立即指派。
    assign dph=dp0[15:8];

    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。int0_n_d：INT0 前一拍是否為高，供下降沿偵測；int1_n_d：INT1 前一拍是否為高，供下降沿偵測。
    reg int0_n_d, int1_n_d;
    // 【教學】int0_low（int0_low）← (int0_n === 1'b0)；= 是本組合求值的立即指派。
    wire int0_low = (int0_n === 1'b0);
    // 【教學】int1_low（int1_low）← (int1_n === 1'b0)；= 是本組合求值的立即指派。
    wire int1_low = (int1_n === 1'b0);
    // 【教學】int0_fall（int0_fall）← int0_n_d && int0_low；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire int0_fall = int0_n_d && int0_low;
    // 【教學】int1_fall（int1_fall）← int1_n_d && int1_low；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire int1_fall = int1_n_d && int1_low;
    // 【教學】timer0_event（timer0_event）← (timer0_overflow === 1'b1)；= 是本組合求值的立即指派。
    wire timer0_event = (timer0_overflow === 1'b1);
    // 【教學】timer1_event（timer1_event）← (timer1_overflow === 1'b1)；= 是本組合求值的立即指派。
    wire timer1_event = (timer1_overflow === 1'b1);
    // 【教學】serial_rx_event（serial_rx_event）← (serial_rx_irq === 1'b1)；= 是本組合求值的立即指派。
    wire serial_rx_event = (serial_rx_irq === 1'b1);
    // 【教學】serial_tx_event（serial_tx_event）← (serial_tx_irq === 1'b1)；= 是本組合求值的立即指派。
    wire serial_tx_event = (serial_tx_irq === 1'b1);
    // 【教學】bus_writes_acc（bus_writes_acc）← sfr_wr_en && (sfr_addr == ADDR_ACC) && !core_acc_we；sfr_wr_en=僅 SFR 範圍直接定址寫入才有效；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire bus_writes_acc = sfr_wr_en && (sfr_addr == ADDR_ACC) && !core_acc_we;
    // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
    wire [7:0] effective_acc = core_acc_we ? core_acc_data :
                               // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                               bus_writes_acc ? sfr_wr_data : acc;
    // 【教學】effective_parity（effective_parity）← ^effective_acc；XOR 可用來反相選定位或計算 parity；= 是本組合求值的立即指派。
    wire effective_parity = ^effective_acc;

    // ------------------------------------------------------------------------
    // SFR 時脈同步寫入邏輯 (包含硬體強制寫入優先權處理)
    // ------------------------------------------------------------------------
    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
        if (!rst_n) begin
            // 【教學】sp（8-bit 堆疊指標影像）← 8'h07；<= 讀本拍舊值並延後提交。
            sp     <= 8'h07; // 8051 Reset 預設值
            // 【教學】acc（8-bit 累加器影像，供保留的 SFR bank 使用）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            acc    <= 8'h00;
            // 【教學】b（乘除法 B 暫存器影像）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            b      <= 8'h00;
            // 【教學】psw（程式狀態字，bit0 是 ACC parity）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            psw    <= 8'h00;
            // 【教學】dp0（第一組 16-bit 資料指標）← 0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            dp0<=0;
            // 【教學】ie（基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ie     <= 8'h00;
            // 【教學】ip（基本中斷優先權設定）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            ip     <= 8'h00;
            // 【教學】tcon（T0/T1 啟動及外部／計時中斷旗標）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            tcon   <= 8'h00;
            // 【教學】tmod（計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            tmod   <= 8'h00;
            // 【教學】scon（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            scon   <= 8'h00;
            // 【教學】pcon（電源／控制影像，bit7 是 UART0 SMOD）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
            pcon   <= 8'h00;
            // 【教學】int0_n_d（INT0 前一拍是否為高，供下降沿偵測）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            int0_n_d <= 1'b1;
            // 【教學】int1_n_d（INT1 前一拍是否為高，供下降沿偵測）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            int1_n_d <= 1'b1;
        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
        end else begin
            // 【教學】int0_n_d（INT0 前一拍是否為高，供下降沿偵測）← !int0_low；<= 讀本拍舊值並延後提交。
            int0_n_d <= !int0_low;
            // 【教學】int1_n_d（INT1 前一拍是否為高，供下降沿偵測）← !int1_low；<= 讀本拍舊值並延後提交。
            int1_n_d <= !int1_low;

            // 最高優先權：ALU/Core 直接硬體更新
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。psw（程式狀態字，bit0 是 ACC parity）← {core_psw_data[7:1], effective_parity}；<= 讀本拍舊值並延後提交。
            if (core_psw_we) psw <= {core_psw_data[7:1], effective_parity};
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。acc（8-bit 累加器影像，供保留的 SFR bank 使用）← core_acc_data；<= 讀本拍舊值並延後提交。
            if (core_acc_we) acc <= core_acc_data;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。b（乘除法 B 暫存器影像）← core_b_data；<= 讀本拍舊值並延後提交。
            if (core_b_we)   b  <= core_b_data;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。sp（8-bit 堆疊指標影像）← core_sp_data；<= 讀本拍舊值並延後提交。
            if (core_sp_we)  sp <= core_sp_data;
			// 【教學】基本 8051 只有單一 DPTR，CPU 可一次更新完整十六位；此版本不保留 DPS 或第二組 DPTR。
			if (core_dptr_we) dp0<=core_dptr_data;
            // 次要優先權：指令總線寫入 (如 MOV direct, A)
            // 【教學】條件成立才走後續分支；sfr_wr_en=僅 SFR 範圍直接定址寫入才有效。沒有選此分支時依 else 或保持規則處理。
            if (sfr_wr_en) begin
                // 【教學】依 sfr_addr 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                case (sfr_addr)
                    // 【教學】命中 ADDR_SP 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。sp（8-bit 堆疊指標影像）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_SP:  if (!core_sp_we) sp <= sfr_wr_data;
                    // 【教學】命中 ADDR_DPL 分支才執行，避免其他 opcode／地址誤用這組控制。dp0[7:0]（第一組 16-bit 資料指標）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_DPL: dp0[7:0]<=sfr_wr_data;
                    // 【教學】命中 ADDR_DPH 分支才執行，避免其他 opcode／地址誤用這組控制。dp0[15:8]（第一組 16-bit 資料指標）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_DPH: dp0[15:8]<=sfr_wr_data;
                    // 【教學】命中 ADDR_B 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。b（乘除法 B 暫存器影像）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_B:   if (!core_b_we) b <= sfr_wr_data;
                    // 【教學】命中 ADDR_TCON 分支才執行，避免其他 opcode／地址誤用這組控制。tcon（T0/T1 啟動及外部／計時中斷旗標）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_TCON:tcon   <= sfr_wr_data;
                    // 【教學】命中 ADDR_TMOD 分支才執行，避免其他 opcode／地址誤用這組控制。tmod（計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_TMOD:tmod   <= sfr_wr_data;
                    // 【教學】命中 ADDR_SCON 分支才執行，避免其他 opcode／地址誤用這組控制。scon（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_SCON:scon   <= sfr_wr_data;
                    // 【教學】寫入 PCON 時以 8Fh 遮罩保留 SMOD 和低四位；IDL/PD 僅保存影像，沒有額外的時鐘停止電路。
                    ADDR_PCON:pcon <= sfr_wr_data & 8'h8f;
                    // 【教學】IE 只保留全域 EA 和五個來源允許，以 9Fh 遮罩排除 UART1/Timer2 等擴充位。
                    ADDR_IE:  ie     <= sfr_wr_data & 8'h9f;
                    // 【教學】基本 8051 只有五個優先位，與 1Fh 做 AND 讓保留位讀回 0，不引入擴充中斷。
                    ADDR_IP: ip <= sfr_wr_data & 8'h1f;
                    // 【教學】命中 ADDR_PSW 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。psw（程式狀態字，bit0 是 ACC parity）← {sfr_wr_data[7:1], effective_parity}；<= 讀本拍舊值並延後提交。
                    ADDR_PSW: if (!core_psw_we) psw <= {sfr_wr_data[7:1], effective_parity};
                    // 【教學】命中 ADDR_ACC 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。acc（8-bit 累加器影像，供保留的 SFR bank 使用）← sfr_wr_data；<= 讀本拍舊值並延後提交。
                    ADDR_ACC: if (!core_acc_we) acc <= sfr_wr_data;
                    // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。此分支沒有其他指派，沿用預設控制或保持時序舊值。
                    default: ; // 未定義 SFR 位址寫入忽略
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // Hardware flag changes take priority over a simultaneous software
            // write to TCON/SCON, so an event cannot be lost at an instruction
            // writeback edge.
            // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
            if (irq_ack) begin
                // 【教學】依 irq_ack_source 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                case (irq_ack_source)
                    // 【教學】命中 3'd0 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[1]（T0/T1 啟動及外部／計時中斷旗標）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
                    3'd0: if (tcon[0]) tcon[1] <= 1'b0;
                    // 【教學】命中 3'd1 分支才執行，避免其他 opcode／地址誤用這組控制。tcon[5]（T0/T1 啟動及外部／計時中斷旗標）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
                    3'd1: tcon[5] <= 1'b0;
                    // 【教學】命中 3'd2 分支才執行，避免其他 opcode／地址誤用這組控制。由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[3]（T0/T1 啟動及外部／計時中斷旗標）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
                    3'd2: if (tcon[2]) tcon[3] <= 1'b0;
                    // 【教學】命中 3'd3 分支才執行，避免其他 opcode／地址誤用這組控制。tcon[7]（T0/T1 啟動及外部／計時中斷旗標）← 1'b0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
                    3'd3: tcon[7] <= 1'b0;
                    // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。此分支沒有其他指派，沿用預設控制或保持時序舊值。
                    default: ;
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
            if (tcon[0]) begin
                // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[1]（T0/T1 啟動及外部／計時中斷旗標）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
                if (int0_fall) tcon[1] <= 1'b1;
            // 【教學】tcon[1]（T0/T1 啟動及外部／計時中斷旗標）← int0_low；<= 讀本拍舊值並延後提交。
            end else tcon[1] <= int0_low;
            // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
            if (tcon[2]) begin
                // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[3]（T0/T1 啟動及外部／計時中斷旗標）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
                if (int1_fall) tcon[3] <= 1'b1;
            // 【教學】tcon[3]（T0/T1 啟動及外部／計時中斷旗標）← int1_low；<= 讀本拍舊值並延後提交。
            end else tcon[3] <= int1_low;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[5]（T0/T1 啟動及外部／計時中斷旗標）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            if (timer0_event) tcon[5] <= 1'b1;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。tcon[7]（T0/T1 啟動及外部／計時中斷旗標）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            if (timer1_event) tcon[7] <= 1'b1;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。scon[0]（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            if (serial_rx_event) scon[0] <= 1'b1;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。scon[1]（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）← 1'b1；設為有效狀態，由所在條件決定何時開始／通知；<= 讀本拍舊值並延後提交。
            if (serial_tx_event) scon[1] <= 1'b1;
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。scon[2]（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）← serial_rb8_data；<= 讀本拍舊值並延後提交。
            if (serial_rb8_write) scon[2] <= serial_rb8_data;
            // P is always the odd-parity indication of the effective ACC.
            // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
            if ((core_acc_we || bus_writes_acc) && !core_psw_we &&
                // 【教學】本行是持續接線或跨行表達式的一部分。sfr_wr_en=僅 SFR 範圍直接定址寫入才有效。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                !(sfr_wr_en && sfr_addr == ADDR_PSW))
                // 【教學】psw[0]（程式狀態字，bit0 是 ACC parity）← effective_parity；<= 讀本拍舊值並延後提交。
                psw[0] <= effective_parity;
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end

    // ------------------------------------------------------------------------
    // SFR 組合邏輯讀取多路複用器 (Read MUX)
    // ------------------------------------------------------------------------
    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
    always @(*) begin
        // 【教學】依 sfr_addr 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
        case (sfr_addr)
            // 【教學】命中 ADDR_P0 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← port_read_data；= 是本組合求值的立即指派。
            ADDR_P0:  sfr_rd_data = port_read_data;
            // 【教學】命中 ADDR_P1 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← port_read_data；= 是本組合求值的立即指派。
            ADDR_P1:  sfr_rd_data = port_read_data;
            // 【教學】命中 ADDR_TCON 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← tcon；= 是本組合求值的立即指派。
            ADDR_TCON:sfr_rd_data = tcon;
            // 【教學】命中 ADDR_TMOD 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← tmod；= 是本組合求值的立即指派。
            ADDR_TMOD:sfr_rd_data = tmod;
            // 【教學】命中 ADDR_TL0 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← timer0_tl；= 是本組合求值的立即指派。
            ADDR_TL0: sfr_rd_data = timer0_tl;
            // 【教學】命中 ADDR_TL1 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← timer1_tl；= 是本組合求值的立即指派。
            ADDR_TL1: sfr_rd_data = timer1_tl;
            // 【教學】命中 ADDR_TH0 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← timer0_th；= 是本組合求值的立即指派。
            ADDR_TH0: sfr_rd_data = timer0_th;
            // 【教學】命中 ADDR_TH1 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← timer1_th；= 是本組合求值的立即指派。
            ADDR_TH1: sfr_rd_data = timer1_th;
            // 【教學】命中 ADDR_SCON 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← scon；= 是本組合求值的立即指派。
            ADDR_SCON:sfr_rd_data = scon;
            // 【教學】命中 ADDR_SBUF 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← serial_sbuf；= 是本組合求值的立即指派。
            ADDR_SBUF:sfr_rd_data = serial_sbuf;
            // 【教學】命中 ADDR_PCON 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← pcon；= 是本組合求值的立即指派。
            ADDR_PCON:sfr_rd_data = pcon;
            // 【教學】命中 ADDR_IE 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← ie；= 是本組合求值的立即指派。
            ADDR_IE:  sfr_rd_data = ie;
            // 【教學】命中 ADDR_IP 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← ip；= 是本組合求值的立即指派。
            ADDR_IP:  sfr_rd_data = ip;
            // 【教學】命中 ADDR_P2 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← port_read_data；= 是本組合求值的立即指派。
            ADDR_P2:  sfr_rd_data = port_read_data;
            // 【教學】命中 ADDR_P3 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← port_read_data；= 是本組合求值的立即指派。
            ADDR_P3:  sfr_rd_data = port_read_data;
            // 【教學】命中 ADDR_SP 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← sp；= 是本組合求值的立即指派。
            ADDR_SP:  sfr_rd_data = sp;
            // 【教學】命中 ADDR_DPL 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← dp0[7:0]；= 是本組合求值的立即指派。
            ADDR_DPL: sfr_rd_data = dp0[7:0];
            // 【教學】命中 ADDR_DPH 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← dp0[15:8]；= 是本組合求值的立即指派。
            ADDR_DPH: sfr_rd_data = dp0[15:8];
            // 【教學】命中 ADDR_PSW 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← psw；= 是本組合求值的立即指派。
            ADDR_PSW: sfr_rd_data = psw;
            // 【教學】命中 ADDR_ACC 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← acc；= 是本組合求值的立即指派。
            ADDR_ACC: sfr_rd_data = acc;
            // 【教學】命中 ADDR_B 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← b；= 是本組合求值的立即指派。
            ADDR_B:   sfr_rd_data = b;
            // Match the IDE reset image: unimplemented SFR slots read zero.
            // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。sfr_rd_data（基本控制與架構暫存器讀值）← 8'h00；重置時建立確定初值，正常分支則清除本拍事件／資料；= 是本組合求值的立即指派。
            default:  sfr_rd_data = 8'h00;
        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
        endcase
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end

// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
