// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】宣告可重複使用的硬體模組 mcu8051_sfr_bank，後面列出它對外的腳位。
module mcu8051_sfr_bank (
    // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire        clk,
    // 【教學】input 由外部驅動，模組只讀取。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire        rst_n,

    // ------------------------------------------------------------------------
    // 1. CPU 總線讀寫介面 (指令讀寫 SFR 專用，位址 0x80 ~ 0xFF)
    // ------------------------------------------------------------------------
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_addr：8-bit SFR 位址，決定讀寫哪個控制暫存器。
    input  wire [7:0]  sfr_addr,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_wr_data：SFR bank 寫入資料。
    input  wire [7:0]  sfr_wr_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_rd_data：基本 SFR 的組合讀回資料。
    output reg  [7:0]  sfr_rd_data,
    // 【教學】input 由外部驅動，模組只讀取。sfr_wr_en：SFR bank 寫入允許。
    input  wire        sfr_wr_en,
    // 【教學】input 由外部驅動，模組只讀取。sfr_rmw：讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
    input  wire        sfr_rmw,

    // ------------------------------------------------------------------------
    // 2. ALU/Core 硬體優先覆寫介面 (如 ALU 計算自動更新 PSW / ACC)
    // ------------------------------------------------------------------------
    // 【教學】input 由外部驅動，模組只讀取。core_psw_we：CPU 直接寫回 PSW 的使能；獨立封裝固定為 0。
    input  wire        core_psw_we,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。core_psw_data：CPU 直接寫回 PSW 的新值；只有對應 we=1 才採用。
    input  wire [7:0]  core_psw_data,
    // 【教學】input 由外部驅動，模組只讀取。core_acc_we：CPU 直接寫回 ACC 的使能；獨立封裝固定為 0。
    input  wire        core_acc_we,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。core_acc_data：CPU 直接寫回 ACC 的新值；只有對應 we=1 才採用。
    input  wire [7:0]  core_acc_data,
    // 【教學】input 由外部驅動，模組只讀取。core_b_we：CPU 直接寫回 B 的使能；獨立封裝固定為 0。
    input  wire        core_b_we,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。core_b_data：CPU 直接寫回 B 的新值；只有對應 we=1 才採用。
    input  wire [7:0]  core_b_data,
    // 【教學】input 由外部驅動，模組只讀取。core_sp_we：CPU 直接寫回 SP 的使能；獨立封裝固定為 0。
    input  wire        core_sp_we,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。core_sp_data：CPU 直接寫回 SP 的新值；只有對應 we=1 才採用。
    input  wire [7:0]  core_sp_data,
    // 【教學】input 由外部驅動，模組只讀取。core_dptr_we：CPU 直接寫回 DPTR 的使能；獨立封裝固定為 0。
    input  wire        core_dptr_we,
    // 【教學】input 由外部驅動，模組只讀取；[15:0] 指定向量位元範圍，例如 [7:0] 共 8 位。core_dptr_data：CPU 直接寫回 DPTR 的新值；只有對應 we=1 才採用。
    input  wire [15:0]  core_dptr_data,
    // 【教學】input 由外部驅動，模組只讀取。int0_n：低有效 INT0 輸入／合併後訊號。
    input  wire         int0_n,
    // 【教學】input 由外部驅動，模組只讀取。int1_n：低有效 INT1 輸入／合併後訊號。
    input  wire         int1_n,
    // 【教學】input 由外部驅動，模組只讀取。timer0_overflow：Timer0 的溢位事件輸入。
    input  wire         timer0_overflow,
    // 【教學】input 由外部驅動，模組只讀取。timer1_overflow：Timer1 的單拍溢位，作 UART 鮑率來源。
    input  wire         timer1_overflow,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。timer0_tl：Timer0 真實 TL0 讀值。
    input  wire [7:0]   timer0_tl,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。timer0_th：Timer0 真實 TH0 讀值。
    input  wire [7:0]   timer0_th,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。timer1_tl：Timer1 真實 TL1 讀值。
    input  wire [7:0]   timer1_tl,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。timer1_th：Timer1 真實 TH1 讀值。
    input  wire [7:0]   timer1_th,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。serial_sbuf：UART0 接收 byte。
    input  wire [7:0]   serial_sbuf,
    // 【教學】input 由外部驅動，模組只讀取。serial_rb8_write：UART0 要求更新 RB8 的事件。
    input  wire         serial_rb8_write,
    // 【教學】input 由外部驅動，模組只讀取。serial_rb8_data：UART0 RB8 的新值。
    input  wire         serial_rb8_data,
    // 【教學】input 由外部驅動，模組只讀取。serial_rx_irq：UART0 額外／真實接收事件。
    input  wire         serial_rx_irq,
    // 【教學】input 由外部驅動，模組只讀取。serial_tx_irq：UART0 額外／真實傳送事件。
    input  wire         serial_tx_irq,
    // 【教學】input 由外部驅動，模組只讀取。irq_ack：主機已接受中斷的確認脈波。
    input  wire         irq_ack,
    // 【教學】input 由外部驅動，模組只讀取；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。irq_ack_source：已接受的 0～12 中斷來源編號。
    input  wire [3:0]   irq_ack_source,
    // ------------------------------------------------------------------------
    // 3. 核心暫存器直接輸出 (直接接回 Core / ALU 供組合邏輯運算)
    // ------------------------------------------------------------------------
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。acc：8-bit 累加器影像，供保留的 SFR bank 使用。
    output reg  [7:0]  acc,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。b：乘除法 B 暫存器影像。
    output reg  [7:0]  b,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。psw：程式狀態字，bit0 是 ACC parity。
    output reg  [7:0]  psw,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sp：8-bit 堆疊指標影像。
    output reg  [7:0]  sp,
    // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。dpl：選定 DPTR 的低八位。
    output wire [7:0]  dpl,
    // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。dph：選定 DPTR 的高八位。
    output wire [7:0]  dph,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ie：基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用。
    output reg  [7:0]  ie,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ip：基本中斷優先權設定。
    output reg  [7:0]  ip,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tcon：T0/T1 啟動及外部／計時中斷旗標。
    output reg  [7:0]  tcon,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
    output reg  [7:0]  tmod,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。scon：UART 模式、REN、SM2、TB8 和 RI/TI/RB8。
    output reg  [7:0]  scon,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。pcon：電源／控制影像，bit7 是 UART0 SMOD。
    output reg  [7:0]  pcon,
    // 【教學】output 將內部結果接給外層。dps_out：選定資料指標的 DPS 值。
    output wire dps_out,
    // 【教學】output 將內部結果接給外層；[15:0] 指定向量位元範圍，例如 [7:0] 共 8 位。dp0_value：DP0 的完整值；dp1_value：DP1 的完整值。
    output wire [15:0] dp0_value,dp1_value,
    // 【教學】output 將內部結果接給外層；[15:0] 指定向量位元範圍，例如 [7:0] 共 8 位。dptr：選定的完整 16-bit DPTR。
    output wire [15:0] dptr,

    // ------------------------------------------------------------------------
    // 4. 外設 / GPIO Ports 界面
    // ------------------------------------------------------------------------
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。port_read_data：GPIO 位址解碼後的讀回值。
    input  wire [7:0]  port_read_data
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);

    // SFR 位址映射定義
    // 【教學】把 SFR 位址 8'h80 命名為 ADDR_P0；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_P0  = 8'h80;
    // 【教學】把 SFR 位址 8'h81 命名為 ADDR_SP；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_SP  = 8'h81;
    // 【教學】把 SFR 位址 8'h82 命名為 ADDR_DPL；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_DPL = 8'h82;
    // 【教學】把 SFR 位址 8'h83 命名為 ADDR_DPH；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_DPH = 8'h83;
    // 【教學】把 SFR 位址 8'h87 命名為 ADDR_PCON；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_PCON= 8'h87;
    // 【教學】把 SFR 位址 8'h90 命名為 ADDR_P1；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_P1  = 8'h90;
    // 【教學】把 SFR 位址 8'h88 命名為 ADDR_TCON；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TCON= 8'h88;
    // 【教學】把 SFR 位址 8'h89 命名為 ADDR_TMOD；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TMOD= 8'h89;
    // 【教學】把 SFR 位址 8'h8A 命名為 ADDR_TL0；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TL0 = 8'h8A;
    // 【教學】把 SFR 位址 8'h8B 命名為 ADDR_TL1；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TL1 = 8'h8B;
    // 【教學】把 SFR 位址 8'h8C 命名為 ADDR_TH0；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TH0 = 8'h8C;
    // 【教學】把 SFR 位址 8'h8D 命名為 ADDR_TH1；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_TH1 = 8'h8D;
    // 【教學】把 SFR 位址 8'h98 命名為 ADDR_SCON；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_SCON= 8'h98;
    // 【教學】把 SFR 位址 8'h99 命名為 ADDR_SBUF；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_SBUF= 8'h99;
    // 【教學】把 SFR 位址 8'hA8 命名為 ADDR_IE；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_IE  = 8'hA8;
    // 【教學】把 SFR 位址 8'hB8 命名為 ADDR_IP；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_IP  = 8'hB8;
    // 【教學】把 SFR 位址 8'hA0 命名為 ADDR_P2；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_P2  = 8'hA0;
    // 【教學】把 SFR 位址 8'hB0 命名為 ADDR_P3；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_P3  = 8'hB0;
    // 【教學】把 SFR 位址 8'hD0 命名為 ADDR_PSW；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_PSW = 8'hD0;
    // 【教學】把 SFR 位址 8'hE0 命名為 ADDR_ACC；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_ACC = 8'hE0;
    // 【教學】把 SFR 位址 8'hF0 命名為 ADDR_B；localparam 是模組內常數，解碼時用名稱可降低寫錯十六進位地址的機率。
    localparam ADDR_B   = 8'hF0;

    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[15:0] 指定向量位元範圍，例如 [7:0] 共 8 位。dp0：第一組 16-bit 資料指標；dp1：第二組 16-bit 資料指標。
    reg [15:0] dp0,dp1;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。dps：目前選擇 DP0/DP1 的單 bit。
    reg dps;
    // 【教學】將兩組 DPTR 的儲存值各別接出，讓外部可同時觀察，不受 DPS 選擇影響。
    assign dp0_value=dp0;assign dp1_value=dp1;
    // 【教學】把目前 DPTR 選擇位接出，供 CPU 配合使用選定的資料指標。
    assign dps_out=dps;
    // 【教學】DPS=1 選 DP1，0 選 DP0；硬體是一個 16-bit 二選一多工器。
    assign dptr = dps?dp1:dp0;
    // 【教學】將選定 DPTR 拆成低／高 byte 輸出，與固定地址 DP0/DP1 的讀回有所不同。
    assign dpl=dptr[7:0];assign dph=dptr[15:8];

    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。int0_n_d：INT0 前一拍是否為高，供下降沿偵測；int1_n_d：INT1 前一拍是否為高，供下降沿偵測。
    reg int0_n_d, int1_n_d;
    // 【教學】只有 INT0 明確為 0 才視為低有效；=== 能在模擬中給 X/Z 確定的判斷結果，但不能取代實體同步。
    wire int0_low = (int0_n === 1'b0);
    // 【教學】只有 INT1 明確為 0 才視為低有效；=== 能在模擬中給 X/Z 確定的判斷結果，但不能取代實體同步。
    wire int1_low = (int1_n === 1'b0);
    // 【教學】INT0 前拍高而本拍低才視為下降沿，讓短事件可變成鎖存旗標。
    wire int0_fall = int0_n_d && int0_low;
    // 【教學】INT1 前拍高而本拍低才視為下降沿，讓短事件可變成鎖存旗標。
    wire int1_fall = int1_n_d && int1_low;
    // 【教學】將外部事件只有明確為 1 時才認定有效，避免模擬中未連接的 X/Z 直接觸發中斷旗標；真正硬體輸入仍需固定或正確連接。
    wire timer0_event = (timer0_overflow === 1'b1);
    // 【教學】將外部事件只有明確為 1 時才認定有效，避免模擬中未連接的 X/Z 直接觸發中斷旗標；真正硬體輸入仍需固定或正確連接。
    wire timer1_event = (timer1_overflow === 1'b1);
    // 【教學】將外部事件只有明確為 1 時才認定有效，避免模擬中未連接的 X/Z 直接觸發中斷旗標；真正硬體輸入仍需固定或正確連接。
    wire serial_rx_event = (serial_rx_irq === 1'b1);
    // 【教學】將外部事件只有明確為 1 時才認定有效，避免模擬中未連接的 X/Z 直接觸發中斷旗標；真正硬體輸入仍需固定或正確連接。
    wire serial_tx_event = (serial_tx_irq === 1'b1);
    // 【教學】只有 SFR 寫 ACC 且 CPU 沒有直接寫回時，匯流排值才真正成為新 ACC；與後面 parity 的資料選擇保持一致。
    wire bus_writes_acc = sfr_wr_en && (sfr_addr == ADDR_ACC) && !core_acc_we;
    // 【教學】計算本拍應生效的 ACC，先選優先權較高的 CPU 寫回，讓 parity 跟著新 ACC 而非晚一拍。
    wire [7:0] effective_acc = core_acc_we ? core_acc_data :
                               // 【教學】CPU 未寫回時，匯流排有寫 ACC 就選新資料，否則取舊 ACC；結束三層來源多工器。
                               bus_writes_acc ? sfr_wr_data : acc;
    // 【教學】前置 ^ 是 reduction XOR，把八位縮成一位；1 的個數為奇數時輸出 1，對應 PSW.P。
    wire effective_parity = ^effective_acc;

    // ------------------------------------------------------------------------
    // SFR 時脈同步寫入邏輯 (包含硬體強制寫入優先權處理)
    // ------------------------------------------------------------------------
    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
        if (!rst_n) begin
            // 【教學】sp（8-bit 堆疊指標影像）寫入 8'h07，使用 <= 讓更新在時序事件結束提交。重置 07h，符合 8051 初始堆疊指標影像。
            sp     <= 8'h07; // 8051 Reset 預設值
            // 【教學】acc（8-bit 累加器影像，供保留的 SFR bank 使用）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            acc    <= 8'h00;
            // 【教學】b（乘除法 B 暫存器影像）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            b      <= 8'h00;
            // 【教學】psw（程式狀態字，bit0 是 ACC parity）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            psw    <= 8'h00;
            // 【教學】兩個資料指標都清 0，並預設選 DP0，使重置後的間接資料位置確定。
            dp0<=0;dp1<=0;dps<=0;
            // 【教學】ie（基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            ie     <= 8'h00;
            // 【教學】ip（基本中斷優先權設定）寫入 8'h80，使用 <= 讓更新在時序事件結束提交。重置為 80h，保留最高固定 1 位，其他優先位清零。
            ip     <= 8'h80;
            // 【教學】tcon（T0/T1 啟動及外部／計時中斷旗標）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tcon   <= 8'h00;
            // 【教學】tmod（計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tmod   <= 8'h00;
            // 【教學】scon（UART 模式、REN、SM2、TB8 和 RI/TI/RB8）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            scon   <= 8'h00;
            // 【教學】pcon（電源／控制影像，bit7 是 UART0 SMOD）寫入 8'h30，使用 <= 讓更新在時序事件結束提交。重置 30h 對應固定 bit5:4=11，其餘控制位清零。
            pcon   <= 8'h30;
            // 【教學】int0_n_d（INT0 前一拍是否為高，供下降沿偵測）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            int0_n_d <= 1'b1;
            // 【教學】int1_n_d（INT1 前一拍是否為高，供下降沿偵測）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            int1_n_d <= 1'b1;
        // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
        end else begin
            // 【教學】記錄 INT0 本拍是否為高，下一拍拿這個舊值偵測下降沿；! 為邏輯反相。
            int0_n_d <= !int0_low;
            // 【教學】記錄 INT1 本拍是否為高，下一拍拿這個舊值偵測下降沿；! 為邏輯反相。
            int1_n_d <= !int1_low;

            // 最高優先權：ALU/Core 直接硬體更新
            // 【教學】CPU 可更新 PSW 高七位，但最低 parity 必須用有效 ACC 重算，不能任由傳入 bit0 破壞一致性。
            if (core_psw_we) psw <= {core_psw_data[7:1], effective_parity};
            // 【教學】CPU 直接寫 ACC；下方匯流排寫入會檢查 !core_acc_we，明確保證此來源優先。
            if (core_acc_we) acc <= core_acc_data;
            // 【教學】CPU 直接寫 B，例如乘除法結果；一般軟體寫入須讓位給此寫回。
            if (core_b_we)   b  <= core_b_data;
            // 【教學】CPU 的堆疊操作可直接更新 SP，避免同拍一般寫入覆蓋 PUSH/POP 等結果。
            if (core_sp_we)  sp <= core_sp_data;
			// 【教學】CPU 寫回選定的 16-bit DPTR；注意下方 DP0/DP1 的 byte 寫入沒有全部加互斥保護，同拍衝突仍可能被後面的 byte 指派覆蓋。
			if (core_dptr_we) begin if(dps)dp1<=core_dptr_data;else dp0<=core_dptr_data;end
            // 次要優先權：指令總線寫入 (如 MOV direct, A)
            // 【教學】SFR 寫入使能為 1 才解碼地址；使能為 0 時保留暫存器值，其他硬體事件仍可更新旗標。
            if (sfr_wr_en) begin
                // 【教學】以 sfr_addr 選擇對應分支；解碼硬體同時監看選擇訊號，case 本身不是循序跑一遍所有選項。
                case (sfr_addr)
                    // 【教學】ADDR_SP 寫入 sp（8-bit 堆疊指標影像）；if (!core_sp_we) 避開 CPU 同拍寫回衝突，資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_SP:  if (!core_sp_we) sp <= sfr_wr_data;
                    // 【教學】ADDR_DPL 寫入 dp0[7:0]（第一組 16-bit 資料指標），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_DPL: dp0[7:0]<=sfr_wr_data;
                    // 【教學】8'h84 寫入 dp1[7:0]（第二組 16-bit 資料指標），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    8'h84: dp1[7:0]<=sfr_wr_data;
                    // 【教學】8'h85 寫入 dp1[15:8]（第二組 16-bit 資料指標），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    8'h85: dp1[15:8]<=sfr_wr_data;
                    // 【教學】86h 只保存寫入資料 bit0 作 DPS，忽略其餘位，因為兩個 DPTR 只需一位選擇。
                    8'h86: dps<=sfr_wr_data[0];
                    // 【教學】ADDR_DPH 寫入 dp0[15:8]（第一組 16-bit 資料指標），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_DPH: dp0[15:8]<=sfr_wr_data;
                    // 【教學】ADDR_B 寫入 b（乘除法 B 暫存器影像）；if (!core_b_we) 避開 CPU 同拍寫回衝突，資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_B:   if (!core_b_we) b <= sfr_wr_data;
                    // 【教學】ADDR_TCON 寫入 tcon（T0/T1 啟動及外部／計時中斷旗標），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_TCON:tcon   <= sfr_wr_data;
                    // 【教學】ADDR_TMOD 寫入 tmod（計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_TMOD:tmod   <= sfr_wr_data;
                    // 【教學】ADDR_SCON 寫入 scon（UART 模式、REN、SM2、TB8 和 RI/TI/RB8），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_SCON:scon   <= sfr_wr_data;
                    // 【教學】寫 PCON 時只採軟體可寫位，將 bit5:4 固定拼為 11；{} 串接各段必須合計八位，維持原 SFR 影像。
                    ADDR_PCON:pcon <= {sfr_wr_data[7:6],2'b11,sfr_wr_data[3:0]};
                    // 【教學】ADDR_IE 寫入 ie（基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用），資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_IE:  ie     <= sfr_wr_data;
                    // 【教學】寫 IP 時 bit7 固定為 1，低七位由軟體指定；這保留原系統的固定讀回位，不是額外的中斷 enable。
                    ADDR_IP: ip <= {1'b1,sfr_wr_data[6:0]};
                    // 【教學】CPU 未直接更新 PSW 時才接受軟體寫高七位，bit0 一律由有效 ACC 的 parity 重算。
                    ADDR_PSW: if (!core_psw_we) psw <= {sfr_wr_data[7:1], effective_parity};
                    // 【教學】ADDR_ACC 寫入 acc（8-bit 累加器影像，供保留的 SFR bank 使用）；if (!core_acc_we) 避開 CPU 同拍寫回衝突，資料取 sfr_wr_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
                    ADDR_ACC: if (!core_acc_we) acc <= sfr_wr_data;
                    // 【教學】未列出的寫入位址／中斷來源不改任何暫存器；空敘述表示保持既有值，不是要把所有 SFR 清零。
                    default: ; // 未定義 SFR 位址寫入忽略
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】硬體旗標更新排在軟體寫入之後，同拍衝突時硬體事件優先。
            // Hardware flag changes take priority over a simultaneous software
            // 【教學】即使軟體同拍寫 TCON/SCON，也保留新來的中斷事件。
            // write to TCON/SCON, so an event cannot be lost at an instruction
            // 【教學】這是同一時序區塊中非阻塞指派先後順序的用途。
            // writeback edge.
            // 【教學】主機已接受中斷才按來源清除支援自動清除的旗標；不是看到 irq_pending 就自行清除。
            if (irq_ack) begin
                // 【教學】以中斷來源編號選擇旗標；輸入雖為 4-bit，下列 3-bit 常數會擴展比較，因此來源 8 以上不會誤當 0。
                case (irq_ack_source)
                    // 【教學】來源 0=INT0；只在 IT0=1 的邊沿模式清 IE0，低電位模式應由腳位電位決定。
                    3'd0: if (tcon[0]) tcon[1] <= 1'b0;
                    // 【教學】來源 1=Timer0，接受中斷後清 TF0；若同拍又有溢位，後面事件設定會再把它設 1。
                    3'd1: tcon[5] <= 1'b0;
                    // 【教學】來源 2=INT1；僅邊沿模式自動清 IE1，低電位中斷由輸入決定。
                    3'd2: if (tcon[2]) tcon[3] <= 1'b0;
                    // 【教學】來源 3=Timer1 或 split TH0，清 TF1；Timer1 的鮑率溢位與 TF1 請求來源在外層已區別。
                    3'd3: tcon[7] <= 1'b0;
                    // 【教學】未列出的寫入位址／中斷來源不改任何暫存器；空敘述表示保持既有值，不是要把所有 SFR 清零。
                    default: ;
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】IT0=1 走邊沿觸發，IE0 需鎖存到軟體／中斷接受清除，不能每拍直接跟隨輸入。
            if (tcon[0]) begin
                // 【教學】偵測到 INT0 下降沿就保存 IE0；這行位於清旗標後，同拍新事件不會被 ack 吃掉。
                if (int0_fall) tcon[1] <= 1'b1;
            // 【教學】IT0=0 為低電位模式，IE0 每拍直接反映 INT0 是否為低，不保留已解除的電位請求。
            end else tcon[1] <= int0_low;
            // 【教學】IT1=1 選 INT1 邊沿模式，旗標由下降沿事件設定。
            if (tcon[2]) begin
                // 【教學】INT1 下降沿鎖存 IE1，CPU 稍後讀取也不會漏掉短事件。
                if (int1_fall) tcon[3] <= 1'b1;
            // 【教學】INT1 低電位模式每拍以實際電位更新 IE1；外部解除低電位後旗標才解除。
            end else tcon[3] <= int1_low;
            // 【教學】Timer0 溢位事件變成持續的 TF0；安排在軟體寫入與 ack 清除之後，使同拍新溢位優先。
            if (timer0_event) tcon[5] <= 1'b1;
            // 【教學】將 Timer1／split TH0 事件鎖存 TF1，不要求主機在單一 overflow 脈波內立即響應。
            if (timer1_event) tcon[7] <= 1'b1;
            // 【教學】UART 接收事件設定 RI；軟體可透過 SCON 檢查並清除。
            if (serial_rx_event) scon[0] <= 1'b1;
            // 【教學】UART 傳送事件設定 TI；與 RI 共用序列中斷線，服務程式需分別檢查。
            if (serial_tx_event) scon[1] <= 1'b1;
            // 【教學】只在 UART 說 RB8 有新值時更新，保留其他 SCON 控制位。
            if (serial_rb8_write) scon[2] <= serial_rb8_data;
            // 【教學】PSW.P 要反映實際生效 ACC 中 1 的個數是否為奇數。
            // P is always the odd-parity indication of the effective ACC.
            // 【教學】ACC 有變化且 CPU 沒有整體寫 PSW 才另外更新 parity；避免多個更新路徑互相覆蓋。
            if ((core_acc_we || bus_writes_acc) && !core_psw_we &&
                // 【教學】接續條件：也要排除軟體正寫 PSW，因該分支已把 parity 正確拼入整個 PSW。
                !(sfr_wr_en && sfr_addr == ADDR_PSW))
                // 【教學】僅改 PSW 最低位 P，其餘 CY、AC、RS 等旗標保持；新 P 與同拍生效 ACC 一致。
                psw[0] <= effective_parity;
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end

    // ------------------------------------------------------------------------
    // SFR 組合邏輯讀取多路複用器 (Read MUX)
    // ------------------------------------------------------------------------
    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
    always @(*) begin
        // 【教學】以 sfr_addr 選擇對應分支；解碼硬體同時監看選擇訊號，case 本身不是循序跑一遍所有選項。
        case (sfr_addr)
            // 【教學】8'he1,8'he2,8'he3,8'he4,8'he5,8'he6,8'hf1,8'hf2 → port_read_data：把 GPIO 已完成一般讀／RMW 選擇的值接回主機。此處 = 是組合阻塞指派。
            8'he1,8'he2,8'he3,8'he4,8'he5,8'he6,8'hf1,8'hf2: sfr_rd_data = port_read_data;
            // 【教學】ADDR_P0 → port_read_data：把 GPIO 已完成一般讀／RMW 選擇的值接回主機。此處 = 是組合阻塞指派。
            ADDR_P0:  sfr_rd_data = port_read_data;
            // 【教學】ADDR_P1 → port_read_data：把 GPIO 已完成一般讀／RMW 選擇的值接回主機。此處 = 是組合阻塞指派。
            ADDR_P1:  sfr_rd_data = port_read_data;
            // 【教學】ADDR_TCON → tcon：讀回 T0/T1 啟動及外部／計時中斷旗標；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TCON:sfr_rd_data = tcon;
            // 【教學】ADDR_TMOD → tmod：讀回 計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TMOD:sfr_rd_data = tmod;
            // 【教學】ADDR_TL0 → timer0_tl：讀回 Timer0 真實 TL0 讀值；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TL0: sfr_rd_data = timer0_tl;
            // 【教學】ADDR_TL1 → timer1_tl：讀回 Timer1 真實 TL1 讀值；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TL1: sfr_rd_data = timer1_tl;
            // 【教學】ADDR_TH0 → timer0_th：讀回 Timer0 真實 TH0 讀值；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TH0: sfr_rd_data = timer0_th;
            // 【教學】ADDR_TH1 → timer1_th：讀回 Timer1 真實 TH1 讀值；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_TH1: sfr_rd_data = timer1_th;
            // 【教學】ADDR_SCON → scon：讀回 UART 模式、REN、SM2、TB8 和 RI/TI/RB8；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_SCON:sfr_rd_data = scon;
            // 【教學】ADDR_SBUF → serial_sbuf：讀回 UART0 接收 byte；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_SBUF:sfr_rd_data = serial_sbuf;
            // 【教學】ADDR_PCON → pcon：讀回 電源／控制影像，bit7 是 UART0 SMOD；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_PCON:sfr_rd_data = pcon;
            // 【教學】ADDR_IE → ie：讀回 基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_IE:  sfr_rd_data = ie;
            // 【教學】ADDR_IP → ip：讀回 基本中斷優先權設定；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_IP:  sfr_rd_data = ip;
            // 【教學】ADDR_P2 → port_read_data：把 GPIO 已完成一般讀／RMW 選擇的值接回主機。此處 = 是組合阻塞指派。
            ADDR_P2:  sfr_rd_data = port_read_data;
            // 【教學】ADDR_P3 → port_read_data：把 GPIO 已完成一般讀／RMW 選擇的值接回主機。此處 = 是組合阻塞指派。
            ADDR_P3:  sfr_rd_data = port_read_data;
            // 【教學】ADDR_SP → sp：讀回 8-bit 堆疊指標影像；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_SP:  sfr_rd_data = sp;
            // 【教學】ADDR_DPL → dp0[7:0]：讀回 第一組 16-bit 資料指標的 bit7～bit0 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_DPL: sfr_rd_data = dp0[7:0];
            // 【教學】8'h84 → dp1[7:0]：讀回 第二組 16-bit 資料指標的 bit7～bit0 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            8'h84:sfr_rd_data=dp1[7:0];
            // 【教學】8'h85 → dp1[15:8]：讀回 第二組 16-bit 資料指標的 bit15～bit8 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            8'h85:sfr_rd_data=dp1[15:8];
            // 【教學】8'h86 → {7'b0,dps}：DPS 只有一位，高七位補 0 形成 8-bit SFR 讀值。此處 = 是組合阻塞指派。
            8'h86:sfr_rd_data={7'b0,dps};
            // 【教學】ADDR_DPH → dp0[15:8]：讀回 第一組 16-bit 資料指標的 bit15～bit8 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_DPH: sfr_rd_data = dp0[15:8];
            // 【教學】ADDR_PSW → psw：讀回 程式狀態字，bit0 是 ACC parity；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_PSW: sfr_rd_data = psw;
            // 【教學】ADDR_ACC → acc：讀回 8-bit 累加器影像，供保留的 SFR bank 使用；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_ACC: sfr_rd_data = acc;
            // 【教學】ADDR_B → b：讀回 乘除法 B 暫存器影像；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
            ADDR_B:   sfr_rd_data = b;
            // 【教學】未實作的基本 SFR 讀 0，讓組合讀回在每個位址都有確定值。
            // Match the IDE reset image: unimplemented SFR slots read zero.
            // 【教學】default → 8'h00：未實作位址回傳固定值，確保組合邏輯每條路都有結果，避免 latch。此處 = 是組合阻塞指派。
            default:  sfr_rd_data = 8'h00;
        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
        endcase
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end

// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
