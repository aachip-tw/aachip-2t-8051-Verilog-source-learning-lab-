// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns/1ps
// 【教學】宣告 aachip_8051_top 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module aachip_8051_top #(
    // 【教學】建構電路時設定的參數 TIMER_CLK_DIV：基本頂層預設 12；只控制 timer，不代表所有 CPU 指令變成 12T。
    parameter integer TIMER_CLK_DIV=12,
    // 【教學】建構電路時設定的參數 RAM_PIPELINED：0 用下降沿讀值，1 多一個上升沿資料暫存，CPU 需加等待狀態。
    parameter integer RAM_PIPELINED=0
// 【教學】結束參數清單並開始對外埠清單；參數決定配置，埠是運作時的訊號。
)(
    // 【教學】輸入由外層驅動。clk：共同時鐘，上升沿更新時序邏輯；rst_n：低有效非同步重置，_n 表示 0 有效。
    input wire clk,rst_n,
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。rom_addr：程式記憶體地址，與 MOVX 資料空間分開。
    output wire [15:0] rom_addr,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。rom_data：程式記憶體讀出的 byte。
    input wire [7:0] rom_data,
    // 【教學】輸出供外層連接；[15:0] 指定位元／陣列範圍。ext_ram_addr：MOVX 的十六位邏輯資料地址。
    output wire [15:0] ext_ram_addr,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。ext_ram_wr_data：MOVX 寫出的 byte。
    output wire [7:0] ext_ram_wr_data,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。ext_ram_rd_data：外部 XRAM 回傳的 byte。
    input wire [7:0] ext_ram_rd_data,
    // 【教學】輸出供外層連接。ext_ram_wr_en：一次 MOVX 寫使能；ext_ram_rd_en：MOVX 讀取使能，讀資料需在 capture 前穩定。
    output wire ext_ram_wr_en,ext_ram_rd_en,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。p0_in：P0 實際腳位輸入，與 latch 不同；p1_in：P1 實際腳位輸入，與 latch 不同；p2_in：P2 實際腳位輸入，與 latch 不同；p3_in：P3 實際腳位輸入，與 latch 不同。
    input wire [7:0] p0_in,p1_in,p2_in,p3_in,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。p0_out：P0 送到腳位緩衝的輸出資料；p1_out：P1 送到腳位緩衝的輸出資料；p2_out：P2 送到腳位緩衝的輸出資料；p3_out：P3 送到腳位緩衝的輸出資料。
    output wire [7:0] p0_out,p1_out,p2_out,p3_out,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。p0_oe：P0 每位輸出使能，1 驅動、0 釋放；p1_oe：P1 每位輸出使能，1 驅動、0 釋放；p2_oe：P2 每位輸出使能，1 驅動、0 釋放；p3_oe：P3 每位輸出使能，1 驅動、0 釋放。
    output wire [7:0] p0_oe,p1_oe,p2_oe,p3_oe
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】wire 由接線／組合表達式驅動；[7:0] 指定位元／陣列範圍。mem_addr：核心資料地址；mem_wr_data：核心資料寫值；mem_rd_data：IRAM/SFR 多工後回給核心的資料；iram_rd_data：內部 RAM 回傳值；sfr_rd_data：基本控制與架構暫存器讀值。
    wire [7:0] mem_addr,mem_wr_data,mem_rd_data,iram_rd_data,sfr_rd_data;
    // 【教學】wire 由接線／組合表達式驅動。mem_wr_en：核心資料寫入請求；mem_rd_en：核心資料讀取請求；mem_rmw：核心讀改寫標記；mem_indirect：核心間接／堆疊標記。
    wire mem_wr_en,mem_rd_en,mem_rmw,mem_indirect;
    // 【教學】地址低於 80h 選 IRAM；間接／堆疊即使 bit7=1 也不能選 SFR。本基本頂層實體 RAM 只有 128 bytes，越界由 RAM 擋下。
    wire sel_iram=!mem_addr[7] || mem_indirect;
    // 【教學】sfr_wr_en（僅 SFR 範圍直接定址寫入才有效）← mem_wr_en && !sel_iram；mem_wr_en=核心資料寫入請求；sel_iram=本次存取選 IRAM 而非 SFR；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire sfr_wr_en=mem_wr_en && !sel_iram;
    // 【教學】mem_rd_data（IRAM/SFR 多工後回給核心的資料）← sel_iram?iram_rd_data:sfr_rd_data；sel_iram=本次存取選 IRAM 而非 SFR；iram_rd_data=內部 RAM 回傳值；sfr_rd_data=基本控制與架構暫存器讀值；= 是本組合求值的立即指派。
    assign mem_rd_data=sel_iram?iram_rd_data:sfr_rd_data;
    // 【教學】wire 由接線／組合表達式驅動。core_acc_we：CPU 寫回 ACC 的單拍允許；core_b_we：CPU 寫回 B 的單拍允許；core_sp_we：CPU 寫回 SP 的單拍允許；core_psw_we：CPU 寫回 PSW 的單拍允許；core_dptr_we：CPU 寫回 DPTR 的單拍允許。
    wire core_acc_we,core_b_we,core_sp_we,core_psw_we,core_dptr_we;
    // 【教學】wire 由接線／組合表達式驅動；[7:0] 指定位元／陣列範圍。core_acc_data：CPU 寫回 ACC 的新值；core_b_data：CPU 寫回 B 的新值；core_sp_data：CPU 寫回 SP 的新值；core_psw_data：CPU 寫回 PSW 的新值。
    wire [7:0] core_acc_data,core_b_data,core_sp_data,core_psw_data;
    // 【教學】wire 由接線／組合表達式驅動；[15:0] 指定位元／陣列範圍。core_dptr_data：CPU 寫回 DPTR 的新值。
    wire [15:0] core_dptr_data;
    // 【教學】wire 由接線／組合表達式驅動；[7:0] 指定位元／陣列範圍。acc：8-bit 累加器影像，供保留的 SFR bank 使用；b：乘除法 B 暫存器影像；sp：8-bit 堆疊指標影像；psw：程式狀態字，bit0 是 ACC parity；ie：基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用；ip：基本中斷優先權設定；tcon：T0/T1 啟動及外部／計時中斷旗標；tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；scon：UART 模式、REN、SM2、TB8 和 RI/TI/RB8；pcon：電源／控制影像，bit7 是 UART0 SMOD。
    wire [7:0] acc,b,sp,psw,ie,ip,tcon,tmod,scon,pcon;
    // 【教學】wire 由接線／組合表達式驅動；[15:0] 指定位元／陣列範圍。dptr：選定的完整 16-bit DPTR；pc：下一次／目前指令的十六位程式計數。
    wire [15:0] dptr,pc;
    // 【教學】wire 由接線／組合表達式驅動。irq_ack：主機已接受中斷的確認脈波；irq_ack_priority：CPU 回報已接受的中斷等級；reti_complete：RETI 完成的單拍通知；RET 不產生它。
    wire irq_ack,irq_ack_priority,reti_complete;
    // 【教學】wire 由接線／組合表達式驅動；[3:0] 指定位元／陣列範圍。irq_ack_source：已接受的 0～12 中斷來源編號。
    wire [3:0] irq_ack_source;
    // 【教學】wire 由接線／組合表達式驅動；[7:0] 指定位元／陣列範圍。gpio_read_data：GPIO 已完成 RMW/pin 選擇的讀值；tl0：Timer0 低 byte 的儲存值；th0：Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer；tl1：Timer1 低 byte 的儲存值；th1：Timer1 高 byte／Mode2 重載值；serial_sbuf：UART0 接收 byte。
    wire [7:0] gpio_read_data,tl0,th0,tl1,th1,serial_sbuf;
    // 【教學】wire 由接線／組合表達式驅動。int0_n：低有效 INT0 輸入／合併後訊號；int1_n：低有效 INT1 輸入／合併後訊號；t0_pin：Counter0 外部下降沿輸入；t1_pin：Counter1 外部下降沿輸入；serial_rxd：由 P3.0 取得的 UART0 接收資料；serial_txd：UART0 傳送資料供 P3.1 複用。
    wire int0_n,int1_n,t0_pin,t1_pin,serial_rxd,serial_txd;
    // 【教學】wire 由接線／組合表達式驅動。serial_rxd_out：UART0 Mode0 資料供 P3.0 複用；serial_rxd_oe：UART0 Mode0 資料輸出允許；ri_set：要求外部 SCON 設 RI 的事件；ti_set：要求外部 SCON 設 TI 的事件；rb8_write：RB8 資料有效更新事件；rb8_data：接收第九位或 Mode1 的停止位。
    wire serial_rxd_out,serial_rxd_oe,ri_set,ti_set,rb8_write,rb8_data;
    // 【教學】wire 由接線／組合表達式驅動。overflow0：Timer0 單拍溢位事件；overflow1：Timer1 單拍溢位事件，也供 UART 鮑率使用；overflow1_split：Timer0 split 的 TH0 溢位，用於 TF1。
    wire overflow0,overflow1,overflow1_split;
    // 【教學】tf1_event（依 T0 Mode3 選 TH0 或 T1 的 TF1 事件）← (tmod[1:0]==2'b11)?overflow1_split:overflow1；= 是本組合求值的立即指派。
    wire tf1_event=(tmod[1:0]==2'b11)?overflow1_split:overflow1;
    // 【教學】定義模組內固定編碼，不是執行期暫存器。位址／位寬常數供解碼及計數器使用，$clog2 算足以表示計數範圍的位數。
    localparam integer DIV_W=(TIMER_CLK_DIV<=1)?1:$clog2(TIMER_CLK_DIV);
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[DIV_W-1:0] 指定位元／陣列範圍。timer_div_count：系統 timer_tick 的分頻相位計數。
    reg [DIV_W-1:0] timer_div_count;
    // 【教學】timer_tick（計時器的一次計數使能，不是另一個 clock）← (TIMER_CLK_DIV<=1)||(timer_div_count==TIMER_CLK_DIV-1)；減法依目前位寬截斷，旗標需另外計算；= 是本組合求值的立即指派。
    wire timer_tick=(TIMER_CLK_DIV<=1)||(timer_div_count==TIMER_CLK_DIV-1);
    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。timer_div_count（系統 timer_tick 的分頻相位計數）← 0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
        if(!rst_n) timer_div_count<=0;
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。timer_div_count（系統 timer_tick 的分頻相位計數）← 0；重置時建立確定初值，正常分支則清除本拍事件／資料；<= 讀本拍舊值並延後提交。
        else if(timer_tick) timer_div_count<=0;
        // 【教學】timer_div_count（系統 timer_tick 的分頻相位計數）← timer_div_count+1'b1；增加固定寬度的計數／資料，超出位寬的進位須另行保存；<= 讀本拍舊值並延後提交。
        else timer_div_count<=timer_div_count+1'b1;
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】本行是持續接線或跨行表達式的一部分。requests=五個中斷個別經 IE 允許的請求。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
    wire [4:0] requests={((scon[0]|scon[1])&ie[4]),tcon[7]&ie[3],
                        // 【教學】本行是持續接線或跨行表達式的一部分。?: 選資料來源，{} 串接位元，&/| 遮罩各位；要連同上一行的左側及下一行結尾閱讀，並非獨立執行步驟。
                        tcon[3]&ie[2],tcon[5]&ie[1],tcon[1]&ie[0]};
    // 【教學】high_requests（套 IP 後的高優先請求）← requests & ip[4:0]；requests=五個中斷個別經 IE 允許的請求；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire [4:0] high_requests=requests & ip[4:0];
    // 【教學】low_requests（套 IP 後的低優先請求）← requests & ~ip[4:0]；requests=五個中斷個別經 IE 允許的請求；逐位遮罩保留不應改變的位元；= 是本組合求值的立即指派。
    wire [4:0] low_requests=requests & ~ip[4:0];
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。active_low：目前正在低優先中斷服務；active_high：目前正在高優先中斷服務。
    reg active_low,active_high;
    // 【教學】本拍 RETI 已完成時先視為高優先服務解除，讓下一個指令邊界可立刻重新仲裁。
    wire effective_high=active_high && !reti_complete;
    // 【教學】低優先只在沒有高優先巢狀服務的 RETI 才解除；高優先返回時，原低優先 ISR 仍在執行。
    wire effective_low=active_low && !(reti_complete && !active_high);
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。irq_valid：有可接受且已仲裁的中斷；irq_priority：已選中斷的高／低等級。
    reg irq_valid,irq_priority;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[3:0] 指定位元／陣列範圍。irq_source：已選中斷來源編號。
    reg [3:0] irq_source;
    // 【教學】把 source 左移三位再加 3，依序得到 INT0=0003、T0=000B、INT1=0013、T1=001B、UART=0023。
    wire [15:0] irq_vector={9'b0,irq_source,3'b011};
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[4:0] 指定位元／陣列範圍。candidates：本拍可接受的那一個優先群組，之後按固定順序選來源。
    reg [4:0] candidates;
    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
    always @(*) begin
        // 【教學】irq_valid 取 0，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；irq_priority 取 0，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；irq_source 取 0，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；candidates 取 0，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        irq_valid=0;irq_priority=0;irq_source=0;candidates=0;
        // 【教學】條件成立才走後續分支；effective_high=扣除本拍 RETI 效果後的高優先服務狀態。沒有選此分支時依 else 或保持規則處理。
        if(!irq_ack && ie[7] && !effective_high) begin
            // 【教學】條件成立才走後續分支；high_requests=套 IP 後的高優先請求。沒有選此分支時依 else 或保持規則處理。
            if(|high_requests) begin
                // 【教學】candidates 取 high_requests，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；irq_valid 取 1，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；irq_priority 取 1，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
                candidates=high_requests;irq_valid=1;irq_priority=1;
            // 【教學】條件成立才走後續分支；effective_low=扣除本拍 RETI 效果後的低優先服務狀態；low_requests=套 IP 後的低優先請求。else if 與先前分支互斥，先命中者優先。
            end else if(!effective_low && |low_requests) begin
                // 【教學】candidates 取 low_requests，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch；irq_valid 取 1，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
                candidates=low_requests;irq_valid=1;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。irq_source 取 0，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        if(candidates[0]) irq_source=0;
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。irq_source 取 1，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        else if(candidates[1]) irq_source=1;
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。irq_source 取 2，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        else if(candidates[2]) irq_source=2;
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。irq_source 取 3，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        else if(candidates[3]) irq_source=3;
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。irq_source 取 4，形成五來源兩等級中斷仲裁；完整預設值可避免組合 latch。
        else if(candidates[4]) irq_source=4;
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。active_low 設 0，保存中斷服務等級；RETI 解除一層，普通 RET 不解除；active_high 設 0，保存中斷服務等級；RETI 解除一層，普通 RET 不解除。
        if(!rst_n) begin active_low<=0;active_high<=0;end
        // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
        else begin
            // 【教學】條件成立才走後續分支；reti_complete=RETI 完成的單拍通知；RET 不產生它。沒有選此分支時依 else 或保持規則處理。
            if(reti_complete) begin
                // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。active_high 設 0，保存中斷服務等級；RETI 解除一層，普通 RET 不解除。
                if(active_high) active_high<=0;
                // 【教學】active_low 設 0，保存中斷服務等級；RETI 解除一層，普通 RET 不解除。
                else active_low<=0;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】條件成立才走後續分支；用程式列出的常數、旗標或地址決定是否執行。沒有選此分支時依 else 或保持規則處理。
            if(irq_ack) begin
                // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。active_high 設 1，保存中斷服務等級；RETI 解除一層，普通 RET 不解除。
                if(irq_ack_priority) active_high<=1;
                // 【教學】active_low 設 1，保存中斷服務等級；RETI 解除一層，普通 RET 不解除。
                else active_low<=1;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】建立 mcu8051_memory 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_memory #(.DEPTH(128),.PIPELINED_READ(RAM_PIPELINED)) u_iram (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rd_addr(mem_addr)，RAM 讀地址；rd_data(iram_rd_data)，RAM 回傳資料。
        .clk(clk),.rd_addr(mem_addr),.rd_data(iram_rd_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：wr_en(rst_n && mem_wr_en && sel_iram)，RAM 上升沿寫入使能；wr_addr(mem_addr)，RAM 寫地址；wr_data(mem_wr_data)，RAM 寫資料。
        .wr_en(rst_n && mem_wr_en && sel_iram),.wr_addr(mem_addr),.wr_data(mem_wr_data)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_classic_sfr 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_classic_sfr u_sfr (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；sfr_addr(mem_addr)，8-bit SFR 位址，決定讀寫哪個控制暫存器；sfr_wr_data(mem_wr_data)，SFR bank 寫入資料。
        .clk(clk),.rst_n(rst_n),.sfr_addr(mem_addr),.sfr_wr_data(mem_wr_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：sfr_rd_data(sfr_rd_data)，基本控制與架構暫存器讀值；sfr_wr_en(sfr_wr_en)，僅 SFR 範圍直接定址寫入才有效；sfr_rmw(mem_rmw)，讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
        .sfr_rd_data(sfr_rd_data),.sfr_wr_en(sfr_wr_en),.sfr_rmw(mem_rmw),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_acc_we(core_acc_we)，CPU 寫回 ACC 的單拍允許；core_acc_data(core_acc_data)，CPU 寫回 ACC 的新值。
        .core_acc_we(core_acc_we),.core_acc_data(core_acc_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_b_we(core_b_we)，CPU 寫回 B 的單拍允許；core_b_data(core_b_data)，CPU 寫回 B 的新值。
        .core_b_we(core_b_we),.core_b_data(core_b_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_sp_we(core_sp_we)，CPU 寫回 SP 的單拍允許；core_sp_data(core_sp_data)，CPU 寫回 SP 的新值。
        .core_sp_we(core_sp_we),.core_sp_data(core_sp_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_psw_we(core_psw_we)，CPU 寫回 PSW 的單拍允許；core_psw_data(core_psw_data)，CPU 寫回 PSW 的新值。
        .core_psw_we(core_psw_we),.core_psw_data(core_psw_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_dptr_we(core_dptr_we)，CPU 寫回 DPTR 的單拍允許；core_dptr_data(core_dptr_data)，CPU 寫回 DPTR 的新值。
        .core_dptr_we(core_dptr_we),.core_dptr_data(core_dptr_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：int0_n(int0_n)，低有效 INT0 輸入／合併後訊號；int1_n(int1_n)，低有效 INT1 輸入／合併後訊號；timer0_overflow(overflow0)，Timer0 的溢位事件輸入；timer1_overflow(tf1_event)，Timer1 的單拍溢位，作 UART 鮑率來源。
        .int0_n(int0_n),.int1_n(int1_n),.timer0_overflow(overflow0),.timer1_overflow(tf1_event),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：timer0_tl(tl0)，Timer0 真實 TL0 讀值；timer0_th(th0)，Timer0 真實 TH0 讀值；timer1_tl(tl1)，Timer1 真實 TL1 讀值；timer1_th(th1)，Timer1 真實 TH1 讀值。
        .timer0_tl(tl0),.timer0_th(th0),.timer1_tl(tl1),.timer1_th(th1),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：serial_sbuf(serial_sbuf)，UART0 接收 byte；serial_rb8_write(rb8_write)，UART0 要求更新 RB8 的事件；serial_rb8_data(rb8_data)，UART0 RB8 的新值。
        .serial_sbuf(serial_sbuf),.serial_rb8_write(rb8_write),.serial_rb8_data(rb8_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：serial_rx_irq(ri_set)，UART0 額外／真實接收事件；serial_tx_irq(ti_set)，UART0 額外／真實傳送事件；irq_ack(irq_ack)，主機已接受中斷的確認脈波；irq_ack_source(irq_ack_source)，已接受的 0～12 中斷來源編號。
        .serial_rx_irq(ri_set),.serial_tx_irq(ti_set),.irq_ack(irq_ack),.irq_ack_source(irq_ack_source),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：acc(acc)，8-bit 累加器影像，供保留的 SFR bank 使用；b(b)，乘除法 B 暫存器影像；psw(psw)，程式狀態字，bit0 是 ACC parity；sp(sp)，8-bit 堆疊指標影像；dpl()，此輸出不需外接，刻意留空；dph()，此輸出不需外接，刻意留空；dptr(dptr)，選定的完整 16-bit DPTR。
        .acc(acc),.b(b),.psw(psw),.sp(sp),.dpl(),.dph(),.dptr(dptr),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ie(ie)，基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用；ip(ip)，基本中斷優先權設定；tcon(tcon)，T0/T1 啟動及外部／計時中斷旗標；tmod(tmod)，計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；scon(scon)，UART 模式、REN、SM2、TB8 和 RI/TI/RB8；pcon(pcon)，電源／控制影像，bit7 是 UART0 SMOD。
        .ie(ie),.ip(ip),.tcon(tcon),.tmod(tmod),.scon(scon),.pcon(pcon),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：port_read_data(gpio_read_data)，GPIO 位址解碼後的讀回值。
        .port_read_data(gpio_read_data)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_gpio 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_gpio #(.EXTENDED(0)) u_gpio (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；sfr_addr(mem_addr)，8-bit SFR 位址，決定讀寫哪個控制暫存器；sfr_write_data(mem_wr_data)，GPIO 寫入資料。
        .clk(clk),.rst_n(rst_n),.sfr_addr(mem_addr),.sfr_write_data(mem_wr_data),
        // 【教學】GPIO 只有直接寫 80/90/A0/B0 四個 port 地址才可更新；擋住擴充 M1/M0 寫入，保持基本 8051 的預設 IO 模式。
        .sfr_write_enable(sfr_wr_en && (mem_addr==8'h80 || mem_addr==8'h90 || mem_addr==8'ha0 || mem_addr==8'hb0)),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：sfr_rmw(mem_rmw)，讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料；p0_oe(p0_oe)，P0 每位輸出使能，1 驅動、0 釋放；p1_oe(p1_oe)，P1 每位輸出使能，1 驅動、0 釋放；p2_oe(p2_oe)，P2 每位輸出使能，1 驅動、0 釋放；p3_oe(p3_oe)，P3 每位輸出使能，1 驅動、0 釋放。
        .sfr_rmw(mem_rmw),.p0_oe(p0_oe),.p1_oe(p1_oe),.p2_oe(p2_oe),.p3_oe(p3_oe),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：p0_in(p0_in)，P0 實際腳位輸入，與 latch 不同；p1_in(p1_in)，P1 實際腳位輸入，與 latch 不同；p2_in(p2_in)，P2 實際腳位輸入，與 latch 不同；p3_in(p3_in)，P3 實際腳位輸入，與 latch 不同。
        .p0_in(p0_in),.p1_in(p1_in),.p2_in(p2_in),.p3_in(p3_in),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：p0_out(p0_out)，P0 送到腳位緩衝的輸出資料；p1_out(p1_out)，P1 送到腳位緩衝的輸出資料；p2_out(p2_out)，P2 送到腳位緩衝的輸出資料；p3_out(p3_out)，P3 送到腳位緩衝的輸出資料。
        .p0_out(p0_out),.p1_out(p1_out),.p2_out(p2_out),.p3_out(p3_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ext_int0_n(1'b1)，獨立 INT0 輸入，未用接 1；ext_int1_n(1'b1)，獨立 INT1 輸入，未用接 1；ext_t0(1'b1)，獨立 Counter0 輸入，未用接 1；ext_t1(1'b1)，獨立 Counter1 輸入，未用接 1。
        .ext_int0_n(1'b1),.ext_int1_n(1'b1),.ext_t0(1'b1),.ext_t1(1'b1),
        // 【教學】此基本頂層沒有 UART1，將 GPIO 的擴充 UART 輸入接閒置值，並把其輸出使能固定 0，避免懸空或額外功能。
        .uart1_txd(1'b1),.uart1_rxd_out(1'b1),.uart1_rxd_oe(1'b0),
        // 【教學】基本頂層沒有 Timer2，將 clock-out 複用允許固定 0，P1.0 保持 GPIO。
        .t2_output_enable(1'b0),.t2_out(1'b1),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：serial_txd(serial_txd)，UART0 傳送資料供 P3.1 複用；serial_rxd_out(serial_rxd_out)，UART0 Mode0 資料供 P3.0 複用；serial_rxd_oe(serial_rxd_oe)，UART0 Mode0 資料輸出允許。
        .serial_txd(serial_txd),.serial_rxd_out(serial_rxd_out),.serial_rxd_oe(serial_rxd_oe),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：port_read_data(gpio_read_data)，GPIO 位址解碼後的讀回值；int0_n(int0_n)，低有效 INT0 輸入／合併後訊號；int1_n(int1_n)，低有效 INT1 輸入／合併後訊號。
        .port_read_data(gpio_read_data),.int0_n(int0_n),.int1_n(int1_n),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：t0_pin(t0_pin)，Counter0 外部下降沿輸入；t1_pin(t1_pin)，Counter1 外部下降沿輸入；serial_rxd(serial_rxd)，由 P3.0 取得的 UART0 接收資料。
        .t0_pin(t0_pin),.t1_pin(t1_pin),.serial_rxd(serial_rxd)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_timer0 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_timer0 u_timer0 (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；timer_tick(timer_tick)，計時器的一次計數使能，不是另一個 clock；t0_pin(t0_pin)，Counter0 外部下降沿輸入；int0_n(int0_n)，低有效 INT0 輸入／合併後訊號。
        .clk(clk),.rst_n(rst_n),.timer_tick(timer_tick),.t0_pin(t0_pin),.int0_n(int0_n),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：tmod(tmod[3:0])，計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；tr0(tcon[4])，Timer0 啟動允許；tr1(tcon[6])，Timer1 啟動；T0 Mode3 也用來控制 TH0。
        .tmod(tmod[3:0]),.tr0(tcon[4]),.tr1(tcon[6]),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：write_tl(sfr_wr_en && mem_addr==8'h8a)，寫入計數器低 byte 的單拍使能；write_th(sfr_wr_en && mem_addr==8'h8c)，寫入計數器高 byte 的單拍使能。
        .write_tl(sfr_wr_en && mem_addr==8'h8a),.write_th(sfr_wr_en && mem_addr==8'h8c),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：write_data(mem_wr_data)，計數器寫入 byte；tl0(tl0)，Timer0 低 byte 的儲存值；th0(th0)，Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer；overflow0(overflow0)，Timer0 單拍溢位事件；overflow1_split(overflow1_split)，Timer0 split 的 TH0 溢位，用於 TF1。
        .write_data(mem_wr_data),.tl0(tl0),.th0(th0),.overflow0(overflow0),.overflow1_split(overflow1_split)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_timer1 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_timer1 u_timer1 (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；timer_tick(timer_tick)，計時器的一次計數使能，不是另一個 clock；t1_pin(t1_pin)，Counter1 外部下降沿輸入；int1_n(int1_n)，低有效 INT1 輸入／合併後訊號。
        .clk(clk),.rst_n(rst_n),.timer_tick(timer_tick),.t1_pin(t1_pin),.int1_n(int1_n),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：tmod(tmod[7:4])，計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位；tr1(tcon[6])，Timer1 啟動；T0 Mode3 也用來控制 TH0；timer0_split_mode(tmod[1:0]==2'b11)，保留的 split 指示輸入；此 Timer1 原碼沒有使用它。
        .tmod(tmod[7:4]),.tr1(tcon[6]),.timer0_split_mode(tmod[1:0]==2'b11),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：write_tl(sfr_wr_en && mem_addr==8'h8b)，寫入計數器低 byte 的單拍使能；write_th(sfr_wr_en && mem_addr==8'h8d)，寫入計數器高 byte 的單拍使能。
        .write_tl(sfr_wr_en && mem_addr==8'h8b),.write_th(sfr_wr_en && mem_addr==8'h8d),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：write_data(mem_wr_data)，計數器寫入 byte；tl1(tl1)，Timer1 低 byte 的儲存值；th1(th1)，Timer1 高 byte／Mode2 重載值；overflow1(overflow1)，Timer1 單拍溢位事件，也供 UART 鮑率使用。
        .write_data(mem_wr_data),.tl1(tl1),.th1(th1),.overflow1(overflow1)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_serial 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_serial u_uart0 (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；clock_enable(1'b1)，核心正常運作使能；基本頂層固定為 1，不提供外部暫停控制；scon(scon)，UART 模式、REN、SM2、TB8 和 RI/TI/RB8；smod(pcon[7])，鮑率倍增選擇，藉分頻減半達成。
        .clk(clk),.rst_n(rst_n),.clock_enable(1'b1),.scon(scon),.smod(pcon[7]),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：timer1_overflow(overflow1)，Timer1 的單拍溢位，作 UART 鮑率來源；rx_baud_overflow(1'b0)，RX 可獨立選擇的鮑率來源脈波；tx_baud_overflow(1'b0)，TX 可獨立選擇的鮑率來源脈波。
        .timer1_overflow(overflow1),.rx_baud_overflow(1'b0),.tx_baud_overflow(1'b0),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：rx_use_timer2(1'b0)，RX 選 Timer2 時改用固定除 16；tx_use_timer2(1'b0)，TX 選 Timer2 時改用固定除 16；rxd(serial_rxd)，串列接收輸入；Mode0 也是同步取樣資料。
        .rx_use_timer2(1'b0),.tx_use_timer2(1'b0),.rxd(serial_rxd),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：sbuf_write(sfr_wr_en && mem_addr==8'h99)，送出一筆 byte 的請求，busy 時會忽略；sbuf_write_data(mem_wr_data)，要送出的 byte。
        .sbuf_write(sfr_wr_en && mem_addr==8'h99),.sbuf_write_data(mem_wr_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：sbuf_read_data(serial_sbuf)，最近收到的 byte，無 FIFO；txd(serial_txd)，串列 TX 輸出，Mode0 改作同步移位時鐘；rxd_out(serial_rxd_out)，Mode0 從 RXD 腳送出的資料。
        .sbuf_read_data(serial_sbuf),.txd(serial_txd),.rxd_out(serial_rxd_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：rxd_output_enable(serial_rxd_oe)，Mode0 允許 RXD 腳輸出資料；ri_set(ri_set)，要求外部 SCON 設 RI 的事件；ti_set(ti_set)，要求外部 SCON 設 TI 的事件。
        .rxd_output_enable(serial_rxd_oe),.ri_set(ri_set),.ti_set(ti_set),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：rb8_write(rb8_write)，RB8 資料有效更新事件；rb8_data(rb8_data)，接收第九位或 Mode1 的停止位；tx_busy()，此輸出不需外接，刻意留空；rx_busy()，此輸出不需外接，刻意留空。
        .rb8_write(rb8_write),.rb8_data(rb8_data),.tx_busy(),.rx_busy()
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
    // 【教學】建立 mcu8051_core 子模組實例；#(...) 覆寫建構參數，後續具名埠把核心、儲存與周邊接成同時工作的電路。
    mcu8051_core #(.RAM_PIPELINED(RAM_PIPELINED),.MOVX_RI_PAGED(1)) u_core (
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：clk(clk)，共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)，低有效非同步重置，_n 表示 0 有效；clock_enable(1'b1)，核心正常運作使能；基本頂層固定為 1，不提供外部暫停控制；movx_page(p2_out)，MOVX @Ri 的高地址 byte；基本整合接 P2 latch。
        .clk(clk),.rst_n(rst_n),.clock_enable(1'b1),.movx_page(p2_out),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：rom_addr(rom_addr)，程式記憶體地址，與 MOVX 資料空間分開；rom_data(rom_data)，程式記憶體讀出的 byte；pc(pc)，下一次／目前指令的十六位程式計數。
        .rom_addr(rom_addr),.rom_data(rom_data),.pc(pc),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ram_addr(mem_addr)，共用資料地址，需由頂層區分 IRAM 與 SFR；ram_wr_data(mem_wr_data)，共用資料寫入值；ram_rd_data(mem_rd_data)，頂層選回的 IRAM 或 SFR 資料。
        .ram_addr(mem_addr),.ram_wr_data(mem_wr_data),.ram_rd_data(mem_rd_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ram_wr_en(mem_wr_en)，CPU 發出一次資料寫入請求；ram_rd_en(mem_rd_en)，CPU 發出資料讀請求；ram_rmw(mem_rmw)，讀改寫指令要求 GPIO 回讀 latch；ram_indirect(mem_indirect)，間接／堆疊存取標記；高地址不應誤寫 SFR；ram_cs()，此輸出不需外接，刻意留空。
        .ram_wr_en(mem_wr_en),.ram_rd_en(mem_rd_en),.ram_rmw(mem_rmw),.ram_indirect(mem_indirect),.ram_cs(),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ext_ram_addr(ext_ram_addr)，MOVX 的十六位邏輯資料地址；ext_ram_wr_data(ext_ram_wr_data)，MOVX 寫出的 byte；ext_ram_rd_data(ext_ram_rd_data)，外部 XRAM 回傳的 byte。
        .ext_ram_addr(ext_ram_addr),.ext_ram_wr_data(ext_ram_wr_data),.ext_ram_rd_data(ext_ram_rd_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：ext_ram_wr_en(ext_ram_wr_en)，一次 MOVX 寫使能；ext_ram_rd_en(ext_ram_rd_en)，MOVX 讀取使能，讀資料需在 capture 前穩定。
        .ext_ram_wr_en(ext_ram_wr_en),.ext_ram_rd_en(ext_ram_rd_en),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_acc_we(core_acc_we)，CPU 寫回 ACC 的單拍允許；core_acc_data(core_acc_data)，CPU 寫回 ACC 的新值。
        .core_acc_we(core_acc_we),.core_acc_data(core_acc_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_b_we(core_b_we)，CPU 寫回 B 的單拍允許；core_b_data(core_b_data)，CPU 寫回 B 的新值。
        .core_b_we(core_b_we),.core_b_data(core_b_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_sp_we(core_sp_we)，CPU 寫回 SP 的單拍允許；core_sp_data(core_sp_data)，CPU 寫回 SP 的新值。
        .core_sp_we(core_sp_we),.core_sp_data(core_sp_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_psw_we(core_psw_we)，CPU 寫回 PSW 的單拍允許；core_psw_data(core_psw_data)，CPU 寫回 PSW 的新值。
        .core_psw_we(core_psw_we),.core_psw_data(core_psw_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：core_dptr_we(core_dptr_we)，CPU 寫回 DPTR 的單拍允許；core_dptr_data(core_dptr_data)，CPU 寫回 DPTR 的新值。
        .core_dptr_we(core_dptr_we),.core_dptr_data(core_dptr_data),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：acc_in(acc)，目前 ACC 儲存值；b_in(b)，目前 B 儲存值；psw_in(psw)，目前 PSW，CY=bit7、AC=bit6、RS=bit4:3、OV=bit2；sp_in(sp)，目前堆疊指標；dptr_in(dptr)，目前資料指標。
        .acc_in(acc),.b_in(b),.psw_in(psw),.sp_in(sp),.dptr_in(dptr),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：irq_valid(irq_valid)，有可接受且已仲裁的中斷；irq_vector(irq_vector)，中斷入口地址；irq_priority(irq_priority)，已選中斷的高／低等級；irq_source(irq_source)，已選中斷來源編號。
        .irq_valid(irq_valid),.irq_vector(irq_vector),.irq_priority(irq_priority),.irq_source(irq_source),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：irq_ack(irq_ack)，主機已接受中斷的確認脈波；irq_ack_priority(irq_ack_priority)，CPU 回報已接受的中斷等級；irq_ack_source(irq_ack_source)，已接受的 0～12 中斷來源編號。
        .irq_ack(irq_ack),.irq_ack_priority(irq_ack_priority),.irq_ack_source(irq_ack_source),
        // 【教學】具名接線（左側子模組埠、括號內外層訊號）：reti_complete(reti_complete)，RETI 完成的單拍通知；RET 不產生它。
        .reti_complete(reti_complete)
    // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
    );
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
