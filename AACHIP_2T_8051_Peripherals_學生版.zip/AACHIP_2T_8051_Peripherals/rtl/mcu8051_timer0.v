// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns / 1ps

// 【教學】Timer0 支援模式 0/1/2，模式 3 將 TL0 與 TH0 拆成兩個 8-bit。
// 8051 Timer 0.  Supports modes 0, 1, 2 and the Timer-0 mode-3 split.
// 【教學】宣告可重複使用的硬體模組 mcu8051_timer0，後面列出它對外的腳位。
module mcu8051_timer0 (
    // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire       clk,
    // 【教學】input 由外部驅動，模組只讀取。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire       rst_n,
    // 【教學】input 由外部驅動，模組只讀取。timer_tick：計時器的一次計數使能，不是另一個 clock。
    input  wire       timer_tick,
    // 【教學】input 由外部驅動，模組只讀取。t0_pin：Counter0 外部下降沿輸入。
    input  wire       t0_pin,
    // 【教學】input 由外部驅動，模組只讀取。int0_n：低有效 INT0 輸入／合併後訊號。
    input  wire       int0_n,
    // 【教學】input 由外部驅動，模組只讀取；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
    input  wire [3:0] tmod,
    // 【教學】input 由外部驅動，模組只讀取。tr0：Timer0 啟動允許。
    input  wire       tr0,
    // 【教學】input 由外部驅動，模組只讀取。tr1：Timer1 啟動；T0 Mode3 也用來控制 TH0。
    input  wire       tr1,
    // 【教學】input 由外部驅動，模組只讀取。write_tl：寫入計數器低 byte 的單拍使能。
    input  wire       write_tl,
    // 【教學】input 由外部驅動，模組只讀取。write_th：寫入計數器高 byte 的單拍使能。
    input  wire       write_th,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。write_data：計數器寫入 byte。
    input  wire [7:0] write_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tl0：Timer0 低 byte 的儲存值。
    output reg  [7:0] tl0,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。th0：Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer。
    output reg  [7:0] th0,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。overflow0：Timer0 單拍溢位事件。
    output reg        overflow0,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。overflow1_split：Timer0 split 的 TH0 溢位，用於 TF1。
    output reg        overflow1_split
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。t0_d：T0 前一拍電位，和本拍比較可偵測下降沿。
    reg t0_d;
    // 【教學】把 T0 明確為 0 的情況判為低，其餘判為高；=== 是四態完全相等，能處理模擬中的 X/Z。這是原碼的模擬預設，不是實體上拉或同步器。
    wire t0_level = (t0_pin === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】前一拍 T0 為高、本拍為低才產生下降沿事件；用一拍記憶把外部電位轉成一次計數，並非兩級 CDC 同步。
    wire t0_fall = t0_d && !t0_level;
    // 【教學】TMOD[3]=GATE；未開 GATE 就放行，開啟後要求 INT0 不是明確低。|| 為邏輯或；!== 在模擬中也比較 X/Z。
    wire gate_open = !tmod[3] || (int0_n !== 1'b0);
    // 【教學】TMOD[2]=C/T，1 選 T0 下降沿當外部計數器，0 選 timer_tick 當計時器；?: 對應二選一多工器。
    wire count_event = tmod[2] ? t0_fall : timer_tick;
    // 【教學】必須 TR0 啟動、GATE 放行、而且本拍真的有計數事件，三者同時成立才加一；&& 是邏輯且。
    wire enabled = tr0 && gate_open && count_event;
    // 【教學】TMOD 的低兩位等於 11 就是 Timer0 Mode3；先命名 split_mode，讓後面能清楚區別兩個 8-bit 計數器與一般模式。
    wire split_mode = (tmod[1:0] == 2'b11);

    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
        if (!rst_n) begin
            // 【教學】tl0（Timer0 低 byte 的儲存值）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tl0 <= 8'h00;
            // 【教學】th0（Timer0 高 byte／Mode2 重載值／Mode3 獨立 timer）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            th0 <= 8'h00;
            // 【教學】把 T0 的前一拍電位設為高，提供確定的下降沿判斷初值；重置後若輸入本來就低，可能被視為第一個下降沿。
            t0_d <= 1'b1;
            // 【教學】將 overflow0 清零：重置時建立初值；正常運轉時每拍先清零，再由下方終值條件設 1，因而形成單拍事件而非永久旗標。
            overflow0 <= 1'b0;
            // 【教學】重置或每拍預設把 split 溢位清掉，確保只有 TH0 回捲那拍才發出事件。
            overflow1_split <= 1'b0;
        // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
        end else begin
            // 【教學】每個 clk 保存本拍 T0 電位；非阻塞 <= 讓本拍邊沿判斷仍能使用更新前的 t0_d。
            t0_d <= t0_level;
            // 【教學】將 overflow0 清零：重置時建立初值；正常運轉時每拍先清零，再由下方終值條件設 1，因而形成單拍事件而非永久旗標。
            overflow0 <= 1'b0;
            // 【教學】重置或每拍預設把 split 溢位清掉，確保只有 TH0 回捲那拍才發出事件。
            overflow1_split <= 1'b0;

            // 【教學】只有低位元組寫入脈波有效才改 TL0；沒寫入時由後面的計數邏輯決定新值。
            if (write_tl) tl0 <= write_data;
            // 【教學】只有高位元組寫入脈波有效才改 TH0；後面計數條件會排除寫入，避免同拍自動計數蓋掉軟體設定。
            if (write_th) th0 <= write_data;

            // 【教學】Timer0 Mode3 把 TL0 與 TH0 拆成獨立 8-bit；必須先分流，才不會誤套用 13/16-bit 合併計數。
            if (split_mode) begin
                // 【教學】TL0 只有計數事件有效且本拍沒有軟體寫 TL0 才遞增；這個條件明確讓軟體寫入優先。
                if (enabled && !write_tl) begin
                    // 【教學】Mode3 的低半部只做 8 位加一；超出 FF 的進位被截掉，溢位另以旗標輸出。
                    tl0 <= tl0 + 8'd1;
                    // 【教學】用加一之前的 TL0=FF 判斷回捲，產生 T0 溢位；不是拿已更新的 TL0 來比。
                    if (tl0 == 8'hff) overflow0 <= 1'b1;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
                // 【教學】split 模式的 TH0 為 TR1 控制的獨立 8-bit timer。
                // In split mode TH0 is an 8-bit timer driven by TR1.  It is
                // 【教學】TH0 不使用外部 counter，也不採用 Timer0 GATE。
                // never an external counter and does not use Timer-0 GATE.
                // 【教學】Mode3 的 TH0 借用 TR1 啟動控制，只吃 timer_tick，不使用 T0 的外部計數或 GATE；寫 TH0 當拍不計數。
                if (tr1 && timer_tick && !write_th) begin
                    // 【教學】Mode3 把 TH0 當獨立 8-bit timer，每個有效 tick 加一，與 TL0 分開運作。
                    th0 <= th0 + 8'd1;
                    // 【教學】TH0 回捲的事件要接到 TF1，因此另設 overflow1_split，避免與真正 Timer1 的 UART 鮑率溢位混淆。
                    if (th0 == 8'hff) overflow1_split <= 1'b1;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】非 split 模式必須整組 TL/TH 都沒有被寫才允許計數，避免一個 13/16-bit 數值的部分寫入被自動更新覆蓋。
            end else if (enabled && !write_tl && !write_th) begin
                // 【教學】依兩個模式位選計數硬體：00 為 13-bit、01 為 16-bit、10 為 8-bit 自動重載。
                case (tmod[1:0])
                    // 【教學】Mode0：走 13-bit 計數路徑，對應傳統 8051 的相容模式。
                    2'b00: begin
                        // 【教學】{} 把 TH0 的 8 位和 TL0 的低 5 位接成 13 位再加一，實作 Mode0；TL0[7:5] 未被指派而保持。13'd1 明確指定運算常數寬度。
                        {th0, tl0[4:0]} <= {th0, tl0[4:0]} + 13'd1;
                        // 【教學】以更新前的 13 位全 1 判斷是否即將由 1FFF 回到 0；本拍設定 overflow0，讓外部 SFR bank 保存溢位旗標。
                        if ({th0, tl0[4:0]} == 13'h1fff) overflow0 <= 1'b1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】Mode1：走 16-bit 計數路徑，提供較長的計數範圍。
                    2'b01: begin
                        // 【教學】把 TH0/TL0 接成 16-bit 計數器再加一；固定 16 位自然捨棄最高進位，FFFF 的下一值為 0000。
                        {th0, tl0} <= {th0, tl0} + 16'd1;
                        // 【教學】Mode1 在更新前為 FFFF 時發出溢位脈波；必須看舊值，因為 <= 的新值要到本次時序計算結束才提交。
                        if ({th0, tl0} == 16'hffff) overflow0 <= 1'b1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】Mode2：走 8-bit 自動重載路徑，常用來提供週期事件或 UART 鮑率。
                    2'b10: begin
                        // 【教學】Mode2 只讓 TL0 計數；到 FF 時走重載分支，而不是一般加一分支。
                        if (tl0 == 8'hff) begin
                            // 【教學】以 TH0 作固定重載值寫回 TL0，實作 8-bit 自動重載；不需要 CPU 每次溢位重新載值。
                            tl0 <= th0;
                            // 【教學】本拍計數已溢位，送出 overflow0=1；外部把這個事件鎖存為 TF0，下一拍本模組預設清回 0。
                            overflow0 <= 1'b1;
                        // 【教學】結束重載分支；尚未到 FF 時只把 TL0 加一，TH0 保留作下一次重載值。
                        end else tl0 <= tl0 + 8'd1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】沒有其他一般模式需要處理；Mode3 已在外層 split 分支處理，所以此空分支刻意不修改任何暫存器。
                    default: ;
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
