// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// 【教學】宣告 mcu8051_alu 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module mcu8051_alu (
    // 【教學】輸入由外層驅動；[4:0] 指定位元／陣列範圍。alu_op：ALU 運算選擇碼。
    input  wire [4:0] alu_op,   // 5-bit 操作碼
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。src_a：ALU 左運算元。
    input  wire [7:0] src_a,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。src_b：ALU 右運算元。
    input  wire [7:0] src_b,
    // 【教學】輸入由外層驅動。cy_in：運算前 CY，ADDC 作進位、SUBB 作借位。
    input  wire       cy_in,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。alu_out：八位運算結果。
    output reg  [7:0] alu_out,
    // 【教學】輸出供外層連接。cy_out：進位／借位旗標。
    output reg        cy_out,
    // 【教學】輸出供外層連接。ac_out：低四位的進位／借位旗標 AC。
    output reg        ac_out,
    // 【教學】輸出供外層連接。ov_out：有號數溢位旗標 OV。
    output reg        ov_out
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);

    // 將 DA A 暫存變數移至模組層級宣告，避免 case 分支內的編譯錯誤
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。da_step1：ALU 十進位調整第一段暫存。
    reg [7:0] da_step1;
    // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[8:0] 指定位元／陣列範圍。da_step2：ALU 十進位調整九位結果。
    reg [8:0] da_step2;

    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
    always @(*) begin
        // 預設旗標狀態
        // Combinational temporaries must be assigned on every path.
        // 【教學】da_step1 = 8'h00：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
        da_step1 = 8'h00;
        // 【教學】da_step2 = 9'h000：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
        da_step2 = 9'h000;
        // 【教學】cy_out = cy_in：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
        cy_out = cy_in;
        // 【教學】ac_out = 1'b0：低四位的進位／借位另存 AC，供 DA A 等 BCD 行為使用，使用阻塞 = 供同區塊後續計算立即使用。
        ac_out = 1'b0;
        // 【教學】ov_out = 1'b0：有號加減超出 -128～127 會改變結果符號；OV 與無號 CY 是不同概念，使用阻塞 = 供同區塊後續計算立即使用。
        ov_out = 1'b0;

        // 【教學】依 alu_op 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
        case (alu_op)
            // 【教學】命中 5'd0 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd0: alu_out = src_a;                                                // ALU_NOP
            // 【教學】命中 5'd1 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd1: alu_out = src_b;                                                // ALU_PASS
            
            // 【教學】命中 5'd2 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd2: begin                                                           // ALU_ADD
                // 【教學】{cy_out, alu_out} = src_a + src_b：左邊共九位，保存八位結果與最高進位，不讓 carry 被截掉，使用阻塞 = 供同區塊後續計算立即使用。
                {cy_out, alu_out} = src_a + src_b;
                // 【教學】ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} > 5'h0F)：低四位的進位／借位另存 AC，供 DA A 等 BCD 行為使用，使用阻塞 = 供同區塊後續計算立即使用。
                ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} > 5'h0F);
                // 【教學】ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7])：有號加減超出 -128～127 會改變結果符號；OV 與無號 CY 是不同概念，使用阻塞 = 供同區塊後續計算立即使用。
                ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7]);
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 5'd3 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd3: begin                                                           // ALU_ADDC
                // 【教學】{cy_out, alu_out} = src_a + src_b + cy_in：左邊共九位，保存八位結果與最高進位，不讓 carry 被截掉，使用阻塞 = 供同區塊後續計算立即使用。
                {cy_out, alu_out} = src_a + src_b + cy_in;
                // 【教學】ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} + cy_in > 5'h0F)：低四位的進位／借位另存 AC，供 DA A 等 BCD 行為使用，使用阻塞 = 供同區塊後續計算立即使用。
                ac_out = ({1'b0, src_a[3:0]} + {1'b0, src_b[3:0]} + cy_in > 5'h0F);
                // 【教學】ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7])：有號加減超出 -128～127 會改變結果符號；OV 與無號 CY 是不同概念，使用阻塞 = 供同區塊後續計算立即使用。
                ov_out = (src_a[7] == src_b[7]) && (alu_out[7] != src_a[7]);
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 5'd4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd4: begin                                                           // ALU_SUBB
                // 8051 CY after SUBB is BORROW, not the MSB of a truncated
                // subtraction result.
                // 【教學】alu_out = src_a - src_b - cy_in：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                alu_out = src_a - src_b - cy_in;
                // 【教學】cy_out = ({1'b0, src_a} < ({1'b0, src_b} + cy_in))：SUBB 的 CY 是無號借位，必須比較擴展後的運算元，不能直接拿截短減法的最高位，使用阻塞 = 供同區塊後續計算立即使用。
                cy_out  = ({1'b0, src_a} < ({1'b0, src_b} + cy_in));
                // 【教學】ac_out = ({1'b0, src_a[3:0]} < ({1'b0, src_b[3:0]} + cy_in))：低四位的進位／借位另存 AC，供 DA A 等 BCD 行為使用，使用阻塞 = 供同區塊後續計算立即使用。
                ac_out  = ({1'b0, src_a[3:0]} < ({1'b0, src_b[3:0]} + cy_in));
                // 【教學】ov_out = (src_a[7] != src_b[7]) && (alu_out[7] != src_a[7])：有號加減超出 -128～127 會改變結果符號；OV 與無號 CY 是不同概念，使用阻塞 = 供同區塊後續計算立即使用。
                ov_out  = (src_a[7] != src_b[7]) && (alu_out[7] != src_a[7]);
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 5'd5 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a + 1'b1：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd5: alu_out = src_a + 1'b1;                                         // ALU_INC
            // 【教學】命中 5'd6 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a - 1'b1：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd6: alu_out = src_a - 1'b1;                                         // ALU_DEC
            // 【教學】命中 5'd7 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a & src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd7: alu_out = src_a & src_b;                                        // ALU_ANL
            // 【教學】命中 5'd8 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a | src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd8: alu_out = src_a | src_b;                                        // ALU_ORL
            // 【教學】命中 5'd9 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a ^ src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd9: alu_out = src_a ^ src_b;                                        // ALU_XRL
            // 【教學】命中 5'd10 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_a * src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd10: alu_out = src_a * src_b;                                       // ALU_MUL
            // 【教學】命中 5'd11 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = (src_b != 8'h00) ? (src_a / src_b) : 8'hFF：形成純組合資料路徑；?: 是依條件選結果的多工器，使用阻塞 = 供同區塊後續計算立即使用。
            5'd11: alu_out = (src_b != 8'h00) ? (src_a / src_b) : 8'hFF;          // ALU_DIV
            
            // 【教學】命中 5'd12 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd12: begin                                                          // ALU_DA (DA A)
                // 階段 1：若低 4 位大於 9 則低位加 0x06
                // 【教學】da_step1 = (src_a[3:0] > 4'h9) ? (src_a + 8'h06) : src_a：形成純組合資料路徑；?: 是依條件選結果的多工器，使用阻塞 = 供同區塊後續計算立即使用。
                da_step1 = (src_a[3:0] > 4'h9) ? (src_a + 8'h06) : src_a;
                
                // 階段 2：若高 4 位大於 9 或有 CY 旗標，高位加 0x60 並更新 CY
                // 【教學】條件成立才走後續分支；da_step1=ALU 十進位調整第一段暫存；cy_in=運算前 CY，ADDC 作進位、SUBB 作借位。沒有選此分支時依 else 或保持規則處理。
                if ((da_step1[7:4] > 4'h9) || cy_in) begin
                    // 【教學】da_step2 = {1'b0, da_step1} + 9'h060：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                    da_step2 = {1'b0, da_step1} + 9'h060;
                    // 【教學】alu_out = da_step2[7:0]：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                    alu_out  = da_step2[7:0];
                    // 【教學】cy_out = 1'b1：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                    cy_out   = 1'b1;
                // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                end else begin
                    // 【教學】alu_out = da_step1：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                    alu_out  = da_step1;
                    // 【教學】cy_out = cy_in：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                    cy_out   = cy_in;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 5'd13 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = {src_a[6:0], src_a[7]}：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd13: alu_out = {src_a[6:0], src_a[7]};                              // ALU_RL
            
            // 【教學】命中 5'd14 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd14: begin                                                          // ALU_RLC
                // 【教學】alu_out = {src_a[6:0], cy_in}：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                alu_out = {src_a[6:0], cy_in};
                // 【教學】cy_out = src_a[7]：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                cy_out  = src_a[7];
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 5'd15 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = {src_a[0], src_a[7:1]}：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            5'd15: alu_out = {src_a[0], src_a[7:1]};                              // ALU_RR
            
            // 【教學】命中 5'd16 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd16: begin                                                          // ALU_RRC
                // 【教學】alu_out = {cy_in, src_a[7:1]}：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                alu_out = {cy_in, src_a[7:1]};
                // 【教學】cy_out = src_a[0]：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                cy_out  = src_a[0];
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end


            // 【教學】命中 5'd17 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            5'd17: begin                                                          // ALU_CMP (CJNE)
                // CJNE compares unsigned operands and does NOT subtract CY-in.
                // alu_out is used only for equality/branch decision.
                // 【教學】alu_out = src_a - src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
                alu_out = src_a - src_b;
                // 【教學】cy_out = (src_a < src_b)：SUBB 的 CY 是無號借位，必須比較擴展後的運算元，不能直接拿截短減法的最高位，使用阻塞 = 供同區塊後續計算立即使用。
                cy_out  = (src_a < src_b);
                // 【教學】ac_out = 1'b0：低四位的進位／借位另存 AC，供 DA A 等 BCD 行為使用，使用阻塞 = 供同區塊後續計算立即使用。
                ac_out  = 1'b0;
                // 【教學】ov_out = 1'b0：有號加減超出 -128～127 會改變結果符號；OV 與無號 CY 是不同概念，使用阻塞 = 供同區塊後續計算立即使用。
                ov_out  = 1'b0;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            
            // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。alu_out = src_b：形成純組合資料路徑，使用阻塞 = 供同區塊後續計算立即使用。
            default: alu_out = src_b;
        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
        endcase
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
