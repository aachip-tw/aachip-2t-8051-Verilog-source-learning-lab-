// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns/1ps

// Byte RAM with a rising-edge write port and falling-edge read address port.
// PIPELINED_READ=0 returns data for the next rising edge.  PIPELINED_READ=1
// registers the M9K output on that rising edge; the CPU inserts a read wait
// state before consuming it. RAM contents survive CPU/system reset.
// 【教學】宣告 mcu8051_memory 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module mcu8051_memory #(
    // 【教學】建構電路時設定的參數 PIPELINED_READ：與核心 RAM_PIPELINED 必須一致，避免讀到上一筆資料。
    parameter integer PIPELINED_READ = 0,
    // 【教學】建構電路時設定的參數 ADDR_WIDTH：RAM 地址線位數，預設八位。
    parameter integer ADDR_WIDTH = 8,
    // 【教學】建構電路時設定的參數 DEPTH：可用 byte 數，基本整合設 128，越界讀 0、寫忽略。
    parameter integer DEPTH = 256,
    // 【教學】建構電路時設定的參數 INIT_FILE：可選 readmemh 初始化檔，空字串表示不載檔。
    parameter INIT_FILE = ""
// 【教學】結束參數清單並開始對外埠清單；參數決定配置，埠是運作時的訊號。
) (
    // 【教學】輸入由外層驅動。clk：共同時鐘，上升沿更新時序邏輯。
    input wire clk,
    // 【教學】輸入由外層驅動；[ADDR_WIDTH-1:0] 指定位元／陣列範圍。rd_addr：RAM 讀地址。
    input wire [ADDR_WIDTH-1:0] rd_addr,
    // 【教學】輸出供外層連接；[7:0] 指定位元／陣列範圍。rd_data：RAM 回傳資料。
    output wire [7:0] rd_data,
    // 【教學】輸入由外層驅動。wr_en：RAM 上升沿寫入使能。
    input wire wr_en,
    // 【教學】輸入由外層驅動；[ADDR_WIDTH-1:0] 指定位元／陣列範圍。wr_addr：RAM 寫地址。
    input wire [ADDR_WIDTH-1:0] wr_addr,
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。wr_data：RAM 寫資料。
    input wire [7:0] wr_data
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】建構電路時展開 RAM 區塊，g_sim 是階層名稱；此可攜版不需 Altera 的 altsyncram 原語。
    generate if (1) begin: g_sim
        // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0],[0:DEPTH-1] 指定位元／陣列範圍。mem：byte RAM 陣列。
        reg [7:0] mem [0:DEPTH-1];
        // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[7:0] 指定位元／陣列範圍。read_data：RAM 輸出資料暫存。
        reg [7:0] read_data;
        // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存；[ADDR_WIDTH-1:0] 指定位元／陣列範圍。read_addr_b：下降沿鎖存的 RAM 讀地址。
        reg [ADDR_WIDTH-1:0] read_addr_b;
        // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。read_valid_b：上一個讀地址是否落在 RAM 深度內。
        reg read_valid_b;
        // 【教學】程序變數；時鐘 always 內保存狀態，完整組合 always 則不儲存。i：初始化 for 迴圈的整數索引，不是 CPU R 暫存器。
        integer i;
        // 【教學】模擬／受支援 FPGA 的上電初始化區塊，只在啟動執行一次；不是每個 reset 都重新清 RAM。
        initial begin
            // 【教學】read_data（RAM 輸出資料暫存）取 8'h00；initial 只描述模擬／可支援的 FPGA 初始化，不是 rst_n 重置清 RAM。
            read_data = 8'h00;
            // 【教學】read_addr_b（下降沿鎖存的 RAM 讀地址）取 {ADDR_WIDTH{1'b0}}；initial 只描述模擬／可支援的 FPGA 初始化，不是 rst_n 重置清 RAM。
            read_addr_b = {ADDR_WIDTH{1'b0}};
            // 【教學】read_valid_b（上一個讀地址是否落在 RAM 深度內）取 1'b0；initial 只描述模擬／可支援的 FPGA 初始化，不是 rst_n 重置清 RAM。
            read_valid_b = 1'b0;
            // 【教學】初始化時用整數 i 逐 byte 清 RAM；for 是描述展開／初始化行為，並非 CPU 程式去執行迴圈。
            for (i=0; i<DEPTH; i=i+1) mem[i] = 8'h00;
            // 【教學】只有 INIT_FILE 非空才讀十六進位文字檔到 mem，供模擬或支援的 FPGA 初始化；此設計沒有執行期程式下載通道。
            if (INIT_FILE != "") $readmemh(INIT_FILE, mem);
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
        // 【教學】僅 clk 上升沿更新，沒有 reset 分支；RAM 資料不隨 CPU 重置清除，讀輸出流水級也由此沿取樣。
        always @(posedge clk)
            // 【教學】由本行 if 的條件限制更新；不命中則保持時序舊值或使用組合預設。mem[wr_addr]（byte RAM 陣列）取 wr_data；依所在上升／下降沿取樣，與 CPU 讀等待狀態配合。
            if (wr_en && wr_addr < DEPTH) mem[wr_addr] <= wr_data;
        // 【教學】依建構時的 PIPELINED_READ 選擇是否加入上升沿讀資料暫存；兩條 generate 路徑不會同時建構，CPU 參數需配合。
        if (PIPELINED_READ == 0) begin: g_unregistered_read
            // 【教學】在 clk 下降沿取樣 RAM 地址／讀值，讓下一個上升沿 CPU 可以使用；這是本核心的半週期記憶體時序合約。
            always @(negedge clk)
                // 【教學】read_data（RAM 輸出資料暫存）取 (rd_addr < DEPTH) ? mem[rd_addr] : 8'h00；依所在上升／下降沿取樣，與 CPU 讀等待狀態配合。
                read_data <= (rd_addr < DEPTH) ? mem[rd_addr] : 8'h00;
        // 【教學】依建構時的 PIPELINED_READ 選擇是否加入上升沿讀資料暫存；兩條 generate 路徑不會同時建構，CPU 參數需配合。
        end else begin: g_registered_read
            // 【教學】在 clk 下降沿取樣 RAM 地址／讀值，讓下一個上升沿 CPU 可以使用；這是本核心的半週期記憶體時序合約。
            always @(negedge clk) begin
                // 【教學】read_addr_b（下降沿鎖存的 RAM 讀地址）取 rd_addr；依所在上升／下降沿取樣，與 CPU 讀等待狀態配合。
                read_addr_b <= rd_addr;
                // 【教學】read_valid_b（上一個讀地址是否落在 RAM 深度內）取 (rd_addr < DEPTH)；依所在上升／下降沿取樣，與 CPU 讀等待狀態配合。
                read_valid_b <= (rd_addr < DEPTH);
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】僅 clk 上升沿更新，沒有 reset 分支；RAM 資料不隨 CPU 重置清除，讀輸出流水級也由此沿取樣。
            always @(posedge clk)
                // 【教學】read_data（RAM 輸出資料暫存）取 read_valid_b ? mem[read_addr_b] : 8'h00；依所在上升／下降沿取樣，與 CPU 讀等待狀態配合。
                read_data <= read_valid_b ? mem[read_addr_b] : 8'h00;
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
        // 【教學】rd_data（RAM 回傳資料）取 read_data；initial 只描述模擬／可支援的 FPGA 初始化，不是 rst_n 重置清 RAM。
        assign rd_data = read_data;
    // 【教學】先關閉 RAM generate 的具名區塊，再結束 generate；不是多一個 CPU 執行階段。
    end endgenerate
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
