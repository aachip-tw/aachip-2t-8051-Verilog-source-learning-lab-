// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns / 1ps

// 【教學】Timer0 split 時，真正 Timer1 的溢位仍可用來產生 UART 鮑率。
// 8051 Timer 1.  In Timer-0 mode 3 its overflow remains available to the
// 【教學】架構上的 TF1 旗標此時改由 TH0 的溢位負責。
// serial baud generator, while TH0 owns the architectural TF1 flag.
// 【教學】宣告可重複使用的硬體模組 mcu8051_timer1，後面列出它對外的腳位。
module mcu8051_timer1 (
    // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire       clk,
    // 【教學】input 由外部驅動，模組只讀取。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire       rst_n,
    // 【教學】input 由外部驅動，模組只讀取。timer_tick：計時器的一次計數使能，不是另一個 clock。
    input  wire       timer_tick,
    // 【教學】input 由外部驅動，模組只讀取。t1_pin：Counter1 外部下降沿輸入。
    input  wire       t1_pin,
    // 【教學】input 由外部驅動，模組只讀取。int1_n：低有效 INT1 輸入／合併後訊號。
    input  wire       int1_n,
    // 【教學】input 由外部驅動，模組只讀取；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tmod：計數模式控制；單一 timer 接收自己的四位，bank 保存完整八位。
    input  wire [3:0] tmod,
    // 【教學】input 由外部驅動，模組只讀取。tr1：Timer1 啟動；T0 Mode3 也用來控制 TH0。
    input  wire       tr1,
    // 【教學】input 由外部驅動，模組只讀取。timer0_split_mode：保留的 split 指示輸入；此 Timer1 原碼沒有使用它。
    input  wire       timer0_split_mode,
    // 【教學】input 由外部驅動，模組只讀取。write_tl：寫入計數器低 byte 的單拍使能。
    input  wire       write_tl,
    // 【教學】input 由外部驅動，模組只讀取。write_th：寫入計數器高 byte 的單拍使能。
    input  wire       write_th,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。write_data：計數器寫入 byte。
    input  wire [7:0] write_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tl1：Timer1 低 byte 的儲存值。
    output reg  [7:0] tl1,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。th1：Timer1 高 byte／Mode2 重載值。
    output reg  [7:0] th1,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。overflow1：Timer1 單拍溢位事件，也供 UART 鮑率使用。
    output reg        overflow1
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。t1_d：T1 前一拍電位，和本拍比較可偵測下降沿。
    reg t1_d;
    // 【教學】把 T1 明確為 0 的情況判為低，其餘判為高；=== 是四態完全相等，能處理模擬中的 X/Z。這是原碼的模擬預設，不是實體上拉或同步器。
    wire t1_level = (t1_pin === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】前一拍 T1 為高、本拍為低才產生下降沿事件；用一拍記憶把外部電位轉成一次計數，並非兩級 CDC 同步。
    wire t1_fall = t1_d && !t1_level;
    // 【教學】TMOD[3]=GATE；未開 GATE 就放行，開啟後要求 INT1 不是明確低。|| 為邏輯或；!== 在模擬中也比較 X/Z。
    wire gate_open = !tmod[3] || (int1_n !== 1'b0);
    // 【教學】TMOD[2]=C/T，1 選 T1 下降沿當外部計數器，0 選 timer_tick 當計時器；?: 對應二選一多工器。
    wire count_event = tmod[2] ? t1_fall : timer_tick;
    // 【教學】Timer0 split 時仍保留 Timer1 作 UART 鮑率來源。
    // Timer 1 remains usable as the serial baud generator while Timer 0 is in
    // 【教學】頂層改接 TF1 來源，不讓這個 Timer1 溢位誤設架構 TF1。
    // split mode.  The top level masks this overflow from TF1 in that case.
    // 【教學】必須 TR1 啟動、GATE 放行、而且本拍真的有計數事件，三者同時成立才加一；&& 是邏輯且。
    wire enabled = tr1 && gate_open && count_event;

    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
        if (!rst_n) begin
            // 【教學】tl1（Timer1 低 byte 的儲存值）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tl1 <= 8'h00;
            // 【教學】th1（Timer1 高 byte／Mode2 重載值）寫入 8'h00，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            th1 <= 8'h00;
            // 【教學】把 T1 的前一拍電位設為高，提供確定的下降沿判斷初值；重置後若輸入本來就低，可能被視為第一個下降沿。
            t1_d <= 1'b1;
            // 【教學】將 overflow1 清零：重置時建立初值；正常運轉時每拍先清零，再由下方終值條件設 1，因而形成單拍事件而非永久旗標。
            overflow1 <= 1'b0;
        // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
        end else begin
            // 【教學】每個 clk 保存本拍 T1 電位；非阻塞 <= 讓本拍邊沿判斷仍能使用更新前的 t1_d。
            t1_d <= t1_level;
            // 【教學】將 overflow1 清零：重置時建立初值；正常運轉時每拍先清零，再由下方終值條件設 1，因而形成單拍事件而非永久旗標。
            overflow1 <= 1'b0;
            // 【教學】只有低位元組寫入脈波有效才改 TL1；沒寫入時由後面的計數邏輯決定新值。
            if (write_tl) tl1 <= write_data;
            // 【教學】只有高位元組寫入脈波有效才改 TH1；後面計數條件會排除寫入，避免同拍自動計數蓋掉軟體設定。
            if (write_th) th1 <= write_data;

            // 【教學】只有計數事件且 TL1/TH1 都沒有軟體寫入才更新 Timer1，軟體可可靠設定初值。
            if (enabled && !write_tl && !write_th) begin
                // 【教學】依兩個模式位選計數硬體：00 為 13-bit、01 為 16-bit、10 為 8-bit 自動重載。
                case (tmod[1:0])
                    // 【教學】Mode0：走 13-bit 計數路徑，對應傳統 8051 的相容模式。
                    2'b00: begin
                        // 【教學】{} 把 TH1 的 8 位和 TL1 的低 5 位接成 13 位再加一，實作 Mode0；TL1[7:5] 未被指派而保持。13'd1 明確指定運算常數寬度。
                        {th1, tl1[4:0]} <= {th1, tl1[4:0]} + 13'd1;
                        // 【教學】以更新前的 13 位全 1 判斷是否即將由 1FFF 回到 0；本拍設定 overflow1，讓外部 SFR bank 保存溢位旗標。
                        if ({th1, tl1[4:0]} == 13'h1fff) overflow1 <= 1'b1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】Mode1：走 16-bit 計數路徑，提供較長的計數範圍。
                    2'b01: begin
                        // 【教學】把 TH1/TL1 接成 16-bit 計數器再加一；固定 16 位自然捨棄最高進位，FFFF 的下一值為 0000。
                        {th1, tl1} <= {th1, tl1} + 16'd1;
                        // 【教學】Mode1 在更新前為 FFFF 時發出溢位脈波；必須看舊值，因為 <= 的新值要到本次時序計算結束才提交。
                        if ({th1, tl1} == 16'hffff) overflow1 <= 1'b1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】Mode2：走 8-bit 自動重載路徑，常用來提供週期事件或 UART 鮑率。
                    2'b10: begin
                        // 【教學】Mode2 只讓 TL1 計數；到 FF 時走重載分支，而不是一般加一分支。
                        if (tl1 == 8'hff) begin
                            // 【教學】以 TH1 作固定重載值寫回 TL1，實作 8-bit 自動重載；不需要 CPU 每次溢位重新載值。
                            tl1 <= th1;
                            // 【教學】本拍計數已溢位，送出 overflow1=1；外部把這個事件鎖存為 TF1，下一拍本模組預設清回 0。
                            overflow1 <= 1'b1;
                        // 【教學】結束重載分支；尚未到 FF 時只把 TL1 加一，TH1 保留作下一次重載值。
                        end else tl1 <= tl1 + 8'd1;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                    // 【教學】Timer1 的模式 3 不計數，default 空敘述讓原值保持。
                    // Mode 3 is reserved for Timer 1 and does not count.
                    // 【教學】其他模式不更新計數器，所以 Timer1 Mode3 保持原值。空敘述是刻意保留，不是漏寫計數。
                    default: ;
                // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                endcase
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
