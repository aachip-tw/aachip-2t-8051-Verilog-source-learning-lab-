// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】基本 8051 的核心組裝檔；每一程式行上方說明用途與設計原因。
// 【學生閱讀】時序 <= 取同拍舊值後提交；不同子模組同時工作，不能當循序軟體閱讀。
// ============================================================================
// Module Name : mcu8051_ucode_rom
// Description : Optimized 8051 Microcode Decoder ROM
// Architecture: Hybrid Decoding (Special Case Exception + Bit Pattern Matrix)
// ============================================================================
// 【教學】宣告 mcu8051_ucode_rom 硬體模組；CPU、微碼、ALU、RAM 與周邊以實例接線並行運作。
module mcu8051_ucode_rom (
    // 【教學】輸入由外層驅動；[7:0] 指定位元／陣列範圍。opcode：原始八位指令操作碼。
    input  wire [7:0]  opcode,
    // 【教學】輸出供外層連接；[1:0] 指定位元／陣列範圍。bytes：指令總 byte 數，供取指與 PC 推進使用。
    output reg  [1:0]  bytes,         // Instruction length (1~3 bytes)
    // 【教學】輸出供外層連接。ram_rd：微碼記憶體讀需求。
    output reg         ram_rd,        // Internal/External RAM Read Enable
    // 【教學】輸出供外層連接。ram_wr：微碼記憶體寫需求。
    output reg         ram_wr,        // Internal/External RAM Write Enable
    // 【教學】輸出供外層連接；[4:0] 指定位元／陣列範圍。alu_op：ALU 運算選擇碼。
    output reg  [4:0]  alu_op,        // ALU Operation Select 擴充為 5 bits
    // 【教學】輸出供外層連接；[3:0] 指定位元／陣列範圍。src_sel：來源定址方式。
    output reg  [3:0]  src_sel,       // Source Operand Select
    // 【教學】輸出供外層連接；[3:0] 指定位元／陣列範圍。dst_sel：目的定址方式。
    output reg  [3:0]  dst_sel,       // Destination Operand Select
    // 【教學】輸出供外層連接。cy_we：此指令是否更新 CY。
    output reg         cy_we,         // Carry Flag Write Enable
    // 【教學】輸出供外層連接；[2:0] 指定位元／陣列範圍。jmp_type：跳轉／呼叫種類。
    output reg  [2:0]  jmp_type       // Branch / Jump Type
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);

    // ------------------------------------------------------------------------
    // ALU Operation Encodings
    // ------------------------------------------------------------------------
    // 【教學】定義模組內固定編碼，不是執行期暫存器。ALU_NOP：保持左運算元；ALU_PASS：直接傳右運算元，不加上目的舊值；ALU_ADD：無進位加法；ALU_ADDC：含 CY 的加法
    localparam ALU_NOP  = 5'd0, ALU_PASS = 5'd1, ALU_ADD  = 5'd2, ALU_ADDC = 5'd3,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。ALU_SUBB：含 CY 借位的減法；ALU_INC：加一；ALU_DEC：減一；ALU_ANL：逐位 AND
               ALU_SUBB = 5'd4, ALU_INC  = 5'd5, ALU_DEC  = 5'd6, ALU_ANL  = 5'd7,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。ALU_ORL：逐位 OR；ALU_XRL：逐位 XOR；ALU_MUL：乘法；ALU_DIV：除法
               ALU_ORL  = 5'd8, ALU_XRL  = 5'd9, ALU_MUL  = 5'd10, ALU_DIV = 5'd11,
               // 【教學】定義模組內固定編碼，不是執行期暫存器。ALU_DA：BCD 調整；ALU_RL：循環左移；ALU_RLC：含 CY 循環左移；ALU_RR：循環右移
               ALU_DA   = 5'd12, ALU_RL  = 5'd13, ALU_RLC = 5'd14, ALU_RR  = 5'd15, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。ALU_RRC：含 CY 循環右移；ALU_CMP：CJNE 無號比較
               ALU_RRC  = 5'd16, ALU_CMP = 5'd17;

    // ------------------------------------------------------------------------
    // Operand Source / Destination Encodings
    // ------------------------------------------------------------------------
    // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_NONE：沒有運算元；SEL_ACC：累加器 A；SEL_REG：目前 PSW bank 的 R0～R7；SEL_IND：R0/R1 間接地址
    localparam SEL_NONE = 4'd0, SEL_ACC = 4'd1, SEL_REG = 4'd2, SEL_IND = 4'd3, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_DIR：直接 byte 地址；SEL_IMM：指令內立即數；SEL_DPTR：十六位 DPTR；SEL_PC：程式計數 PC
               SEL_DIR  = 4'd4, SEL_IMM = 4'd5, SEL_DPTR = 4'd6, SEL_PC = 4'd7, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。SEL_BIT：位元位址運算元；SEL_EXT：MOVC/MOVX 額外記憶體來源
               SEL_BIT  = 4'd8, SEL_EXT = 4'd9;

    // ------------------------------------------------------------------------
    // Jump / Control Encodings
    // ------------------------------------------------------------------------
    // 【教學】定義模組內固定編碼，不是執行期暫存器。JMP_NONE：不跳轉；JMP_SJMP：相對／特殊跳轉；JMP_AJMP：11-bit 頁內絕對跳轉；JMP_LJMP：16-bit 絕對跳轉
    localparam JMP_NONE = 3'd0, JMP_SJMP = 3'd1, JMP_AJMP = 3'd2, JMP_LJMP = 3'd3, 
               // 【教學】定義模組內固定編碼，不是執行期暫存器。JMP_CJNE：比較不同就跳轉；JMP_DJNZ：減一非零跳轉；JMP_RET：RET 或 RETI 堆疊返回；JMP_CALL：CALL 呼叫並壓返回 PC
               JMP_CJNE = 3'd4, JMP_DJNZ = 3'd5, JMP_RET = 3'd6, JMP_CALL = 3'd7;

    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
    always @(*) begin
        // 預設控制信號 (Default NOP-like State)
        // 【教學】bytes 設為 2'd1，讓後級依此控制欄位執行。
        bytes    = 2'd1;
        // 【教學】ram_rd 設為 1'b0，讓後級依此控制欄位執行。
        ram_rd   = 1'b0;
        // 【教學】ram_wr 設為 1'b0，讓後級依此控制欄位執行。
        ram_wr   = 1'b0; 
        // 【教學】alu_op 設為 ALU_NOP（保持左運算元），讓後級依此控制欄位執行。
        alu_op   = ALU_NOP;
        // 【教學】src_sel 設為 SEL_NONE（沒有運算元），讓後級依此控制欄位執行。
        src_sel  = SEL_NONE;
        // 【教學】dst_sel 設為 SEL_NONE（沒有運算元），讓後級依此控制欄位執行。
        dst_sel  = SEL_NONE;
        // 【教學】cy_we 設為 1'b0，讓後級依此控制欄位執行。
        cy_we    = 1'b0;
        // 【教學】jmp_type 設為 JMP_NONE（不跳轉），讓後級依此控制欄位執行。
        jmp_type = JMP_NONE;

        // --------------------------------------------------------------------
        // 第一層：優先處理不規則 / 特殊指令例外 (Exceptions)
        // --------------------------------------------------------------------
        // 【教學】依 opcode 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
        case (opcode)
            // 【教學】命中 8'h00 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_NOP（保持左運算元），讓後級依此控制欄位執行。
            8'h00: begin bytes = 2'd1; alu_op = ALU_NOP; end // NOP
            // 【教學】命中 8'h02 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_LJMP（16-bit 絕對跳轉），讓後級依此控制欄位執行。
            8'h02: begin bytes = 2'd3; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_LJMP; end // LJMP addr16
            // 【教學】命中 8'h03 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_RR（循環右移），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'h03: begin bytes = 2'd1; alu_op = ALU_RR; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // RR A
            // 【教學】命中 8'h10 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h10: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JBC
            // 【教學】命中 8'h12 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_CALL（CALL 呼叫並壓返回 PC），讓後級依此控制欄位執行。
            8'h12: begin bytes = 2'd3; ram_rd = 1'b1; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_CALL; end // LCALL
            // 【教學】命中 8'h13 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_RRC（含 CY 循環右移），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
            8'h13: begin bytes = 2'd1; alu_op = ALU_RRC; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // RRC A
            // 【教學】命中 8'h20 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h20: begin bytes = 2'd3; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JB
            // 【教學】命中 8'h22 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_RET（RET 或 RETI 堆疊返回），讓後級依此控制欄位執行。
            8'h22: begin bytes = 2'd1; ram_rd = 1'b1; dst_sel = SEL_PC; jmp_type = JMP_RET; end // RET
            // 【教學】命中 8'h23 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_RL（循環左移），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'h23: begin bytes = 2'd1; alu_op = ALU_RL; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // RL A
            // 【教學】命中 8'h30 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h30: begin bytes = 2'd3; src_sel = SEL_BIT; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNB
            // 【教學】命中 8'h32 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_RET（RET 或 RETI 堆疊返回），讓後級依此控制欄位執行。
            8'h32: begin bytes = 2'd1; ram_rd = 1'b1; dst_sel = SEL_PC; jmp_type = JMP_RET; end // RETI
            // 【教學】命中 8'h33 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_RLC（含 CY 循環左移），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
            8'h33: begin bytes = 2'd1; alu_op = ALU_RLC; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // RLC A
            // 【教學】命中 8'h40 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h40: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JC
            // 【教學】命中 8'h42 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_ORL（逐位 OR），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h42: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ORL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h43 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_ORL（逐位 OR），讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h43: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ORL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h50 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h50: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNC
            // 【教學】命中 8'h52 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_ANL（逐位 AND），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h52: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ANL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h53 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_ANL（逐位 AND），讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h53: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_ANL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h60 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h60: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JZ
            // 【教學】命中 8'h62 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_XRL（逐位 XOR），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h62: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_XRL; src_sel = SEL_ACC; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h63 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_XRL（逐位 XOR），讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h63: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_XRL; src_sel = SEL_IMM; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h70 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h70: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JNZ
            // 【教學】命中 8'h72 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；alu_op 設為 ALU_ORL（逐位 OR），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'h72: begin bytes = 2'd2; alu_op = ALU_ORL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'h73 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h73: begin bytes = 2'd1; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // JMP @A+DPTR
            // 【教學】命中 8'h80 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行；jmp_type 設為 JMP_SJMP（相對／特殊跳轉），讓後級依此控制欄位執行。
            8'h80: begin bytes = 2'd2; src_sel = SEL_IMM; dst_sel = SEL_PC; jmp_type = JMP_SJMP; end // SJMP
            // 【教學】命中 8'h82 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；alu_op 設為 ALU_ANL（逐位 AND），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'h82: begin bytes = 2'd2; alu_op = ALU_ANL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'h83 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'h83: begin bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_EXT; dst_sel = SEL_ACC; end
            // 【教學】命中 8'h84 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_DIV（除法），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'h84: begin bytes = 2'd1; ram_rd = 1'b1; alu_op = ALU_DIV; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // DIV AB
            // 【教學】命中 8'h85 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
            8'h85: begin bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_DIR; end
            // 【教學】命中 8'h90 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd3，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行；dst_sel 設為 SEL_DPTR（十六位 DPTR），讓後級依此控制欄位執行。
            8'h90: begin bytes = 2'd3; alu_op = ALU_PASS; src_sel = SEL_IMM; dst_sel = SEL_DPTR; end
            // 【教學】命中 8'h92 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'h92: begin bytes = 2'd2; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'h93 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'h93: begin bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_EXT; dst_sel = SEL_ACC; end
            // 【教學】命中 8'hA0 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；alu_op 設為 ALU_ORL（逐位 OR），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hA0: begin bytes = 2'd2; alu_op = ALU_ORL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'hA2 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hA2: begin bytes = 2'd2; alu_op = ALU_PASS; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'hA4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_MUL（乘法），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
            8'hA4: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_MUL; src_sel = SEL_ACC; dst_sel = SEL_ACC; end // MUL AB
            // 【教學】命中 8'hA5 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_NOP（保持左運算元），讓後級依此控制欄位執行。
            8'hA5: begin bytes = 2'd1; alu_op = ALU_NOP; end
            // 【教學】命中 8'hB0 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；alu_op 設為 ALU_ANL（逐位 AND），讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hB0: begin bytes = 2'd2; alu_op = ALU_ANL; src_sel = SEL_BIT; dst_sel = SEL_BIT; end
            // 【教學】命中 8'hB2 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hB2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // CPL bit
            // 【教學】命中 8'hB3 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hB3: begin bytes = 2'd1; dst_sel = SEL_BIT; end // CPL C
            // 【教學】命中 8'hC2 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hC2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // CLR bit
            // 【教學】命中 8'hC3 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
            8'hC3: begin bytes = 2'd1; dst_sel = SEL_BIT; end // CLR C
            // 【教學】命中 8'hD4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_DA（BCD 調整），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
            8'hD4: begin bytes = 2'd1; alu_op = ALU_DA; src_sel = SEL_ACC; dst_sel = SEL_ACC; cy_we = 1'b1; end // DA A (影響 Carry)
            
            // ----------------------------------------------------------------
            // 第二層：矩陣規律拆解 (Matrix Rules)
            // ----------------------------------------------------------------
            // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
            default: begin
                // [規律 1] AJMP / ACALL (所有低 4 位為 0x1 之指令)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。沒有選此分支時依 else 或保持規則處理。
                if (opcode[3:0] == 4'h1) begin
                    // 【教學】bytes 設為 2'd2，讓後級依此控制欄位執行。
                    bytes    = 2'd2;
                    // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                    src_sel  = SEL_IMM;
                    // 【教學】dst_sel 設為 SEL_PC（程式計數 PC），讓後級依此控制欄位執行。
                    dst_sel  = SEL_PC;
                    // 【教學】jmp_type 設為 opcode[4] ? JMP_CALL : JMP_AJMP，讓後級依此控制欄位執行。
                    jmp_type = opcode[4] ? JMP_CALL : JMP_AJMP;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 2] 標準算術與邏輯群組 (ADD, ADDC, ORL, ANL, XRL, SUBB)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (((opcode[7:4] >= 4'h2 && opcode[7:4] <= 4'h6) || opcode[7:4] == 4'h9) && opcode[3:0] >= 4'h4) begin
                    // 【教學】dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                    dst_sel = SEL_ACC;
                    
                    // 【教學】依 opcode[7:4] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[7:4])
                        // 【教學】命中 4'h2 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_ADD（無進位加法），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
                        4'h2: begin alu_op = ALU_ADD; cy_we = 1'b1; end   // ADD 需更新 Carry
                        // 【教學】命中 4'h3 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_ADDC（含 CY 的加法），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
                        4'h3: begin alu_op = ALU_ADDC; cy_we = 1'b1; end  // ADDC 需更新 Carry
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_ORL（逐位 OR），讓後級依此控制欄位執行。
                        4'h4: alu_op = ALU_ORL;
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_ANL（逐位 AND），讓後級依此控制欄位執行。
                        4'h5: alu_op = ALU_ANL;
                        // 【教學】命中 4'h6 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_XRL（逐位 XOR），讓後級依此控制欄位執行。
                        4'h6: alu_op = ALU_XRL;
                        // 【教學】命中 4'h9 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_SUBB（含 CY 借位的減法），讓後級依此控制欄位執行；cy_we 設為 1'b1，讓後級依此控制欄位執行。
                        4'h9: begin alu_op = ALU_SUBB; cy_we = 1'b1; end  // SUBB 需更新 Carry
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。alu_op 設為 ALU_NOP（保持左運算元），讓後級依此控制欄位執行。
                        default: alu_op = ALU_NOP;
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase

                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                        4'h4:       begin bytes = 2'd2; src_sel = SEL_IMM; end                  // #data
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        4'h5:       begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_DIR; end   // direct
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_IND; end   // @Ri
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default:    begin bytes = 2'd1; src_sel = SEL_REG; end                  // R0 ~ R7
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

               // [規律 3] 遞增 / 遞減指令 (INC / DEC)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'h0 || opcode[7:4] == 4'h1) begin
                    // 【教學】alu_op 設為 (opcode[7:4] == 4'h0) ? ALU_INC : ALU_DEC，讓後級依此控制欄位執行。
                    alu_op = (opcode[7:4] == 4'h0) ? ALU_INC : ALU_DEC;
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                        4'h4: begin bytes = 2'd1; src_sel = SEL_ACC; dst_sel = SEL_ACC; end 
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        4'h5: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_DIR; dst_sel = SEL_DIR; end                       
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_IND; dst_sel = SEL_IND; end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行；dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default: begin bytes = 2'd1; src_sel = SEL_REG; dst_sel = SEL_REG; end // INC Rn
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 4] MOV A, src 數據讀取群組 (0xE_)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hE) begin
                    // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                    alu_op  = ALU_PASS;
                    // 【教學】dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                    dst_sel = SEL_ACC;
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h0 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行。
                        4'h0:       begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_EXT; end
                        // 【教學】命中 4'h2, 4'h3 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行。
                        4'h2, 4'h3: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_EXT; end
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；src_sel 設為 SEL_NONE（沒有運算元），讓後級依此控制欄位執行。
                        4'h4:       begin bytes = 2'd1; src_sel = SEL_NONE; end // CLR A
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        4'h5:       begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_DIR; end
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; src_sel = SEL_IND; end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default:    begin bytes = 2'd1; src_sel = SEL_REG; end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 5] MOV dest, A 數據寫入群組 (0xF_)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hF) begin
                    // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                    alu_op  = ALU_PASS;
                    // 【教學】src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                    src_sel = SEL_ACC;
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h0 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行。
                        4'h0:       begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_EXT; end
                        // 【教學】命中 4'h2, 4'h3 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_EXT（MOVC/MOVX 額外記憶體來源），讓後級依此控制欄位執行。
                        4'h2, 4'h3: begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_EXT; end
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                        4'h4:       begin bytes = 2'd1; dst_sel = SEL_ACC; end // CPL A
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        4'h5:       begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_DIR; end
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_IND; end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default:    begin bytes = 2'd1; ram_wr = 1'b1; dst_sel = SEL_REG; end // MOV Rn, A
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 6] CJNE 條件跳轉指令 (0xB4 ~ 0xBF)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hB && opcode[3:0] >= 4'h4) begin
                    // 【教學】bytes 設為 2'd3，讓後級依此控制欄位執行。
                    bytes    = 2'd3;
                    // 【教學】jmp_type 設為 JMP_CJNE（比較不同就跳轉），讓後級依此控制欄位執行。
                    jmp_type = JMP_CJNE;
                    // 【教學】alu_op 設為 ALU_CMP（CJNE 無號比較），讓後級依此控制欄位執行。
                    alu_op   = ALU_CMP;   // CJNE 比較不可受舊 CY 影響
                    // 【教學】cy_we 設為 1'b1，讓後級依此控制欄位執行。
                    cy_we    = 1'b1;      // operand1 < operand2 時 CY=1

                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h4: begin // B4: CJNE A,#data,rel
                            // 【教學】ram_rd 設為 1'b0，讓後級依此控制欄位執行。
                            ram_rd = 1'b0;
                            // 【教學】dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                            dst_sel = SEL_ACC;   // lhs = A
                            // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h5: begin // B5: CJNE A,direct,rel
                            // 【教學】ram_rd 設為 1'b1，讓後級依此控制欄位執行。
                            ram_rd = 1'b1;
                            // 【教學】dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                            dst_sel = SEL_ACC;   // lhs = A
                            // 【教學】src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                            src_sel = SEL_DIR;   // rhs = direct
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h6, 4'h7: begin // B6/B7: CJNE @R0/@R1,#data,rel
                            // 【教學】ram_rd 設為 1'b1，讓後級依此控制欄位執行。
                            ram_rd = 1'b1;
                            // 【教學】dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                            dst_sel = SEL_IND;   // lhs = @Ri
                            // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end

                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        default: begin // B8~BF: CJNE Rn,#data,rel
                            // 【教學】ram_rd 設為 1'b1，讓後級依此控制欄位執行。
                            ram_rd = 1'b1;
                            // 【教學】dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                            dst_sel = SEL_REG;   // lhs = Rn
                            // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                            src_sel = SEL_IMM;   // rhs = op1 (#data)
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
                
                // [規律 7] DJNZ 減一跳轉指令 (0xD5, 0xD8~0xDF)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hD && (opcode[3:0] == 4'h5 || opcode[3:0] >= 4'h8)) begin
                    // 【教學】alu_op 設為 ALU_DEC（減一），讓後級依此控制欄位執行。
                    alu_op   = ALU_DEC;
                    // 【教學】jmp_type 設為 JMP_DJNZ（減一非零跳轉），讓後級依此控制欄位執行。
                    jmp_type = JMP_DJNZ; 
                    // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。沒有選此分支時依 else 或保持規則處理。
                    if (opcode[3:0] == 4'h5) begin
                        // 【教學】bytes 設為 2'd3，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        bytes = 2'd3; ram_rd = 1'b1; ram_wr = 1'b1; src_sel = SEL_DIR; dst_sel = SEL_DIR;
                    // 【教學】開始互斥的 else 分支；同拍可有多筆 <=，但這個分支不會和對應 if 同時執行。
                    end else begin
                        // 【教學】bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行；dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        bytes = 2'd2; src_sel = SEL_REG; dst_sel = SEL_REG;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 8] MOV dest, #data 立即數寫入群組 (0x74 ~ 0x7F)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'h7 && opcode[3:0] >= 4'h4) begin
                    // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                    alu_op  = ALU_PASS;
                    // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                    src_sel = SEL_IMM;
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                        4'h4:       begin bytes = 2'd2; dst_sel = SEL_ACC; end // MOV A, #data
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h5: begin // MOV direct, #data (0x75)
                            // 【教學】bytes 設為 2'd3，讓後級依此控制欄位執行。
                            bytes    = 2'd3;
                            // MOV 必須直接寫入 immediate，不能把目的位址舊值加進來。
                            // ALU_PASS 會輸出 src_b，而 SEL_IMM/3-byte 指令的 src_b = op2。
                            // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                            alu_op   = ALU_PASS;
                            // 【教學】src_sel 設為 SEL_IMM（指令內立即數），讓後級依此控制欄位執行。
                            src_sel  = SEL_IMM; 
                            // 【教學】dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                            dst_sel  = SEL_DIR; 
                            // 【教學】ram_wr 設為 1'b1，讓後級依此控制欄位執行。
                            ram_wr   = 1'b1;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end 
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_IND; end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default:    begin bytes = 2'd2; ram_wr = 1'b1; dst_sel = SEL_REG; end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 9] MOV direct, src 直接定址寫入群組 (0x86 ~ 0x8F)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'h8 && opcode[3:0] >= 4'h6) begin
                    // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                    alu_op  = ALU_PASS;
                    // 【教學】dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                    dst_sel = SEL_DIR;
                    // 【教學】ram_wr 設為 1'b1，讓後級依此控制欄位執行。
                    ram_wr  = 1'b1;
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd2; ram_rd = 1'b1; src_sel = SEL_IND; end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                        default:    begin bytes = 2'd2; src_sel = SEL_REG; end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 10] MOV dest, direct 與 INC DPTR 群組 (0xA3, 0xA6 ~ 0xAF)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hA) begin
                    // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。沒有選此分支時依 else 或保持規則處理。
                    if (opcode == 8'hA3) begin // INC DPTR
                        // 【教學】bytes 設為 2'd1，讓後級依此控制欄位執行。
                        bytes   = 2'd1;
                        // 【教學】alu_op 設為 ALU_INC（加一），讓後級依此控制欄位執行。
                        alu_op  = ALU_INC; 
                        // 【教學】src_sel 設為 SEL_DPTR（十六位 DPTR），讓後級依此控制欄位執行。
                        src_sel = SEL_DPTR;
                        // 【教學】dst_sel 設為 SEL_DPTR（十六位 DPTR），讓後級依此控制欄位執行。
                        dst_sel = SEL_DPTR;
                    // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                    end else if (opcode[3:0] >= 4'h6) begin
                        // 【教學】alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行。
                        alu_op  = ALU_PASS;
                        // 【教學】ram_rd 設為 1'b1，讓後級依此控制欄位執行。
                        ram_rd  = 1'b1;
                        // 【教學】ram_wr 設為 1'b1，讓後級依此控制欄位執行。
                        ram_wr  = 1'b1;
                        // 【教學】src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        src_sel = SEL_DIR;
                        // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                        case (opcode[3:0])
                            // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                            4'h6, 4'h7: begin bytes = 2'd2; dst_sel = SEL_IND; end // MOV @Ri, direct
                            // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；dst_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行。
                            default:    begin bytes = 2'd2; dst_sel = SEL_REG; end // MOV Rn, direct
                        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                        endcase
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 11] PUSH, SWAP, XCH 群組 (0xC0, 0xC4 ~ 0xCF)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hC) begin
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h0 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h0: begin // PUSH direct
                            // 【教學】bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行。
                            bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_IND;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                        // 【教學】命中 4'h4 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h4: begin // SWAP A
                            // 【教學】bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                            bytes = 2'd1; alu_op = ALU_PASS; src_sel = SEL_ACC; dst_sel = SEL_ACC;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                        // 【教學】命中 4'h5 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h5: begin // XCH A, direct
                            // 【教學】bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                            bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_DIR; dst_sel = SEL_ACC;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        4'h6, 4'h7: begin // XCH A, @Ri
                            // 【教學】bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                            bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_ACC;
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。後續列出本分支的指派，state 變更於下一拍生效。
                        default: begin // XCH A, Rn
                            // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。沒有選此分支時依 else 或保持規則處理。
                            if (opcode[3:0] >= 4'h8) begin
                                // 【教學】bytes 設為 2'd1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_REG（目前 PSW bank 的 R0～R7），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                                bytes = 2'd1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_REG; dst_sel = SEL_ACC;
                            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                            end
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // [規律 12] POP, XCHD 與 SETB 群組 (0xD0, 0xD2, 0xD3, 0xD6, 0xD7)
                // 【教學】條件成立才走後續分支；opcode=原始八位指令操作碼。else if 與先前分支互斥，先命中者優先。
                else if (opcode[7:4] == 4'hD) begin
                    // 【教學】依 opcode[3:0] 選一個分支；先看不規則 opcode，再以高低 nibble 的規律解碼，可減少重複邏輯。
                    case (opcode[3:0])
                        // 【教學】命中 4'h0 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_DIR（直接 byte 地址），讓後級依此控制欄位執行。
                        4'h0: begin bytes = 2'd2; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_DIR; end // POP
                        // 【教學】命中 4'h2 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd2，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；src_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_BIT（位元位址運算元），讓後級依此控制欄位執行。
                        4'h2: begin bytes = 2'd2; ram_wr = 1'b1; src_sel = SEL_BIT; dst_sel = SEL_BIT; end // SETB bit
                        // 【教學】命中 4'h3 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；dst_sel 設為 4'd8，讓後級依此控制欄位執行。
                        4'h3: begin bytes = 2'd1; dst_sel = 4'd8; end // SETB C
                        // 【教學】命中 4'h6, 4'h7 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；ram_rd 設為 1'b1，讓後級依此控制欄位執行；ram_wr 設為 1'b1，讓後級依此控制欄位執行；alu_op 設為 ALU_PASS（直接傳右運算元，不加上目的舊值），讓後級依此控制欄位執行；src_sel 設為 SEL_IND（R0/R1 間接地址），讓後級依此控制欄位執行；dst_sel 設為 SEL_ACC（累加器 A），讓後級依此控制欄位執行。
                        4'h6, 4'h7: begin bytes = 2'd1; ram_rd = 1'b1; ram_wr = 1'b1; alu_op = ALU_PASS; src_sel = SEL_IND; dst_sel = SEL_ACC; end // XCHD
                        // 【教學】命中 default 分支才執行，避免其他 opcode／地址誤用這組控制。bytes 設為 2'd1，讓後級依此控制欄位執行；alu_op 設為 ALU_NOP（保持左運算元），讓後級依此控制欄位執行；src_sel 設為 SEL_NONE（沒有運算元），讓後級依此控制欄位執行；dst_sel 設為 SEL_NONE（沒有運算元），讓後級依此控制欄位執行。
                        default: begin bytes = 2'd1; alu_op = ALU_NOP; src_sel = SEL_NONE; dst_sel = SEL_NONE; end
                    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
                    endcase
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
        endcase
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
