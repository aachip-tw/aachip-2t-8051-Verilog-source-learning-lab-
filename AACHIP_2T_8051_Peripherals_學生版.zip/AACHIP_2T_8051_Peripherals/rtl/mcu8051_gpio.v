// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns / 1ps

// 【教學】模式編碼：00 準雙向、01 推挽、10 輸入、11 開漏。
// M1/M0: 00 quasi, 01 push-pull, 10 input, 11 open-drain.
// 【教學】弱上拉由板子或 Quartus I/O 設定提供，這份 RTL 沒有產生實體電阻。
// Physical weak pull-ups remain controlled by Quartus/board configuration.
// 【教學】宣告可重複使用的硬體模組 mcu8051_gpio，後面列出它對外的腳位；#(...) 的參數可在建立實例時決定硬體配置。EXTENDED 預設 0，設 1 才加入 P1 的 UART1/T2 複用。
module mcu8051_gpio #(parameter EXTENDED=0) (
    // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire       clk,
    // 【教學】input 由外部驅動，模組只讀取。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire       rst_n,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_addr：8-bit SFR 位址，決定讀寫哪個控制暫存器。
    input  wire [7:0] sfr_addr,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sfr_write_data：GPIO 寫入資料。
    input  wire [7:0] sfr_write_data,
    // 【教學】input 由外部驅動，模組只讀取。sfr_write_enable：GPIO 寫入允許。
    input  wire       sfr_write_enable,
    // 【教學】input 由外部驅動，模組只讀取。sfr_rmw：讀改寫讀 latch 的選擇，避免外部電位改掉原輸出資料。
    input  wire       sfr_rmw,
    // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_oe：P0 每位輸出使能，1 驅動、0 釋放；p1_oe：P1 每位輸出使能，1 驅動、0 釋放；p2_oe：P2 每位輸出使能，1 驅動、0 釋放；p3_oe：P3 每位輸出使能，1 驅動、0 釋放。
    output wire [7:0] p0_oe, p1_oe, p2_oe, p3_oe,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_in：P0 實際腳位輸入，與 latch 不同；p1_in：P1 實際腳位輸入，與 latch 不同。
    input  wire [7:0] p0_in, input wire [7:0] p1_in,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p2_in：P2 實際腳位輸入，與 latch 不同；p3_in：P3 實際腳位輸入，與 latch 不同。
    input  wire [7:0] p2_in, input wire [7:0] p3_in,
    // 【教學】input 由外部驅動，模組只讀取。ext_int0_n：獨立 INT0 輸入，未用接 1；ext_int1_n：獨立 INT1 輸入，未用接 1。
    input  wire       ext_int0_n, input wire ext_int1_n,
    // 【教學】input 由外部驅動，模組只讀取。ext_t0：獨立 Counter0 輸入，未用接 1；ext_t1：獨立 Counter1 輸入，未用接 1。
    input  wire       ext_t0, input wire ext_t1,
    // 【教學】input 由外部驅動，模組只讀取；此行混合方向，只有 miso 是外部輸入，sclk/mosi/cs_n 是本模組輸出。uart1_txd：UART1 傳送值，後續接 P1.3；uart1_rxd_out：UART1 Mode0 同步資料輸出；uart1_rxd_oe：UART1 Mode0 輸出使能；t2_output_enable：Timer2 可複用到 P1.0 的允許；t2_out：Timer2 clock-out 方波資料。
    input wire uart1_txd,uart1_rxd_out,uart1_rxd_oe,t2_output_enable,t2_out,
    // 【教學】input 由外部驅動，模組只讀取。serial_txd：UART0 傳送資料供 P3.1 複用。
    input  wire       serial_txd,
    // 【教學】input 由外部驅動，模組只讀取。serial_rxd_out：UART0 Mode0 資料供 P3.0 複用。
    input  wire       serial_rxd_out,
    // 【教學】input 由外部驅動，模組只讀取。serial_rxd_oe：UART0 Mode0 資料輸出允許。
    input  wire       serial_rxd_oe,
    // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_out：P0 送到腳位緩衝的輸出資料；p1_out：P1 送到腳位緩衝的輸出資料。
    output wire [7:0] p0_out, output wire [7:0] p1_out,
    // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p2_out：P2 送到腳位緩衝的輸出資料；p3_out：P3 送到腳位緩衝的輸出資料。
    output wire [7:0] p2_out, output wire [7:0] p3_out,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。port_read_data：GPIO 位址解碼後的讀回值。
    output reg  [7:0] port_read_data,
    // 【教學】output 將內部結果接給外層。int0_n：低有效 INT0 輸入／合併後訊號；int1_n：低有效 INT1 輸入／合併後訊號。
    output wire       int0_n, output wire int1_n,
    // 【教學】output 將內部結果接給外層。t0_pin：Counter0 外部下降沿輸入；t1_pin：Counter1 外部下降沿輸入。
    output wire       t0_pin, output wire t1_pin,
    // 【教學】output 將內部結果接給外層。serial_rxd：由 P3.0 取得的 UART0 接收資料。
    output wire       serial_rxd
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_latch：P0 軟體保存的輸出值；p1_latch：P1 軟體保存的輸出值；p2_latch：P2 軟體保存的輸出值；p3_latch：P3 軟體保存的輸出值。
    reg [7:0] p0_latch,p1_latch,p2_latch,p3_latch;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p0_m1：P0 各位模式的高位；p0_m0：P0 各位模式的低位；p1_m1：P1 各位模式的高位；p1_m0：P1 各位模式的低位；p2_m1：P2 各位模式的高位；p2_m0：P2 各位模式的低位；p3_m1：P3 各位模式的高位；p3_m0：P3 各位模式的低位。
    reg [7:0] p0_m1,p0_m0,p1_m1,p1_m0,p2_m1,p2_m0,p3_m1,p3_m0;
    // 【教學】把外接 INT0 輸入只有明確 0 時才認為低，X/Z 在模擬中預設高；=== 不等於實體電路的上拉或除抖。
    wire ext_i0 = (ext_int0_n === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】把外接 INT1 輸入只有明確 0 時才認為低，X/Z 在模擬中預設高；=== 不等於實體電路的上拉或除抖。
    wire ext_i1 = (ext_int1_n === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】把外接 T0 輸入只有明確 0 時才認為低，X/Z 在模擬中預設高；=== 不等於實體電路的上拉或除抖。
    wire ext_c0 = (ext_t0 === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】把外接 T1 輸入只有明確 0 時才認為低，X/Z 在模擬中預設高；=== 不等於實體電路的上拉或除抖。
    wire ext_c1 = (ext_t1 === 1'b0) ? 1'b0 : 1'b1;
    // 【教學】P0 沒有在此處插入週邊輸出多工器，直接把軟體保存的 latch 送到輸出資料線；OE 另行決定是否驅動。
    assign p0_out=p0_latch;
    // 【教學】串接 P1 八個位元：高四位維持 GPIO，P1.3 可切入 UART1 TXD；與 latch 做 AND 表示 latch 必須為 1 才放行 UART。
    assign p1_out={p1_latch[7:4],p1_latch[3]&(EXTENDED?uart1_txd:1'b1),
      // 【教學】接續 P1 串接：P1.2 只在擴充 UART1 Mode0 要輸出時送資料，否則不改 latch；P1.1 保持 GPIO 輸出值。
      p1_latch[2]&((EXTENDED&&uart1_rxd_oe)?uart1_rxd_out:1'b1),p1_latch[1],
      // 【教學】P1.0 在 Timer2 clock-out 啟用時換成 t2_out，其他時候仍取 latch；結束八位串接，OE 仍由 GPIO 模式決定。
      (EXTENDED&&t2_output_enable)?t2_out:p1_latch[0]};
    // 【教學】P2 沒有在此處插入週邊輸出多工器，直接把軟體保存的 latch 送到輸出資料線；OE 另行決定是否驅動。
    assign p2_out=p2_latch;
    // 【教學】P3 高六位維持 latch，P3.1 與 UART0 TXD 做 AND；保持 8051 latch=0 可拉低腳位的控制方式。
    assign p3_out={p3_latch[7:2],p3_latch[1]&serial_txd,
                   // 【教學】P3.0 在 UART Mode0 輸出同步資料，其餘時候用 1 作 AND 的中性值，不影響原 GPIO latch。
                   p3_latch[0]&(serial_rxd_oe ? serial_rxd_out : 1'b1)};
    // 【教學】逐位算 P0 的輸出使能：M1/M0=01 推挽一直驅動，10 輸入一直釋放，00/11 只在資料為 0 時拉低。~ & | 都是逐位運算；真正三態需在 FPGA I/O 頂層實作。
    assign p0_oe = (~p0_m1 & p0_m0) | (~p0_out & ~(p0_m1 & ~p0_m0));
    // 【教學】逐位算 P1 的輸出使能：M1/M0=01 推挽一直驅動，10 輸入一直釋放，00/11 只在資料為 0 時拉低。~ & | 都是逐位運算；真正三態需在 FPGA I/O 頂層實作。
    assign p1_oe = (~p1_m1 & p1_m0) | (~p1_out & ~(p1_m1 & ~p1_m0));
    // 【教學】逐位算 P2 的輸出使能：M1/M0=01 推挽一直驅動，10 輸入一直釋放，00/11 只在資料為 0 時拉低。~ & | 都是逐位運算；真正三態需在 FPGA I/O 頂層實作。
    assign p2_oe = (~p2_m1 & p2_m0) | (~p2_out & ~(p2_m1 & ~p2_m0));
    // 【教學】逐位算 P3 的輸出使能：M1/M0=01 推挽一直驅動，10 輸入一直釋放，00/11 只在資料為 0 時拉低。~ & | 都是逐位運算；真正三態需在 FPGA I/O 頂層實作。
    assign p3_oe = (~p3_m1 & p3_m0) | (~p3_out & ~(p3_m1 & ~p3_m0));
    // 【教學】INT0 的獨立輸入與 P3.2 做 AND，任一為低就有效；未用獨立輸入時要接 1，避免永久觸發。
    assign int0_n=ext_i0 & p3_in[2];
    // 【教學】INT1 合併外接輸入與 P3.3，兩者都高才解除低有效中斷。
    assign int1_n=ext_i1 & p3_in[3];
    // 【教學】T0 計數腳合併獨立輸入與 P3.4；本線交給 Timer0 做下降沿偵測。
    assign t0_pin=ext_c0 & p3_in[4];
    // 【教學】T1 計數腳合併獨立輸入與 P3.5；未用的一路接 1 才不會遮住另一條。
    assign t1_pin=ext_c1 & p3_in[5];
    // 【教學】UART0 接收取實際 P3.0 輸入，不能取輸出 latch，因為 UART 必須讀外部傳入資料。
    assign serial_rxd=p3_in[0];
    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
      // 【教學】低有效重置把四個 port latch 設為 FF；在準雙向模式下輸出 1 代表釋放，讓外部可驅動輸入。
      if(!rst_n) begin p0_latch<=8'hff;p1_latch<=8'hff;p2_latch<=8'hff;p3_latch<=8'hff;
        // 【教學】P0 的 M1/M0 全清 0，讓八個腳位重置後都採準雙向模式，避免一上電就強制推挽驅動。
        p0_m1<=0; p0_m0<=0;
        // 【教學】P1 的 M1/M0 全清 0，讓八個腳位重置後都採準雙向模式，避免一上電就強制推挽驅動。
        p1_m1<=0; p1_m0<=0;
        // 【教學】P2 的 M1/M0 全清 0，讓八個腳位重置後都採準雙向模式，避免一上電就強制推挽驅動。
        p2_m1<=0; p2_m0<=0;
        // 【教學】P3 的 M1/M0 全清 0，讓八個腳位重置後都採準雙向模式，避免一上電就強制推挽驅動。
        p3_m1<=0; p3_m0<=0;
      // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
      end
      // 【教學】非重置且寫入允許才解碼位址；沒有命中的 case 時暫存器保持，形成有 enable 的正反器而不是組合 latch。
      else if(sfr_write_enable) case(sfr_addr)
        // 【教學】8'h80 寫入 p0_latch（P0 軟體保存的輸出值），資料取 sfr_write_data；8'h90 寫入 p1_latch（P1 軟體保存的輸出值），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'h80:p0_latch<=sfr_write_data; 8'h90:p1_latch<=sfr_write_data;
        // 【教學】8'ha0 寫入 p2_latch（P2 軟體保存的輸出值），資料取 sfr_write_data；8'hb0 寫入 p3_latch（P3 軟體保存的輸出值），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'ha0:p2_latch<=sfr_write_data; 8'hb0:p3_latch<=sfr_write_data;
        // 【教學】8'he1 寫入 p0_m1（P0 各位模式的高位），資料取 sfr_write_data；8'he2 寫入 p0_m0（P0 各位模式的低位），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'he1:p0_m1<=sfr_write_data; 8'he2:p0_m0<=sfr_write_data;
        // 【教學】8'he3 寫入 p1_m1（P1 各位模式的高位），資料取 sfr_write_data；8'he4 寫入 p1_m0（P1 各位模式的低位），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'he3:p1_m1<=sfr_write_data; 8'he4:p1_m0<=sfr_write_data;
        // 【教學】8'he5 寫入 p2_m1（P2 各位模式的高位），資料取 sfr_write_data；8'he6 寫入 p2_m0（P2 各位模式的低位），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'he5:p2_m1<=sfr_write_data; 8'he6:p2_m0<=sfr_write_data;
        // 【教學】8'hf1 寫入 p3_m1（P3 各位模式的高位），資料取 sfr_write_data；8'hf2 寫入 p3_m0（P3 各位模式的低位），資料取 sfr_write_data。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
        8'hf1:p3_m1<=sfr_write_data; 8'hf2:p3_m0<=sfr_write_data;
      // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
      endcase
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。此行同時開始依位址選讀值。
    always @(*) case(sfr_addr)
      // 【教學】8'h80 → sfr_rmw?p0_latch:p0_in：RMW 選輸出 latch，一般讀選實際 pin，避免外部拉低改寫原本輸出值。此處 = 是組合阻塞指派。
      8'h80:port_read_data=sfr_rmw?p0_latch:p0_in;
      // 【教學】8'h90 → sfr_rmw?p1_latch:p1_in：RMW 選輸出 latch，一般讀選實際 pin，避免外部拉低改寫原本輸出值。此處 = 是組合阻塞指派。
      8'h90:port_read_data=sfr_rmw?p1_latch:p1_in;
      // 【教學】8'ha0 → sfr_rmw?p2_latch:p2_in：RMW 選輸出 latch，一般讀選實際 pin，避免外部拉低改寫原本輸出值。此處 = 是組合阻塞指派。
      8'ha0:port_read_data=sfr_rmw?p2_latch:p2_in;
      // 【教學】8'hb0 → sfr_rmw?p3_latch:p3_in：RMW 選輸出 latch，一般讀選實際 pin，避免外部拉低改寫原本輸出值。此處 = 是組合阻塞指派。
      8'hb0:port_read_data=sfr_rmw?p3_latch:p3_in;
      // 【教學】8'he1 → p0_m1：讀回 P0 各位模式的高位；讀取只經組合多工器，不更改其儲存值；8'he2 → p0_m0：讀回 P0 各位模式的低位；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
      8'he1:port_read_data=p0_m1; 8'he2:port_read_data=p0_m0;
      // 【教學】8'he3 → p1_m1：讀回 P1 各位模式的高位；讀取只經組合多工器，不更改其儲存值；8'he4 → p1_m0：讀回 P1 各位模式的低位；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
      8'he3:port_read_data=p1_m1; 8'he4:port_read_data=p1_m0;
      // 【教學】8'he5 → p2_m1：讀回 P2 各位模式的高位；讀取只經組合多工器，不更改其儲存值；8'he6 → p2_m0：讀回 P2 各位模式的低位；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
      8'he5:port_read_data=p2_m1; 8'he6:port_read_data=p2_m0;
      // 【教學】8'hf1 → p3_m1：讀回 P3 各位模式的高位；讀取只經組合多工器，不更改其儲存值；8'hf2 → p3_m0：讀回 P3 各位模式的低位；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
      8'hf1:port_read_data=p3_m1; 8'hf2:port_read_data=p3_m0;
      // 【教學】default → 8'hff：未實作位址回傳固定值，確保組合邏輯每條路都有結果，避免 latch。此處 = 是組合阻塞指派。
      default:port_read_data=8'hff;
    // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
    endcase
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
