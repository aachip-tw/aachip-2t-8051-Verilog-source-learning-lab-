// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns / 1ps

// 【教學】序列埠模式 1/2/3 使用含 start/stop 的非同步資料框。
// 8051 serial port.  Modes 1/2/3 implement framed UART transfer.  Mode 0
// 【教學】模式 0 是八位同步移位，TXD 輸出時鐘。
// implements an 8-bit synchronous shift using TXD as the shift clock.
// 【教學】宣告可重複使用的硬體模組 mcu8051_serial，後面列出它對外的腳位；#(...) 的參數可在建立實例時決定硬體配置。
module mcu8051_serial #(
    // 【教學】可覆寫的整數參數 SEPARATE_BAUD：是否啟用 RX/TX 分開的鮑率來源，參數在 elaboration 決定硬體配置；不是軟體運行中可寫的暫存器。
    parameter integer SEPARATE_BAUD = 0,
    // 【教學】可覆寫的整數參數 VARIABLE_BAUD_DIV：一般可變鮑率分頻；用 Timer2 時其衍生位寬必須容納 0～15；不是軟體運行中可寫的暫存器。
    parameter integer VARIABLE_BAUD_DIV = 32,
    // 【教學】可覆寫的整數參數 MODE2_BAUD_DIV：Mode2 固定鮑率分頻，SMOD=1 再減半；不是軟體運行中可寫的暫存器。
    parameter integer MODE2_BAUD_DIV = 64,
    // 【教學】可覆寫的整數參數 MODE0_BAUD_DIV：Mode0 半週期分頻；兩個事件才移一個 bit；不是軟體運行中可寫的暫存器。
    parameter integer MODE0_BAUD_DIV = 1
// 【教學】結束參數清單並開始對外埠清單；參數決定配置，埠是運作時的訊號。
) (
    // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯。
    input  wire       clk,
    // 【教學】input 由外部驅動，模組只讀取。rst_n：低有效非同步重置，_n 表示 0 有效。
    input  wire       rst_n,
    // 【教學】input 由外部驅動，模組只讀取。clock_enable：UART 的狀態推進允許。
    input  wire       clock_enable,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。scon：UART 模式、REN、SM2、TB8 和 RI/TI/RB8。
    input  wire [7:0] scon,
    // 【教學】input 由外部驅動，模組只讀取。smod：鮑率倍增選擇，藉分頻減半達成。
    input  wire       smod,
    // 【教學】input 由外部驅動，模組只讀取。timer1_overflow：Timer1 的單拍溢位，作 UART 鮑率來源。
    input  wire       timer1_overflow,
    // 【教學】input 由外部驅動，模組只讀取。rx_baud_overflow：RX 可獨立選擇的鮑率來源脈波；tx_baud_overflow：TX 可獨立選擇的鮑率來源脈波。
    input wire rx_baud_overflow,tx_baud_overflow,
    // 【教學】input 由外部驅動，模組只讀取。rx_use_timer2：RX 選 Timer2 時改用固定除 16；tx_use_timer2：TX 選 Timer2 時改用固定除 16。
    input wire rx_use_timer2,tx_use_timer2,
    // 【教學】input 由外部驅動，模組只讀取。rxd：串列接收輸入；Mode0 也是同步取樣資料。
    input  wire       rxd,
    // 【教學】input 由外部驅動，模組只讀取。sbuf_write：送出一筆 byte 的請求，busy 時會忽略。
    input  wire       sbuf_write,
    // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sbuf_write_data：要送出的 byte。
    input  wire [7:0] sbuf_write_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sbuf_read_data：最近收到的 byte，無 FIFO。
    output reg  [7:0] sbuf_read_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。txd：串列 TX 輸出，Mode0 改作同步移位時鐘。
    output reg        txd,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rxd_out：Mode0 從 RXD 腳送出的資料。
    output reg        rxd_out,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rxd_output_enable：Mode0 允許 RXD 腳輸出資料。
    output reg        rxd_output_enable,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。ri_set：要求外部 SCON 設 RI 的事件。
    output reg        ri_set,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。ti_set：要求外部 SCON 設 TI 的事件。
    output reg        ti_set,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rb8_write：RB8 資料有效更新事件。
    output reg        rb8_write,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rb8_data：接收第九位或 Mode1 的停止位。
    output reg        rb8_data,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。tx_busy：正在傳送，阻止新資料覆蓋 frame。
    output reg        tx_busy,
    // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rx_busy：正在接收 frame。
    output reg        rx_busy
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
    // 【教學】以 $clog2 向上取 log2 計算分頻器所需位寬，至少保留 1 位避免零位寬；localparam 在建構電路時決定，不會每拍重新運算。
    localparam integer VAR_W = (VARIABLE_BAUD_DIV <= 1) ? 1 : $clog2(VARIABLE_BAUD_DIV);
    // 【教學】以 $clog2 向上取 log2 計算分頻器所需位寬，至少保留 1 位避免零位寬；localparam 在建構電路時決定，不會每拍重新運算。
    localparam integer FIX_W = (MODE2_BAUD_DIV <= 1) ? 1 : $clog2(MODE2_BAUD_DIV);
    // 【教學】以 $clog2 向上取 log2 計算分頻器所需位寬，至少保留 1 位避免零位寬；localparam 在建構電路時決定，不會每拍重新運算。
    localparam integer M0_W = (MODE0_BAUD_DIV <= 1) ? 1 : $clog2(MODE0_BAUD_DIV);
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[VAR_W-1:0] 指定向量位元範圍，例如 [7:0] 共 8 位。variable_count：RX timer 溢位的分頻計數；tx_variable_count：TX timer 溢位的獨立分頻計數。
    reg [VAR_W-1:0] variable_count,tx_variable_count;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[FIX_W-1:0] 指定向量位元範圍，例如 [7:0] 共 8 位。fixed_count：Mode2 固定鮑率的時鐘計數。
    reg [FIX_W-1:0] fixed_count;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[M0_W-1:0] 指定向量位元範圍，例如 [7:0] 共 8 位。mode0_count：同步 Mode0 的半週期計數。
    reg [M0_W-1:0] mode0_count;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[10:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tx_shift：11-bit 傳送移位暫存器，容納最長 frame。
    reg [10:0] tx_shift;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tx_remaining：尚待完成的 frame 位數。
    reg [3:0] tx_remaining;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。rx_shift：八位接收資料的暫存。
    reg [7:0] rx_shift;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[3:0] 指定向量位元範圍，例如 [7:0] 共 8 位。rx_index：下一個接收位的位置。
    reg [3:0] rx_index;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。rx_ninth：暫存第九資料位。
    reg rx_ninth;
    // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。mode0_phase：Mode0 的兩個半週期相位。
    reg mode0_phase;
    // 【教學】抽出 SCON 的 SM0/SM1 兩個模式位；位元切片不產生暫存器，只是取出兩條訊號線。
    wire [1:0] mode = scon[7:6];
    // 【教學】SMOD=1 時將可變鮑率分頻數減半，並把下限限制為 1，避免除數變成 0；此 ?: 運算接到下一行。
    wire [31:0] variable_limit = smod ? ((VARIABLE_BAUD_DIV/2) < 1 ? 1 : VARIABLE_BAUD_DIV/2) :
                                             // 【教學】接續上一行 SMOD=0 的分支：保留原分頻數，但最小仍為 1；以 limit 作比較終值。
                                             (VARIABLE_BAUD_DIV < 1 ? 1 : VARIABLE_BAUD_DIV);
    // 【教學】Mode2 用固定時鐘分頻；SMOD=1 將分頻減半使鮑率倍增，並防止 0 分頻。
    wire [31:0] fixed_limit = smod ? ((MODE2_BAUD_DIV/2) < 1 ? 1 : MODE2_BAUD_DIV/2) :
                                          // 【教學】固定鮑率在 SMOD=0 時採原參數，最小 1；本行結束跨行的三元選擇式。
                                          (MODE2_BAUD_DIV < 1 ? 1 : MODE2_BAUD_DIV);
    // 【教學】參數允許分開鮑率時改用外部指定的 RX 溢位來源，否則相容舊介面，固定取 Timer1。
    wire rx_source=SEPARATE_BAUD ? rx_baud_overflow : timer1_overflow;
    // 【教學】TX 另選自己的溢位來源，才能讓 UART0 接收及傳送使用不同 timer。
    wire tx_source=SEPARATE_BAUD ? tx_baud_overflow : timer1_overflow;
    // 【教學】接收選 Timer2 時固定每 16 個溢位產生一個 bit tick；其他情況使用可由 SMOD 調整的 variable_limit。
    wire [31:0] rx_limit=(SEPARATE_BAUD && rx_use_timer2)?16:variable_limit;
    // 【教學】傳送與接收各算自己的分頻限制，避免一方選 Timer2 連帶改變另一方。
    wire [31:0] tx_limit=(SEPARATE_BAUD && tx_use_timer2)?16:variable_limit;
    // 【教學】RX 分頻計數從 0 開始，數到 limit-1 且本拍有來源事件才發 tick，總共恰為 limit 次事件。
    wire variable_baud_tick = rx_source && (variable_count == rx_limit-1);
    // 【教學】TX 使用獨立分頻計數器，在第 tx_limit 個來源事件發 tick，支援 TX/RX 不同速率。
    wire tx_variable_baud_tick = tx_source && (tx_variable_count == tx_limit-1);
    // 【教學】Mode2 每個允許時鐘都計數；舊值到 limit-1 時發出一次固定鮑率 tick。
    wire fixed_baud_tick = (fixed_count == fixed_limit-1);
    // 【教學】Mode0 的相位事件由自己的分頻器產生；兩次相位事件組成一個完整移位時鐘。
    wire mode0_baud_tick = (mode0_count == MODE0_BAUD_DIV-1);
    // 【教學】接收在 Mode2 選固定鮑率，其餘非同步 UART 模式選 RX 可變鮑率；這不是額外產生一棵時鐘。
    wire uart_baud_tick = (mode == 2'b10) ? fixed_baud_tick : variable_baud_tick;

    // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
    always @(posedge clk or negedge rst_n) begin
        // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
        if (!rst_n) begin
            // 【教學】variable_count（RX timer 溢位的分頻計數）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            variable_count <= 0;
            // 【教學】tx_variable_count（TX timer 溢位的獨立分頻計數）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tx_variable_count <= 0;
            // 【教學】fixed_count（Mode2 固定鮑率的時鐘計數）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            fixed_count <= 0;
            // 【教學】mode0_count（同步 Mode0 的半週期計數）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            mode0_count <= 0;
            // 【教學】sbuf_read_data（最近收到的 byte，無 FIFO）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            sbuf_read_data <= 0;
            // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
            txd <= 1'b1;
            // 【教學】rxd_out（Mode0 從 RXD 腳送出的資料）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。重置設 1 使同步資料輸出先處於高；是否實際驅動仍看輸出使能。
            rxd_out <= 1'b1;
            // 【教學】rxd_output_enable（Mode0 允許 RXD 腳輸出資料）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 表示 Mode0 正送資料而可驅動 RXD，0 則釋放；重置時必須釋放，避免干擾接收。
            rxd_output_enable <= 1'b0;
            // 【教學】ri_set（要求外部 SCON 設 RI 的事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 代表本拍接收完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 RI。
            ri_set <= 1'b0;
            // 【教學】ti_set（要求外部 SCON 設 TI 的事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 代表本拍傳送完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 TI。
            ti_set <= 1'b0;
            // 【教學】rb8_write（RB8 資料有效更新事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 告知外部 RB8 資料有效，0 是重置或正常每拍清事件，避免重複更新。
            rb8_write <= 1'b0;
            // 【教學】rb8_data（接收第九位或 Mode1 的停止位）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            rb8_data <= 1'b0;
            // 【教學】tx_busy（正在傳送，阻止新資料覆蓋 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 鎖住傳送器直到整個 frame 完成，0 則允許下一筆 SBUF 寫入。
            tx_busy <= 1'b0;
            // 【教學】rx_busy（正在接收 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 開始一個 frame 的接收，0 回到等待起始位；不表示有接收 FIFO。
            rx_busy <= 1'b0;
            // 【教學】tx_shift（11-bit 傳送移位暫存器，容納最長 frame）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tx_shift <= 0;
            // 【教學】tx_remaining（尚待完成的 frame 位數）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            tx_remaining <= 0;
            // 【教學】rx_shift（八位接收資料的暫存）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            rx_shift <= 0;
            // 【教學】rx_index（下一個接收位的位置）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            rx_index <= 0;
            // 【教學】rx_ninth（暫存第九資料位）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            rx_ninth <= 0;
            // 【教學】mode0_phase（Mode0 的兩個半週期相位）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
            mode0_phase <= 0;
        // 【教學】結束重置；僅在 clock_enable=1 時推進 UART。為 0 時所有暫存器保持，連 ri_set/ti_set 也保持，不能當作自動清脈波。
        end else if (clock_enable) begin
            // 【教學】ri_set（要求外部 SCON 設 RI 的事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 代表本拍接收完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 RI。
            ri_set <= 1'b0;
            // 【教學】ti_set（要求外部 SCON 設 TI 的事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 代表本拍傳送完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 TI。
            ti_set <= 1'b0;
            // 【教學】rb8_write（RB8 資料有效更新事件）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 告知外部 RB8 資料有效，0 是重置或正常每拍清事件，避免重複更新。
            rb8_write <= 1'b0;

            // 【教學】只在接收來源 timer 溢位時推進 RX 分頻，而非每拍 clk 都增加。
            if (rx_source) begin
                // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
                if (variable_baud_tick) variable_count <= 0;
                // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
                else variable_count <= variable_count + 1'b1;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】TX 使用自己的來源使能，與 RX 的分頻計數互不混用。
            if(tx_source) begin
                // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
                if(tx_variable_baud_tick) tx_variable_count<=0;
                // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
                else tx_variable_count<=tx_variable_count+1'b1;
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
            // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
            if (fixed_baud_tick) fixed_count <= 0;
            // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
            else fixed_count <= fixed_count + 1'b1;
            // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
            if (mode0_baud_tick) mode0_count <= 0;
            // 【教學】對應分頻 tick 到點就把計數器清 0，否則加 1；計數從 0 到 limit-1，所以剛好每滿設定次數才推進一次 UART bit／相位。此行的 <= 用舊計數計算。
            else mode0_count <= mode0_count + 1'b1;

            // 【教學】只有寫 SBUF 且傳送閒置才接受資料；忙碌時寫入會被忽略，沒有傳送 FIFO。
            if (sbuf_write && !tx_busy) begin
                // 【教學】tx_busy（正在傳送，阻止新資料覆蓋 frame）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 鎖住傳送器直到整個 frame 完成，0 則允許下一筆 SBUF 寫入。
                tx_busy <= 1'b1;
                // 【教學】Mode0 使用同步移位，TXD 是時鐘、RXD 是資料線，必須與非同步 start/stop 傳送分開。
                if (mode == 2'b00) begin
                    // 【教學】Mode0 只送 8 個資料位，11-bit 暫存器高三位補 0；最低位先送，配合後續右移。
                    tx_shift <= {3'b0, sbuf_write_data};
                    // 【教學】Mode0 記下還要傳 8 個資料位；這是倒數計數器，不是資料本身。
                    tx_remaining <= 8;
                    // 【教學】rxd_output_enable（Mode0 允許 RXD 腳輸出資料）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 表示 Mode0 正送資料而可驅動 RXD，0 則釋放；重置時必須釋放，避免干擾接收。
                    rxd_output_enable <= 1'b1;
                    // 【教學】Mode0 先把資料 bit0 放上 RXD 資料輸出，使第一次取樣前資料已準備。
                    rxd_out <= sbuf_write_data[0];
                    // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
                    txd <= 1'b0;
                    // 【教學】mode0_phase（Mode0 的兩個半週期相位）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
                    mode0_phase <= 1'b0;
                // 【教學】Mode1 使用 8 個資料位及起始／停止位，準備 10-bit frame。
                end else if (mode == 2'b01) begin
                    // 【教學】由高到低拼接補位、停止位 1、8-bit 資料、起始位 0；右移讓起始位與資料最低位最先送出。
                    tx_shift <= {1'b0, 1'b1, sbuf_write_data, 1'b0};
                    // 【教學】Mode1 的 start+8 data+stop 共 10 位，倒數到最後一位才能結束傳送。
                    tx_remaining <= 10;
                    // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
                    txd <= 1'b0;
                // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
                end else begin
                    // 【教學】Mode2/3 在 8-bit 資料外增加 TB8=SCON[3]，再加 start/stop，正好構成 11 位。
                    tx_shift <= {1'b1, scon[3], sbuf_write_data, 1'b0};
                    // 【教學】Mode2/3 多一個第九資料位，因此共 11 位。
                    tx_remaining <= 11;
                    // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
                    txd <= 1'b0;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end

            // 【教學】Mode0 使用同步移位，TXD 是時鐘、RXD 是資料線，必須與非同步 start/stop 傳送分開。
            if (mode == 2'b00) begin
                // 【教學】同步模式需要兩個分頻事件形成完整移位時鐘，避免每半週期都移一位。
                // Two divider events form one shift clock in synchronous mode.
                // 【教學】同步移位只在正在傳送且相位 tick 到來時切換時鐘，閒置時不應持續翻轉 TXD。
                if (tx_busy && mode0_baud_tick) begin
                    // 【教學】逐位反相這個單 bit 相位，區別一個完整時鐘內的兩個半週期。
                    mode0_phase <= ~mode0_phase;
                    // 【教學】Mode0 將 TXD 翻轉一次，作為外部同步移位時鐘；每兩次翻轉才是一個 bit 週期。
                    txd <= ~txd;
                    // 【教學】用更新前的相位決定是否真正移動資料；如此兩個相位 tick 只移一個資料位。
                    if (mode0_phase) begin
                        // 【教學】右移一位丟棄已送出的最低位，讓下一位成為新的 bit0；>> 為邏輯右移，高位補 0。
                        tx_shift <= tx_shift >> 1;
                        // 【教學】Mode0 把當前 RXD 放進最高位，同時其餘位右移；連續 8 次後組成收到的 byte。
                        rx_shift <= {rxd,rx_shift[7:1]};
                        // 【教學】舊的剩餘位數為 1 表示本次已處理最後一位，接著釋放 busy 並通知完成。
                        if (tx_remaining == 1) begin
                            // 【教學】tx_busy（正在傳送，阻止新資料覆蓋 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 鎖住傳送器直到整個 frame 完成，0 則允許下一筆 SBUF 寫入。
                            tx_busy <= 1'b0;
                            // 【教學】rx_busy（正在接收 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 開始一個 frame 的接收，0 回到等待起始位；不表示有接收 FIFO。
                            rx_busy <= 1'b0;
                            // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
                            txd <= 1'b1;
                            // 【教學】rxd_output_enable（Mode0 允許 RXD 腳輸出資料）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 表示 Mode0 正送資料而可驅動 RXD，0 則釋放；重置時必須釋放，避免干擾接收。
                            rxd_output_enable <= 1'b0;
                            // 【教學】把本拍剛採到的 RXD 一起拼入結果；不能直接取 rx_shift，因為其 <= 新值尚未提交，會漏最後一位。
                            sbuf_read_data <= {rxd,rx_shift[7:1]};
                            // 【教學】ti_set（要求外部 SCON 設 TI 的事件）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 代表本拍傳送完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 TI。
                            ti_set <= 1'b1;
                            // 【教學】ri_set（要求外部 SCON 設 RI 的事件）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 代表本拍接收完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 RI。
                            ri_set <= 1'b1;
                        // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
                        end else begin
                            // 【教學】完成一位後把剩餘位數減一；與資料右移同步進行，使計數和 frame 對齊。
                            tx_remaining <= tx_remaining - 1'b1;
                            // 【教學】本拍右移之前的 bit1，就是右移之後的 bit0；直接取舊 bit1 可避免非阻塞更新晚一拍。
                            rxd_out <= tx_shift[1];
                        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                        end
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
            end else begin
                // 【教學】Mode2 用固定 TX tick，Mode1/3 用可變 TX tick；且必須 busy 才能推進 frame。
                if (((mode==2'b10)?fixed_baud_tick:tx_variable_baud_tick) && tx_busy) begin
                    // 【教學】舊的剩餘位數為 1 表示本次已處理最後一位，接著釋放 busy 並通知完成。
                    if (tx_remaining == 1) begin
                        // 【教學】tx_busy（正在傳送，阻止新資料覆蓋 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 鎖住傳送器直到整個 frame 完成，0 則允許下一筆 SBUF 寫入。
                        tx_busy <= 1'b0;
                        // 【教學】txd（串列 TX 輸出，Mode0 改作同步移位時鐘）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。設 1 是 UART 閒置／停止位（Mode0 也用於恢復閒置），設 0 是起始位或同步時鐘初相位；要依所在 reset/start/finish 分支判讀。
                        txd <= 1'b1;
                        // 【教學】ti_set（要求外部 SCON 設 TI 的事件）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 代表本拍傳送完成通知，0 用於重置或每拍預設清事件；外部 SCON 再保存成 TI。
                        ti_set <= 1'b1;
                    // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
                    end else begin
                        // 【教學】右移一位丟棄已送出的最低位，讓下一位成為新的 bit0；>> 為邏輯右移，高位補 0。
                        tx_shift <= tx_shift >> 1;
                        // 【教學】完成一位後把剩餘位數減一；與資料右移同步進行，使計數和 frame 對齊。
                        tx_remaining <= tx_remaining - 1'b1;
                        // 【教學】把下一個要送的位元取自移位前 bit1，配合本拍右移，避免重送舊 bit0。
                        txd <= tx_shift[1];
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end

                // 【教學】接收動作只在一個 bit 的取樣時刻發生；此版是單次取樣，並沒有 16 倍過取樣或半位元中心校準。
                if (uart_baud_tick) begin
                // 【教學】還沒接收 frame 時只監看起始位，不要把閒置高電位當資料存入。
                if (!rx_busy) begin
                    // 【教學】REN=SCON[4] 允許接收且 RXD 為低時辨認起始位；未實作額外的起始位抗毛刺確認。
                    if (scon[4] && !rxd) begin
                        // 【教學】rx_busy（正在接收 frame）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 開始一個 frame 的接收，0 回到等待起始位；不表示有接收 FIFO。
                        rx_busy <= 1'b1;
                        // 【教學】rx_index（下一個接收位的位置）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
                        rx_index <= 0;
                        // 【教學】rx_shift（八位接收資料的暫存）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
                        rx_shift <= 0;
                        // 【教學】rx_ninth（暫存第九資料位）寫入 0，使用 <= 讓更新在時序事件結束提交。此處清零／設初值讓後續計數、位索引或控制狀態從確定值開始；沒有此初值時模擬可能傳播 X。
                        rx_ninth <= 0;
                    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                    end
                // 【教學】已進入接收時先收 data bit0～bit7，共八位，再分流到第九位或停止位。
                end else if (rx_index < 8) begin
                    // 【教學】以可變索引把本拍 RXD 存入對應資料位，實作 LSB-first 接收。
                    rx_shift[rx_index] <= rxd;
                    // 【教學】記下下一個要取樣的位元位置，讓八次取樣分別落在 bit0～bit7。
                    rx_index <= rx_index + 1'b1;
                // 【教學】Mode2/3 在八個資料位之後還有第九位；Mode1 沒有它，因此直接進停止位處理。
                end else if (mode != 2'b01 && rx_index == 8) begin
                    // 【教學】把第九資料位獨立保存，以便接收結束後寫 RB8 並套用 SM2 篩選。
                    rx_ninth <= rxd;
                    // 【教學】第九位已取樣，將索引移到 9，讓下一個 tick 進入停止／完成分支。
                    rx_index <= 9;
                // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
                end else begin
                    // 【教學】rx_busy（正在接收 frame）寫入 1'b0，使用 <= 讓更新在時序事件結束提交。1 開始一個 frame 的接收，0 回到等待起始位；不表示有接收 FIFO。
                    rx_busy <= 1'b0;
                    // 【教學】完整八位資料接收完成，更新軟體可讀的 SBUF；沒有 FIFO，後來的 frame 會覆蓋此值。
                    sbuf_read_data <= rx_shift;
                    // 【教學】rb8_write（RB8 資料有效更新事件）寫入 1'b1，使用 <= 讓更新在時序事件結束提交。1 告知外部 RB8 資料有效，0 是重置或正常每拍清事件，避免重複更新。
                    rb8_write <= 1'b1;
                    // 【教學】Mode1 的 RB8 記停止位，Mode2/3 記第九資料位，透過多工器選正確來源。
                    rb8_data <= (mode == 2'b01) ? rxd : rx_ninth;
                    // 【教學】SM2=0 一律通知接收；SM2=1 則只在停止位／第九位為 1 時設 RI，實作多機通訊的接收條件。
                    if (!scon[5] || ((mode == 2'b01) ? rxd : rx_ninth)) ri_set <= 1'b1;
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
                // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
                end
            // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
            end
        // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
        end
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
