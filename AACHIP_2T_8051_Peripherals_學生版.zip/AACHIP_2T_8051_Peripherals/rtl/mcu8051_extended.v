// Copyright (c) 2026 AACHIP Technology Co., Ltd., Taiwan.
// All rights reserved.
// 僅供 AACHIP Technology Co., Ltd. 內部員工學習與訓練使用。
// 未經本公司事先書面許可，不得對外散布、公開發布或提供予第三方。
// Internal employee education and training only.

// 【學生閱讀】每一個原始非空程式行前均附「教學」說明；空白行僅分段。
// 【學生閱讀】wire 是連線；reg 是程序可指派變數，是否儲存取決於 always 類型。
// 【學生閱讀】時序用 <= 讀舊值、同拍提交；組合用 = 並覆蓋全部路徑以避免 latch。
// 【學生閱讀】以下維持原始程式 token；保留的原註解若有簡化敘述，以教學補充為準。
// 【教學】模擬時間單位為 1ns、精度為 1ps，例如 #5 是 5ns；只控制模擬延遲的解讀，不設定 FPGA 實際時鐘頻率。
`timescale 1ns/1ps
// 【教學】這組擴充周邊原本由不同 T 週期版本共用。
// Extended peripherals shared by the 1T, 2T and 12T implementations.
// 【教學】模組內以 clk 加使能推進狀態，不將計數邏輯輸出當作新 clock。
// No generated clocks: all state advances on clk with explicit enables.
// 【教學】宣告可重複使用的硬體模組 mcu8051_extended，後面列出它對外的腳位。
module mcu8051_extended (
 // 【教學】input 由外部驅動，模組只讀取。clk：共同時鐘，上升沿更新時序邏輯；rst_n：低有效非同步重置，_n 表示 0 有效；run_enable：周邊運作使能；並非所有模組的總暫停開關；timer_tick：計時器的一次計數使能，不是另一個 clock。
 input wire clk,rst_n,run_enable,timer_tick,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。addr：本次 SFR byte 位址；wdata：本次寫入的 8-bit 資料。
 input wire [7:0] addr,wdata,
 // 【教學】input 由外部驅動，模組只讀取。wr：本拍寫入有效。
 input wire wr,
 // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。rdata：擴充 SFR 的組合讀回值。
 output reg [7:0] rdata,
 // 【教學】output 將內部結果接給外層。selected：位址是否由 extended 模組負責。
 output wire selected,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。p1：P1 實際腳位取樣，供 T2/UART1/擴充中斷使用。
 input wire [7:0] p1,
 // 【教學】input 由外部驅動，模組只讀取。timer1_overflow：Timer1 的單拍溢位，作 UART 鮑率來源。
 input wire timer1_overflow,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ie：基本中斷允許，bit7 是全域 EA；extended 內的同名輸入未使用。
 input wire [7:0] ie,
 // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ckcon：時鐘與原 CPU 等待控制；spc_fnc：原系統特殊功能控制，獨立套件只保留暫存器；mpage：原 CPU MOVX 分頁值，獨立套件不操作記憶體；eie：擴充中斷允許／優先權；exif：擴充外部中斷事件旗標；eicon：擴充控制與事件位，bit7 也作 UART1 SMOD。
 output reg [7:0] ckcon,spc_fnc,mpage,eie,exif,eicon,
 // 【教學】output 將內部結果接給外層。timer2_irq：Timer2 TF2 或 EXF2 請求；serial1_irq：UART1 RI 或 TI 請求。
 output wire timer2_irq,serial1_irq,
 // 【教學】output 將內部結果接給外層。uart1_txd：UART1 傳送值，後續接 P1.3；uart1_rxd_out：UART1 Mode0 同步資料輸出；uart1_rxd_oe：UART1 Mode0 輸出使能。
 output wire uart1_txd,uart1_rxd_out,uart1_rxd_oe,
 // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。t2_out：Timer2 clock-out 方波資料。
 output reg t2_out,
 // 【教學】output 將內部結果接給外層。t2_output_enable：Timer2 可複用到 P1.0 的允許。
 output wire t2_output_enable,
 // 【教學】output 將內部結果接給外層。uart0_rx_tick：Timer2 提供 UART0 RX 的溢位來源；uart0_tx_tick：Timer2 提供 UART0 TX 的溢位來源。
 output wire uart0_rx_tick,uart0_tx_tick,
 // 【教學】output 將內部結果接給外層。uart0_use_rx_t2：UART0 RX 選 Timer2；uart0_use_tx_t2：UART0 TX 選 Timer2。
 output wire uart0_use_rx_t2,uart0_use_tx_t2,
 // 【教學】output 將內部結果接給外層。adc_sclk：ADC SPI 時鐘，idle 高；adc_mosi：送到 ADC 的序列命令；adc_cs_n：低有效 ADC 晶片選取。
 output wire adc_sclk,adc_mosi,adc_cs_n,
 // 【教學】input 由外部驅動，模組只讀取。adc_miso：ADC 回傳的序列資料。
 input wire adc_miso,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_a：擴充 port A 輸出 latch 的資料；export_b：擴充 port B 輸出 latch 的資料；export_c：擴充 port C 輸出 latch 的資料；export_d：擴充 port D 輸出 latch 的資料。
 output wire [7:0] export_a,export_b,export_c,export_d,
 // 【教學】output 將內部結果接給外層；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_b_oe：擴充 port B 輸出使能，1 輸出、0 輸入；export_c_oe：擴充 port C 輸出使能，1 輸出、0 輸入；export_d_oe：擴充 port D 輸出使能，1 輸出、0 輸入。
 output wire [7:0] export_b_oe,export_c_oe,export_d_oe,
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。export_a_in：擴充 port A 外部輸入值；export_b_in：擴充 port B 外部輸入值；export_c_in：擴充 port C 外部輸入值；export_d_in：擴充 port D 外部輸入值。
 input wire [7:0] export_a_in,export_b_in,export_c_in,export_d_in
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。scon1：UART1 控制及事件旗標；t2con：Timer2 控制、鮑率選擇與旗標；t2mod：Timer2 up/down 與 clock-out 模式。
 reg [7:0] scon1,t2con,t2mod;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[15:0] 指定向量位元範圍，例如 [7:0] 共 8 位。counter2：16-bit Timer2 現值；reload2：16-bit Timer2 重載／capture 值。
 reg [15:0] counter2,reload2;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。ddrb：port B 逐位方向，1 輸出、0 輸入；ddrc：port C 逐位方向，1 輸出、0 輸入；ddrd：port D 逐位方向，1 輸出、0 輸入；porta：port A 的軟體輸出 latch；portb：port B 的軟體輸出 latch；portc：port C 的軟體輸出 latch；portd：port D 的軟體輸出 latch。
 reg [7:0] ddrb,ddrc,ddrd,porta,portb,portc,portd;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。sbuf1：UART1 最近接收 byte。
 wire [7:0] sbuf1;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。ri1：UART1 接收完成事件；ti1：UART1 傳送完成事件；rb8we1：UART1 RB8 更新事件；rb8data1：UART1 RB8 新資料。
 wire ri1,ti1,rb8we1,rb8data1;
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動。txbusy1：UART1 傳送忙碌；rxbusy1：UART1 接收忙碌。
 wire txbusy1,rxbusy1;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。pins_d：上次有效時鐘的 P1 取樣，用來偵測下降沿。
 reg [7:0] pins_d;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。timer2_overflow：Timer2 到終點的單拍事件。
 reg timer2_overflow;
 // 【教學】P1.0 上次高、本次低表示 T2 下降沿；pins_d 只在 run_enable 更新，這不是完整的非同步輸入同步器。
 wire t2fall=pins_d[0]&&!p1[0];
 // 【教學】對 P1.1/T2EX 做下降沿偵測，供 Timer2 capture/reload 使用。
 wire exfall=pins_d[1]&&!p1[1];
 // 【教學】只要 RCLK 或 TCLK 有一個選 Timer2，就採鮑率模式；邏輯或把兩個用途合成一個模式判斷。
 wire baud_mode=t2con[5]||t2con[4];
 // 【教學】CKCON 的 timer 高速位選每個主時鐘；否則用 timer_tick，特殊模式另有選擇。
 // CKCON TxM=1 selects the core clock, 0 selects the timer machine tick.
 // 【教學】先要求 run_enable；C/T2=1 選外部下降沿，否則在下一行選計時時鐘；這些是 clk enable 而非新時鐘。
 wire count_tick=run_enable && (t2con[1] ? t2fall :
                 // 【教學】CKCON 高速、鮑率模式或 clock-out 任一啟用時每拍計數，否則等 timer_tick；此選擇式仍在外層 run_enable 之內。
                 (ckcon[5] || baud_mode || t2mod[1]) ? 1'b1 : timer_tick);
 // 【教學】只有啟用 up/down、不是鮑率模式且 P1.1 為低才向下數；同一腳位因此同時參與方向控制。
 wire down=t2mod[0]&&!baud_mode&&!p1[1];
 // 【教學】向上數終點是 FFFF，向下數終點是 reload2；終點比較必須依方向切換。
 wire count_limit=down ? counter2==reload2 : counter2==16'hffff;
 // 【教學】EXEN2 允許且 T2EX 下降沿時才 capture/reload；up/down 模式把 P1.1 用作方向，因此排除此外部觸發。
 wire ext_reload=t2con[3]&&exfall&&!t2mod[0];
 // 【教學】寫 TL2 或 TH2 的當拍標記為軟體直接寫計數器，後面禁止自動遞增／重載覆蓋。
 wire t2_write=wr&&(addr==8'hcc||addr==8'hcd);
 // 【教學】wire 表示連線，由 assign 或子模組輸出驅動；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。adc_control：ADC 控制與 busy/done 的回讀線；adc_hi：ADC 結果高 byte；adc_lo：ADC 結果低 byte。
 wire [7:0] adc_control,adc_hi,adc_lo;
 // 【教學】TF2 或 EXF2 任一存在就提出 Timer2 請求；IE 的允許篩選放在外層。
 assign timer2_irq=t2con[7]||t2con[6];
 // 【教學】UART1 接收 RI1 或傳送 TI1 任一旗標為 1 都需要服務，軟體須讀 SCON1 區分來源。
 assign serial1_irq=scon1[0]||scon1[1];
 // 【教學】只有 clock-out 模式、TR2 啟動且採內部 timer 時鐘時，才將 Timer2 輸出複用到 P1.0。
 assign t2_output_enable=t2mod[1]&&t2con[2]&&!t2con[1];
 // 【教學】RCLK 位控制 UART0 接收是否改用 Timer2；只選 RX，TX 另有 TCLK。
 assign uart0_use_rx_t2=t2con[5];
 // 【教學】TCLK 位控制 UART0 傳送來源，允許與接收選不同 timer。
 assign uart0_use_tx_t2=t2con[4];
 // 【教學】把 Timer2 單拍溢位事件送到 UART0 接收分頻器；還需 UART 內再除 16，不能直接當 bit 時鐘。
 assign uart0_rx_tick=timer2_overflow;
 // 【教學】同一 Timer2 溢位也送 TX，實際是否採用由 TCLK 決定。
 assign uart0_tx_tick=timer2_overflow;
 // 【教學】將 export A 的軟體 latch 接出；A 沒有提供 DDR/OE，實體方向需在系統頂層決定。
 assign export_a=porta;
 // 【教學】B/C/D 各自把 latch 接到資料輸出；三個 assign 是並行接線，不是先後執行的程式。
 assign export_b=portb;assign export_c=portc;assign export_d=portd;
 // 【教學】DDR 每個 bit 直接作對應輸出使能：1 輸出、0 輸入；真正高阻態緩衝放在頂層。
 assign export_b_oe=ddrb;assign export_c_oe=ddrc;assign export_d_oe=ddrd;

 // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。 SEPARATE_BAUD=1 開啟 RX/TX 獨立鮑率來源。
 mcu8051_serial #(.SEPARATE_BAUD(1)) u_uart1 (
  // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；clock_enable(run_enable)：把子模組的 clock_enable 埠接到外層 run_enable，用途為UART 的狀態推進允許。
  .clk(clk),.rst_n(rst_n),.clock_enable(run_enable),
  // 【教學】具名接線不依埠的排列順序。scon(scon1)：把子模組的 scon 埠接到外層 scon1，用途為UART 模式、REN、SM2、TB8 和 RI/TI/RB8；smod(eicon[7])：把子模組的 smod 埠接到外層 eicon[7]，用途為鮑率倍增選擇，藉分頻減半達成；timer1_overflow(timer1_overflow)：把子模組的 timer1_overflow 埠接到外層 timer1_overflow，用途為Timer1 的單拍溢位，作 UART 鮑率來源。
  .scon(scon1),.smod(eicon[7]),.timer1_overflow(timer1_overflow),
  // 【教學】具名接線不依埠的排列順序。rx_baud_overflow(timer1_overflow)：把子模組的 rx_baud_overflow 埠接到外層 timer1_overflow，用途為RX 可獨立選擇的鮑率來源脈波；tx_baud_overflow(timer1_overflow)：把子模組的 tx_baud_overflow 埠接到外層 timer1_overflow，用途為TX 可獨立選擇的鮑率來源脈波。
  .rx_baud_overflow(timer1_overflow),.tx_baud_overflow(timer1_overflow),
  // 【教學】具名接線不依埠的排列順序。rx_use_timer2(1'b0)：選擇是否採 Timer2 的固定除16，與鮑率來源一致；tx_use_timer2(1'b0)：選擇是否採 Timer2 的固定除16，與鮑率來源一致。
  .rx_use_timer2(1'b0),.tx_use_timer2(1'b0),
  // 【教學】具名接線不依埠的排列順序。rxd(p1[2])：把子模組的 rxd 埠接到外層 p1[2]，用途為串列接收輸入；Mode0 也是同步取樣資料；sbuf_write(wr&&addr==8'hc1)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波；sbuf_write_data(wdata)：把子模組的 sbuf_write_data 埠接到外層 wdata，用途為要送出的 byte。
  .rxd(p1[2]),.sbuf_write(wr&&addr==8'hc1),.sbuf_write_data(wdata),
  // 【教學】具名接線不依埠的排列順序。sbuf_read_data(sbuf1)：把子模組的 sbuf_read_data 埠接到外層 sbuf1，用途為最近收到的 byte，無 FIFO；txd(uart1_txd)：把子模組的 txd 埠接到外層 uart1_txd，用途為串列 TX 輸出，Mode0 改作同步移位時鐘；rxd_out(uart1_rxd_out)：把子模組的 rxd_out 埠接到外層 uart1_rxd_out，用途為Mode0 從 RXD 腳送出的資料。
  .sbuf_read_data(sbuf1),.txd(uart1_txd),.rxd_out(uart1_rxd_out),
  // 【教學】具名接線不依埠的排列順序。rxd_output_enable(uart1_rxd_oe)：把子模組的 rxd_output_enable 埠接到外層 uart1_rxd_oe，用途為Mode0 允許 RXD 腳輸出資料；ri_set(ri1)：把子模組的 ri_set 埠接到外層 ri1，用途為要求外部 SCON 設 RI 的事件；ti_set(ti1)：把子模組的 ti_set 埠接到外層 ti1，用途為要求外部 SCON 設 TI 的事件。
  .rxd_output_enable(uart1_rxd_oe),.ri_set(ri1),.ti_set(ti1),
  // 【教學】具名接線不依埠的排列順序。rb8_write(rb8we1)：把子模組的 rb8_write 埠接到外層 rb8we1，用途為RB8 資料有效更新事件；rb8_data(rb8data1)：把子模組的 rb8_data 埠接到外層 rb8data1，用途為接收第九位或 Mode1 的停止位；tx_busy(txbusy1)：把子模組的 tx_busy 埠接到外層 txbusy1，用途為正在傳送，阻止新資料覆蓋 frame；rx_busy(rxbusy1)：把子模組的 rx_busy 埠接到外層 rxbusy1，用途為正在接收 frame。
  .rb8_write(rb8we1),.rb8_data(rb8data1),.tx_busy(txbusy1),.rx_busy(rxbusy1)
 // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
 );
 // 【教學】建立子模組實例，重用該硬體；後續 .埠名(訊號) 逐項接線，子模組與本模組其他電路同時工作。
 mcu8051_adc_spi u_adc (
  // 【教學】具名接線不依埠的排列順序。clk(clk)：把子模組的 clk 埠接到外層 clk，用途為共同時鐘，上升沿更新時序邏輯；rst_n(rst_n)：把子模組的 rst_n 埠接到外層 rst_n，用途為低有效非同步重置，_n 表示 0 有效；wr(wr&&addr==8'hf8)：寫入有效再比對該 SFR 位址，只有目標模組收到寫脈波；wdata(wdata)：把子模組的 wdata 埠接到外層 wdata，用途為本次寫入的 8-bit 資料。
  .clk(clk),.rst_n(rst_n),.wr(wr&&addr==8'hf8),.wdata(wdata),
  // 【教學】具名接線不依埠的排列順序。control(adc_control)：把子模組的 control 埠接到外層 adc_control，用途為ADC 控制／busy(bit6)／done(bit7)；result_hi(adc_hi)：把子模組的 result_hi 埠接到外層 adc_hi，用途為ADC 回傳的高 byte；result_lo(adc_lo)：把子模組的 result_lo 埠接到外層 adc_lo，用途為ADC 回傳的低 byte。
  .control(adc_control),.result_hi(adc_hi),.result_lo(adc_lo),
  // 【教學】具名接線不依埠的排列順序。sclk(adc_sclk)：把子模組的 sclk 埠接到外層 adc_sclk，用途為SPI 時鐘輸出，Mode3 閒置高；mosi(adc_mosi)：把子模組的 mosi 埠接到外層 adc_mosi，用途為SPI 主機送給從機的資料；cs_n(adc_cs_n)：把子模組的 cs_n 埠接到外層 adc_cs_n，用途為SPI 低有效片選；miso(adc_miso)：把子模組的 miso 埠接到外層 adc_miso，用途為SPI 從機送回主機的資料。
  .sclk(adc_sclk),.mosi(adc_mosi),.cs_n(adc_cs_n),.miso(adc_miso)
 // 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
 );

 // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
 always @(posedge clk or negedge rst_n) begin
  // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
  if(!rst_n) begin
   // 【教學】建立與原系統相容的 SFR 重置影像，並關閉擴充中斷；保留 EXIF/EICON 的固定狀態位。這些 <= 在同一重置事件一起生效。
   ckcon<=8'h01;spc_fnc<=8'h02;mpage<=0;eie<=0;exif<=8'h08;eicon<=8'h40;
   // 【教學】重置 UART1/Timer2 控制及計數值，讓周邊從停用狀態開始，避免未知值引發輸出或中斷。
   scon1<=0;t2con<=0;t2mod<=0;counter2<=0;reload2<=0;
   // 【教學】邊沿歷史預設為高、溢位事件清零、Timer2 輸出 idle 高，提供確定的啟動狀態。
   pins_d<=8'hff;timer2_overflow<=0;t2_out<=1;
   // 【教學】所有 DDR 清 0 先當輸入，資料 latch 也清零；即使資料為 0，DDR=0 時仍不驅動腳位。
   ddrb<=0;ddrc<=0;ddrd<=0;porta<=0;portb<=0;portc<=0;portd<=0;
  // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
  end else begin
   // 【教學】每拍先清 Timer2 溢位，再在真的到終點時設 1，形成供 UART 使用的單拍事件。
   timer2_overflow<=0;
   // 【教學】僅周邊允許運作時更新 P1 的前次取樣；停用期間不追蹤每一個外部邊沿。
   if(run_enable) pins_d<=p1;
   // 【教學】只有寫入時依 addr 解碼更新一個 SFR；沒有寫到的暫存器保留舊值。
   if(wr) case(addr)
    // 【教學】8'h8e 寫入 ckcon（時鐘與原 CPU 等待控制），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'h8e:ckcon<=wdata;
    // 【教學】8'h8f 寫入 spc_fnc（原系統特殊功能控制，獨立套件只保留暫存器），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'h8f:spc_fnc<=wdata;
    // 【教學】寫 EXIF 只採高四個事件位，低四位強制為 8；軟體可透過寫高位清外部中斷旗標。
    8'h91:exif<={wdata[7:4],4'h8};
    // 【教學】8'h92 寫入 mpage（原 CPU MOVX 分頁值，獨立套件不操作記憶體），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'h92:mpage<=wdata;
    // 【教學】8'hc0 寫入 scon1（UART1 控制及事件旗標），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hc0:scon1<=wdata;
    // 【教學】8'hc8 寫入 t2con（Timer2 控制、鮑率選擇與旗標），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hc8:t2con<=wdata;
    // 【教學】8'hc9 寫入 t2mod（Timer2 up/down 與 clock-out 模式），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hc9:t2mod<=wdata;
    // 【教學】8'hca 寫入 reload2[7:0]（16-bit Timer2 重載／capture 值），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hca:reload2[7:0]<=wdata;
    // 【教學】8'hcb 寫入 reload2[15:8]（16-bit Timer2 重載／capture 值），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hcb:reload2[15:8]<=wdata;
    // 【教學】8'hcc 寫入 counter2[7:0]（16-bit Timer2 現值），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hcc:counter2[7:0]<=wdata;
    // 【教學】8'hcd 寫入 counter2[15:8]（16-bit Timer2 現值），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hcd:counter2[15:8]<=wdata;
    // 【教學】寫 EICON 時把 bit6 固定 1、bit2 固定 0，其餘採軟體值；串接讓保留位規則明確可見。
    8'hd8:eicon<={wdata[7],1'b1,wdata[5:3],1'b0,wdata[1:0]};
    // 【教學】8'he8 寫入 eie（擴充中斷允許／優先權），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'he8:eie<=wdata;
    // 【教學】8'hf9 寫入 porta（port A 的軟體輸出 latch），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hf9:porta<=wdata;
    // 【教學】8'hfa 寫入 ddrb（port B 逐位方向，1 輸出、0 輸入），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hfa:ddrb<=wdata;
    // 【教學】8'hfb 寫入 portb（port B 的軟體輸出 latch），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hfb:portb<=wdata;
    // 【教學】8'hfc 寫入 ddrc（port C 逐位方向，1 輸出、0 輸入），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hfc:ddrc<=wdata;
    // 【教學】8'hfd 寫入 portc（port C 的軟體輸出 latch），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hfd:portc<=wdata;
    // 【教學】8'hfe 寫入 ddrd（port D 逐位方向，1 輸出、0 輸入），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hfe:ddrd<=wdata;
    // 【教學】8'hff 寫入 portd（port D 的軟體輸出 latch），資料取 wdata。地址解碼避免一筆寫入同時改到其他暫存器，<= 使值在本拍結束一起提交。
    8'hff:portd<=wdata;
    // 【教學】沒有符合的 case 就不作額外指派；寫入時保留舊值，組合讀取已先給 rdata=0，所以此空分支不會產生 latch。
    default:;
   // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
   endcase
   // 【教學】UART1 的 RI 事件鎖存進 SCON1[0]；這行在軟體寫入後面，同拍事件優先，避免遺失接收通知。
   if(ri1)scon1[0]<=1;
   // 【教學】UART1 傳送完成設定 TI1；旗標留到軟體清除，不要求 CPU 恰好在單拍事件時讀取。
   if(ti1)scon1[1]<=1;
   // 【教學】只有接收第九位／停止位更新事件有效時才寫 RB8，其他時間保留上次結果。
   if(rb8we1)scon1[2]<=rb8data1;
   // 【教學】這一段 Timer2 及擴充外部中斷只在 run_enable 時運作；上面的 SFR 寫入與 UART 事件更新不在此條件內。
   if(run_enable) begin
    // 【教學】EX2～EX5 下降沿只有在對應 EIE 已啟用時才鎖存，停用期間不保留事件。
    // Match the 4T external interrupt logic: EX2..EX5 falling. Flag capture is enabled by EXn, as on its pin mux.
    // 【教學】EIE[4] 已允許，且 P1.4 前拍高、本拍低時鎖存 EXIF[4]；停用時不保存邊沿，這與事後才用 enable 篩選旗標的設計不同。
    if(eie[4]&&pins_d[4]&&!p1[4])exif[4]<=1;
    // 【教學】EIE[5] 已允許，且 P1.5 前拍高、本拍低時鎖存 EXIF[5]；停用時不保存邊沿，這與事後才用 enable 篩選旗標的設計不同。
    if(eie[5]&&pins_d[5]&&!p1[5])exif[5]<=1;
    // 【教學】EIE[6] 已允許，且 P1.6 前拍高、本拍低時鎖存 EXIF[6]；停用時不保存邊沿，這與事後才用 enable 篩選旗標的設計不同。
    if(eie[6]&&pins_d[6]&&!p1[6])exif[6]<=1;
    // 【教學】EIE[7] 已允許，且 P1.7 前拍高、本拍低時鎖存 EXIF[7]；停用時不保存邊沿，這與事後才用 enable 篩選旗標的設計不同。
    if(eie[7]&&pins_d[7]&&!p1[7])exif[7]<=1;
    // 【教學】TR2 啟動、本拍有計數事件且未寫 TL2/TH2 才更新，保障軟體設定的優先權。
    if(t2con[2]&&count_tick&&!t2_write) begin
     // 【教學】計數值已到本方向的終點時處理回捲／reload，同時產生溢位，而不是再走普通加減。
     if(count_limit) begin
      // 【教學】向下到終點後回 FFFF；向上時自動重載、鮑率、up/down、clock-out 都載 reload2，只有一般 capture 模式回 0000。巢狀 ?: 是分層多工器。
      counter2<=down?16'hffff: ((!t2con[0]||baud_mode||t2mod[0]||t2mod[1])?reload2:16'h0000);
      // 【教學】發出 Timer2 終點事件供 UART 使用；是否同時設定 TF2 由下面模式條件決定。
      timer2_overflow<=1;
      // 【教學】clock-out 模式每次溢位翻轉輸出，因此兩次溢位才形成一個完整方波週期。
      if(t2mod[1])t2_out<=~t2_out;
      // 【教學】只有一般計數溢位設定 TF2；鮑率及 clock-out 不因每個週期都要求 CPU 中斷。
      if(!baud_mode&&!t2mod[1])t2con[7]<=1;
      // 【教學】up/down 且非鮑率模式到終點就翻轉 EXF2；此處是 toggle，不是每次固定寫 1。
      if(t2mod[0]&&!baud_mode)t2con[6]<=~t2con[6];
     // 【教學】未到終點時依方向減一或加一；固定位寬的計數器配合上面的終點處理。
     end else counter2<=down?counter2-16'd1:counter2+16'd1;
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】外部 T2EX capture/reload 條件成立時執行；這段排在一般計數之後，同拍指派同暫存器時可能覆寫前面的結果。
    if(ext_reload) begin
     // 【教學】外部 capture/reload 事件鎖存 EXF2，供軟體辨認；不會因下一拍輸入解除而自動清除。
     t2con[6]<=1;
     // 【教學】一般 capture 模式把目前計數值存到 RCAP2；因 <= 用舊值，本拍捕捉的是計數更新之前的 counter2。
     if(!baud_mode&&t2con[0])reload2<=counter2;
     // 【教學】其他外部觸發情況從 RCAP2 重載計數器，但不能覆蓋同拍直接寫 TL2/TH2。
     else if(!t2_write)counter2<=reload2;
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
   // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
   end
  // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
  end
 // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
 end

 // 【教學】開始解碼擴充模組負責的 SFR；命中時外層讀多工器必須選 extended 的 rdata，而非基本 bank。
 assign selected=addr==8'h8e||addr==8'h8f||addr==8'h91||addr==8'h92||
  // 【教學】接續地址解碼：C0～C3 是 UART1/ADC 結果，C8～CD 是 Timer2 控制與計數。&& 把範圍上下界同時限制。
  (addr>=8'hc0&&addr<=8'hc3)||(addr>=8'hc8&&addr<=8'hcd)||
  // 【教學】完成解碼 EICON、EIE 與 F8～FF 的 ADC/export IO；selected 只表示位址歸屬，不代表有讀寫動作。
  addr==8'hd8||addr==8'he8||addr>=8'hf8;
 // 【教學】組合邏輯：任何讀到的輸入變化都重新求值；用阻塞 = 並覆蓋所有路徑，才能形成多工器而非意外 latch。
 always @(*) begin
  // 【教學】組合讀取先給預設 0，後面 case 再覆寫；即使 default 不指派也不會保留舊值，因此不推導 latch。
  rdata=0;
  // 【教學】以 addr 選擇對應分支；解碼硬體同時監看選擇訊號，case 本身不是循序跑一遍所有選項。
  case(addr)
   // 【教學】8'h8e → ckcon：讀回 時鐘與原 CPU 等待控制；讀取只經組合多工器，不更改其儲存值；8'h8f → spc_fnc：讀回 原系統特殊功能控制，獨立套件只保留暫存器；讀取只經組合多工器，不更改其儲存值；8'h91 → exif：讀回 擴充外部中斷事件旗標；讀取只經組合多工器，不更改其儲存值；8'h92 → mpage：讀回 原 CPU MOVX 分頁值，獨立套件不操作記憶體；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'h8e:rdata=ckcon;8'h8f:rdata=spc_fnc;8'h91:rdata=exif;8'h92:rdata=mpage;
   // 【教學】8'hc0 → scon1：讀回 UART1 控制及事件旗標；讀取只經組合多工器，不更改其儲存值；8'hc1 → sbuf1：讀回 UART1 最近接收 byte；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hc0:rdata=scon1;8'hc1:rdata=sbuf1;
   // 【教學】8'hc2 → adc_lo：讀回 ADC 結果低 byte；讀取只經組合多工器，不更改其儲存值；8'hc3 → adc_hi：讀回 ADC 結果高 byte；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hc2:rdata=adc_lo;8'hc3:rdata=adc_hi;
   // 【教學】8'hc8 → t2con：讀回 Timer2 控制、鮑率選擇與旗標；讀取只經組合多工器，不更改其儲存值；8'hc9 → t2mod：讀回 Timer2 up/down 與 clock-out 模式；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hc8:rdata=t2con;8'hc9:rdata=t2mod;
   // 【教學】8'hca → reload2[7:0]：讀回 16-bit Timer2 重載／capture 值的 bit7～bit0 切片；讀取只經組合多工器，不更改其儲存值；8'hcb → reload2[15:8]：讀回 16-bit Timer2 重載／capture 值的 bit15～bit8 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hca:rdata=reload2[7:0];8'hcb:rdata=reload2[15:8];
   // 【教學】8'hcc → counter2[7:0]：讀回 16-bit Timer2 現值的 bit7～bit0 切片；讀取只經組合多工器，不更改其儲存值；8'hcd → counter2[15:8]：讀回 16-bit Timer2 現值的 bit15～bit8 切片；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hcc:rdata=counter2[7:0];8'hcd:rdata=counter2[15:8];
   // 【教學】8'hd8 → eicon：讀回 擴充控制與事件位，bit7 也作 UART1 SMOD；讀取只經組合多工器，不更改其儲存值；8'he8 → eie：讀回 擴充中斷允許／優先權；讀取只經組合多工器，不更改其儲存值；8'hf8 → adc_control：讀回 ADC 控制與 busy/done 的回讀線；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hd8:rdata=eicon;8'he8:rdata=eie;8'hf8:rdata=adc_control;
   // 【教學】8'hf9 → export_a_in：讀回 擴充 port A 外部輸入值；讀取只經組合多工器，不更改其儲存值；8'hfa → ddrb：讀回 port B 逐位方向，1 輸出、0 輸入；讀取只經組合多工器，不更改其儲存值。此處 = 是組合阻塞指派。
   8'hf9:rdata=export_a_in;8'hfa:rdata=ddrb;
   // 【教學】8'hfb → (export_b_in&~ddrb)|(portb&ddrb)：DDR=0 的位取輸入，DDR=1 的位取輸出 latch；逐位遮罩後 OR 合成 byte。此處 = 是組合阻塞指派。
   8'hfb:rdata=(export_b_in&~ddrb)|(portb&ddrb);
   // 【教學】8'hfc → ddrc：讀回 port C 逐位方向，1 輸出、0 輸入；讀取只經組合多工器，不更改其儲存值；8'hfd → (export_c_in&~ddrc)|(portc&ddrc)：DDR=0 的位取輸入，DDR=1 的位取輸出 latch；逐位遮罩後 OR 合成 byte。此處 = 是組合阻塞指派。
   8'hfc:rdata=ddrc;8'hfd:rdata=(export_c_in&~ddrc)|(portc&ddrc);
   // 【教學】8'hfe → ddrd：讀回 port D 逐位方向，1 輸出、0 輸入；讀取只經組合多工器，不更改其儲存值；8'hff → (export_d_in&~ddrd)|(portd&ddrd)：DDR=0 的位取輸入，DDR=1 的位取輸出 latch；逐位遮罩後 OR 合成 byte。此處 = 是組合阻塞指派。
   8'hfe:rdata=ddrd;8'hff:rdata=(export_d_in&~ddrd)|(portd&ddrd);
   // 【教學】沒有符合的 case 就不作額外指派；寫入時保留舊值，組合讀取已先給 rdata=0，所以此空分支不會產生 latch。
   default:;
  // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
  endcase
 // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
 end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule

// 【教學】ADC 固定命令流程：Ax、41、等 MISO 低、00、00；不是通用 SPI 控制器。
// Same ADC command sequence as the 4T: Ax,41,wait MISO low,00,00.
// 【教學】SPI Mode3；半週期預設 66 clk，四 byte 期間 CS 低，字節間隔預設 100 clk。
// SPI mode 3, divider 66, CS held low over four bytes, 100 clock gaps.
// 【教學】宣告可重複使用的硬體模組 mcu8051_adc_spi，後面列出它對外的腳位；#(...) 的參數可在建立實例時決定硬體配置。HALF_PERIOD=66 設 SPI 半週期，GAP=100 設 byte 間隔，皆以 clk 次數為單位。
module mcu8051_adc_spi #(parameter HALF_PERIOD=66,GAP=100)(
 // 【教學】input 由外部驅動，模組只讀取；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。clk：共同時鐘，上升沿更新時序邏輯；rst_n：低有效非同步重置，_n 表示 0 有效；wr：本拍寫入有效；wdata：本次寫入的 8-bit 資料。
 input wire clk,rst_n,wr,input wire [7:0] wdata,
 // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。control：ADC 控制／busy(bit6)／done(bit7)；result_hi：ADC 回傳的高 byte；result_lo：ADC 回傳的低 byte。
 output reg [7:0] control,result_hi,result_lo,
 // 【教學】output 將內部結果接給外層；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；此行混合方向，只有 miso 是外部輸入，sclk/mosi/cs_n 是本模組輸出。sclk：SPI 時鐘輸出，Mode3 閒置高；mosi：SPI 主機送給從機的資料；cs_n：SPI 低有效片選；miso：SPI 從機送回主機的資料。
 output reg sclk,mosi,cs_n,input wire miso
// 【教學】關閉埠宣告或本次模組實例的接線清單；分號結束這個語法單元，不表示多等一個時鐘。
);
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[2:0] 指定向量位元範圍，例如 [7:0] 共 8 位。state：FSM 目前狀態，三位可容納六種狀態。
 reg [2:0] state;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。tx：SPI 本 byte 待送資料；rx：SPI 本 byte 接收移位暫存。
 reg [7:0] tx,rx;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[7:0] 指定向量位元範圍，例如 [7:0] 共 8 位。div_count：SPI 半週期分頻計數；八位參數須留在可表示範圍；gap_count：SPI byte 間隔計數；八位參數須留在可表示範圍。
 reg [7:0] div_count,gap_count;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[2:0] 指定向量位元範圍，例如 [7:0] 共 8 位。bit_count：SPI bit7 到 bit0 的倒數索引。
 reg [2:0] bit_count;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯；[1:0] 指定向量位元範圍，例如 [7:0] 共 8 位。byte_count：SPI 四個 byte 的 0～3 編號。
 reg [1:0] byte_count;
 // 【教學】reg 可在 always 內指派；此處的用途須配合後面區塊判斷；reg 不是一律等於正反器，時鐘 always 才儲存，完整組合 always 則是組合邏輯。miso_s1：MISO 同步第一級；miso_s2：MISO 同步第二級，後段只使用此級。
 reg miso_s1,miso_s2;
 // 【教學】寫控制且新值 busy=1、舊 busy=0 才產生啟動條件，避免同一次交易重複啟動；狀態機還要在 IDLE 才接受。
 wire start=wr&&wdata[6]&&!control[6];
 // 【教學】用具名常數定義六個 FSM 狀態，讀 LOW/HIGH 比讀數字更清楚；常數本身不需要正反器。
 localparam IDLE=0,LOW=1,HIGH=2,PAUSE=3,READY=4,FINISH=5;
 // 【教學】clk 上升沿更新暫存器，rst_n 下降沿可不等時鐘立即重置，描述帶非同步低有效 reset 的正反器；同區塊內用 <= 讓各暫存器取樣同一拍舊值。
 always @(posedge clk or negedge rst_n) begin
  // 【教學】rst_n=0 走重置分支；! 是邏輯反相，後面的初值讓模擬和上電 reset 後狀態確定。
  if(!rst_n) begin
   // 【教學】重置控制、結果與狀態，先回到閒置而不啟動任何 ADC 交易。
   control<=0;result_hi<=0;result_lo<=0;state<=IDLE;
   // 【教學】傳收資料與各層計數器都清零，避免第一次 SPI 交易承接未知的 bit/byte 位置。
   tx<=0;rx<=0;div_count<=0;gap_count<=0;bit_count<=0;byte_count<=0;
   // 【教學】MISO 同步級預設高，SCLK idle 高、CS 不選取，符合本控制器的 SPI Mode3 起始狀態。
   miso_s1<=1;miso_s2<=1;sclk<=1;mosi<=0;cs_n<=1;
  // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
  end else begin
   // 【教學】兩級正反器依序取樣 MISO；非阻塞讓第二級拿上一拍第一級的值，以降低非同步輸入亞穩態傳到後級的機率。
   miso_s1<=miso;miso_s2<=miso_s1;
   // 【教學】寫入新啟動要求時強制清 control[7] 完成位，保留其餘七位；非啟動寫入就原值保存。
   if(wr)control<=wdata[6]?{1'b0,wdata[6:0]}:wdata;
   // 【教學】以 state 選擇對應分支；解碼硬體同時監看選擇訊號，case 本身不是循序跑一遍所有選項。
   case(state)
    // 【教學】狀態為 IDLE 才接受 start；忙碌狀態不會因重寫控制就重新跑第一 byte。
    IDLE:if(start)begin
     // 【教學】第一個命令 byte 由固定高半 A 與低四位通道／選項拼成 Ax，同時清接收移位暫存器。
     tx<={4'ha,wdata[3:0]};rx<=0;
     // 【教學】從第 0 byte 的 bit7 開始 MSB-first，清分頻、拉低 CS 選晶片並進入低相位等待。
     byte_count<=0;bit_count<=7;div_count<=0;cs_n<=0;state<=LOW;
    // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
    end
    // 【教學】LOW 狀態等滿半週期才改變 SCLK；由 0 數到 HALF_PERIOD-1 剛好是 HALF_PERIOD 個 clk。
    LOW:if(div_count==HALF_PERIOD-1)begin
     // 【教學】分頻歸零、SCLK 拉低時推出本位 MOSI，切到 HIGH 等待下一個取樣邊沿；資料有半週期建立時間。
     div_count<=0;sclk<=0;mosi<=tx[bit_count];state<=HIGH;
    // 【教學】本次半週期尚未結束就只增加分頻計數；SCLK/MOSI 不變，讓輸出電位保持穩定。
    end else div_count<=div_count+1'b1;
    // 【教學】HIGH 等待另一個半週期，到點後產生 SCLK 上升沿並收資料，完成一個 SPI bit。
    HIGH:if(div_count==HALF_PERIOD-1)begin
     // 【教學】上升沿時把同步後 MISO 放進 RX 最低位，其餘左移；連續八次組成 MSB-first 接收 byte。
     div_count<=0;sclk<=1;rx<={rx[6:0],miso_s2};
     // 【教學】bit7 已一路數到 bit0，代表本 byte 最後一位正在取樣，接著需處理 byte 邊界。
     if(bit_count==0)begin
      // 【教學】第三個 byte（編號 2）是高結果，拼入本拍最後一位；不能直接用舊 rx，否則漏一位。
      if(byte_count==2)result_hi<={rx[6:0],miso_s2};
      // 【教學】第四個 byte（編號 3）接收完即完成整筆交易，不再安排下一個 byte。
      if(byte_count==3)begin
       // 【教學】保存低結果並切換 FINISH，下一拍集中處理 done/busy 與 CS 釋放。
       result_lo<={rx[6:0],miso_s2};state<=FINISH;
      // 【教學】關閉前一個 begin 並開始條件不成立的 else 分支；兩條路互斥，由包住它的 if 決定，不會自行消耗一個 clock。
      end else begin
       // 【教學】尚有下一 byte，先遞增 byte 編號並重設字節間隔，保證後續 pause 從頭計時。
       byte_count<=byte_count+1'b1;gap_count<=0;
       // 【教學】用舊 byte_count 判斷下一筆：第一筆之後送 41，其餘送 00 以產生讀結果所需時鐘。
       tx<=byte_count==0?8'h41:8'h00;
       // 【教學】第二筆命令（舊編號 1）後先等 ADC ready，其餘 byte 只等固定間隔；舊值判斷是 <= 的關鍵。
       state<=byte_count==1?READY:PAUSE;
      // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
      end
     // 【教學】本 byte 還沒收完就把位索引減一，回 LOW 開始下一個 SPI bit；減索引實作 MSB-first。
     end else begin bit_count<=bit_count-1'b1;state<=LOW;end
    // 【教學】本次半週期尚未結束就只增加分頻計數；SCLK/MOSI 不變，讓輸出電位保持穩定。
    end else div_count<=div_count+1'b1;
    // 【教學】ADC 以 MISO 拉低表示就緒，收到後開始固定 gap；若一直高，狀態會一直等，這版沒有 timeout。
    READY:if(!miso_s2)begin gap_count<=0;state<=PAUSE;end
    // 【教學】字節間等滿 GAP 個 clk；由 0 計數所以終值比較 GAP-1，而不是 GAP。
    PAUSE:if(gap_count==GAP-1)begin
     // 【教學】間隔結束後重設 bit7 與接收／分頻，開始下一個完整 byte，不能沿用上一筆 bit0。
     bit_count<=7;rx<=0;div_count<=0;state<=LOW;
    // 【教學】未等滿間隔就只增加 gap_count，期間 SCLK/CS 保持原狀，不多送時鐘。
    end else gap_count<=gap_count+1'b1;
    // 【教學】完成時設 done、清 busy、釋放 CS，並回 IDLE 準備下一筆；交易結果保留供軟體讀。
    FINISH:begin control[7]<=1;control[6]<=0;cs_n<=1;state<=IDLE;end
    // 【教學】若 FSM 狀態不在已列出的編碼，回 IDLE；這是狀態復原路徑，但此行本身不會同時重設所有 SPI 輸出。
    default:state<=IDLE;
   // 【教學】結束目前 case 選擇；它和 begin/end 不同，要與前面的 case 配對，不能互換。
   endcase
  // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
  end
 // 【教學】結束最近一個尚未配對的 begin 區塊；end 只是界定作用範圍，不代表這裡額外等待時鐘或停止硬體。
 end
// 【教學】結束此 module 的定義；不同 module 是可並行存在的硬體，不會像函式一樣依檔案順序執行。
endmodule
