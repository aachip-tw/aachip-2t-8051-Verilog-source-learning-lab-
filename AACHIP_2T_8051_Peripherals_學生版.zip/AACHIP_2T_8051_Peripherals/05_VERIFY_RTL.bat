@echo off
setlocal
pushd "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File verify.ps1
if errorlevel 1 goto failed
powershell -NoProfile -ExecutionPolicy Bypass -File verify_8051.ps1
if errorlevel 1 goto failed
echo.
echo PASS
popd
pause
exit /b 0
:failed
echo.
echo FAIL - read the error above and the log in build.
popd
pause
exit /b 1
