@echo off
setlocal
pushd "%~dp0"
if "%~1"=="" (
  set /p "LAB_NUMBER=Lesson number [01-09]: "
) else (
  set "LAB_NUMBER=%~1"
)
python -u tools\run_lessons.py "%LAB_NUMBER%" --open
if errorlevel 1 goto failed
echo.
echo PASS
popd
pause
exit /b 0
:failed
echo.
echo FAIL - read the error above and the log in build.
popd
pause
exit /b 1
