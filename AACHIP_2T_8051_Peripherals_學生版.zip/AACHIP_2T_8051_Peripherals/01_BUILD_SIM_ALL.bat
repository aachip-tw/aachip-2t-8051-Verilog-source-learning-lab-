@echo off
setlocal
pushd "%~dp0"
python -u tools\run_lessons.py all
if errorlevel 1 goto failed
echo.
echo PASS
popd
pause
exit /b 0
:failed
echo.
echo FAIL - read the error above and the log in build.
popd
pause
exit /b 1
