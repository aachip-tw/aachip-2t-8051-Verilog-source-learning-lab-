# 周邊 RTL 詳細中文說明

本文件以本套件內實際 RTL 為依據。傳統 8051 規格僅用於解釋命名，實際支援程度以此程式為準。

## 1. 模組關係與抽出邊界

```
aachip_8051_peripherals（新增封裝）
 ├─ mcu8051_gpio          P0～P3、模式暫存器、腳位複用
 ├─ mcu8051_timer0        Timer0/Counter0、Mode3 的 TH0
 ├─ mcu8051_timer1        Timer1/Counter1、UART 溢位來源
 ├─ mcu8051_serial        UART0
 ├─ mcu8051_sfr_bank      基本控制暫存器、中斷旗標、SFR 讀回
 └─ mcu8051_extended      Timer2、擴充 SFR、IO、外部中斷
     ├─ mcu8051_serial    UART1
     └─ mcu8051_adc_spi   專用 ADC SPI 控制器
```

Counter 並非另一個獨立模組：它是 Timer 的外部事件計數模式。ADC SPI 模組與 extended 寫在同一個檔案，因此不要重複加入第二份定義。

基本 SFR bank 同時含有 ACC、B、PSW、SP、雙 DPTR。為保留原模組與原旗標更新語意，本套件保留它們；新增封裝將 CPU 專用寫回輸入全部接 0，未輸出 CPU 暫存器。匯流排仍可讀寫相關位址，這不代表套件內含 CPU。

## 2. 新增封裝與共同時序

### 2.1 SFR 匯流排

| 訊號 | 說明 |
|---|---|
| sfr_addr[7:0] | SFR byte 位址 |
| sfr_wdata[7:0] | 寫入值 |
| sfr_we | 上升沿為 1 就寫入；不自動清除 |
| sfr_rdata[7:0] | 目前位址的組合讀回 |
| sfr_rmw | GPIO 讀取是否選 latch；不改變一般控制 SFR 的讀取 |
| run_enable | 主要計時與 UART 推進允許；不是所有狀態的總停止開關 |
| irq_ack/source | 接收端回報已接受某中斷，僅基本來源有自動清旗標 |

extended 的 selected 優先於基本 SFR bank。只有提交到此介面的寫入才應拉高 sfr_we；原 CPU 的 IRAM/SFR 解碼已經不在封裝中。沒有 byte enable，也不處理 8051 位元位址指令；若上游需要位元操作，必須正確轉為 byte 的讀改寫。

`TIMER_CLK_DIV` 預設 1，分頻計數器每個 run_enable 有效的時鐘推進一次，產生 timer_tick。CKCON[3]/[4] 可讓 T0/T1 改用每個有效主時鐘。新增封裝沒有原 CPU 的 MOVX 等待或 debug 停機握手，因此不是整顆 2T CPU 的時序替代品，也不能從「2T」名稱直接推定 Timer 必為除 2。

run_enable=0 時，T0/T1 的 timer_tick 被擋住，但 Counter0/1 的外部下降沿路徑仍運作；基本 SFR 的外部中斷、軟體寫入及 ADC 也仍運作。UART 在停用時保持既有 ri_set/ti_set/rb8_write，事件輸出不保證自動回 0。需要完全凍結時應另外設計完整的 clock-enable 政策，不能直接把 run_enable 當成整體 halt。

## 3. GPIO：mcu8051_gpio.v

### 3.1 暫存器與重置

P0～P3 各有 8-bit latch，重置為 FF；每個 port 有 M1、M0 兩個 8-bit 模式暫存器，重置為 00。寫入 port 位址只更新 latch；寫入模式位址只更新相應模式暫存器。

| 位址 | 功能 | 位址 | 功能 |
|---|---|---|---|
| 80/90/A0/B0 | P0/P1/P2/P3 | E1/E2 | P0M1/P0M0 |
| E3/E4 | P1M1/P1M0 | E5/E6 | P2M1/P2M0 |
| F1/F2 | P3M1/P3M0 | | |

### 3.2 輸出使能

每一位依 M1/M0 選擇：

| M1 M0 | 模式 | OE 行為 |
|---|---|---|
| 00 | 準雙向 | 輸出值 0 時拉低；值 1 時釋放 |
| 01 | 推挽 | 一直驅動，可輸出高或低 |
| 10 | 輸入 | 一直釋放 |
| 11 | 開漏 | 值 0 時拉低，值 1 時釋放 |

此 RTL 的準雙向與開漏在 OE 真值上相同，沒有實作傳統短暫強上拉電路。`pN_out` 是驅動資料，`pN_oe=1` 才允許實體腳位輸出。三態需落在晶片頂層 I/O，而不是任意 FPGA 內部匯流排。

### 3.3 讀回與複用

一般讀回使用 pN_in；RMW 讀回 latch。如此可避免外部把腳位拉低後，讀改寫又把原本的輸出 1 錯存成 0。

P3.0 為 UART0 RXD，P3.1 為 TXD；P3.2/3 為 INT0/1；P3.4/5 為 Counter0/1。獨立外部輸入與對應 P3 輸入做 AND，因此任一拉低都會使有效輸入為低。獨立輸入不用時接 1。

EXTENDED=1 時 P1.3 為 UART1 TXD，P1.2 可作 UART1 Mode0 資料輸出，P1.0 在 Timer2 clock-out 啟用時改接 t2_out。UART 輸出通常與 port latch 做 AND，軟體須把對應 latch 設 1；OE 模式仍最後決定是否真的驅動腳位。Timer2 的輸出資料替換不代表 OE 自動強制啟用。

## 4. Timer0 / Counter0：mcu8051_timer0.v

輸入包括 timer_tick、t0_pin、int0_n、TMOD 低四位、TR0/TR1，以及 TL/TH 的寫入脈波。輸出 TL0、TH0 和單 clk 的 overflow0、overflow1_split。重置全部為 0，下降沿記憶 t0_d 重置為 1。

TMOD[3] 是 GATE，為 1 時只有 INT0 高才允許計數；TMOD[2] 是 C/T，為 0 選 timer_tick，為 1 選 t0_pin 的下降沿。TR0 也必須為 1。t0_d 每個 clk 記錄腳位，因此下降沿是 `t0_d && !t0_level`。

| M1 M0 | 實際行為 |
|---|---|
| 00 | `{TH0,TL0[4:0]}` 13-bit 遞增；TL0 高三位保留；1FFF 回 0 並溢位 |
| 01 | `{TH0,TL0}` 16-bit 遞增；FFFF 回 0 並溢位 |
| 10 | TL0 為 8-bit 計數器；FF 後載入 TH0 並溢位；TH0 為 reload |
| 11 | TL0 維持 8-bit T0/Counter0；TH0 另作 TR1 控制的 8-bit timer |

Mode3 的 TH0 只吃 timer_tick，不用 C/T0 與 GATE0。它的 overflow1_split 接到架構上的 TF1。非 split 模式時，只要同拍寫 TL 或 TH 就抑制整組計數；split 模式只抑制被寫的半部。overflow 每拍預設清零，事件交由 SFR bank 保存成 sticky flag。

外部腳位目前只有單拍記憶來找邊沿，沒有完整兩級同步器及除抖。外部非同步 counter 訊號的頻率與脈寬必須允許可靠採樣；實際上板應評估 CDC 與亞穩態。

## 5. Timer1 / Counter1：mcu8051_timer1.v

TMOD 高四位送入此模組後重新編號為 [3:0]，解讀方式與 T0 相同，使用 TR1、INT1、T1。模式 0/1/2 分別為 13-bit、16-bit、8-bit reload，模式 3 不計數。

雖然有 timer0_split_mode 輸入，此版模組內未使用它。Timer0 split 時 Timer1 仍由 TR1 啟停，其 overflow1 繼續提供 UART；封裝只是在 TF1 來源選擇器改接 TH0 的 split overflow。不要把「T0 Mode3」解讀為 Timer1 本體完全停止。

以 Timer1 Mode2 作 UART 時，若有效 Timer1 tick 頻率為 Ftick、TH1=N，溢位頻率約為 `Ftick/(256-N)`。此為穩態公式，剛寫 TL1 或起動的第一段計數可能不同。

## 6. UART：mcu8051_serial.v

UART0 與 UART1 共用此模組。SCON[7:6] 選模式，SCON[5] 為 SM2，SCON[4] 為 REN，SCON[3] 為 TB8；RI/TI/RB8 透過輸出事件更新外部 SCON，而非在 serial 模組內維護整顆 SCON。

| 模式 | TXD / RXD 行為 | 時脈來源 |
|---|---|---|
| 0 | TXD 為移位時鐘，RXD 為雙向同步資料；8-bit、LSB first | MODE0_BAUD_DIV，每兩個事件移一位 |
| 1 | start=0、8 data、stop=1，10-bit frame | Timer1 或分開的 Timer2 溢位 |
| 2 | start、8 data、TB8、stop，11-bit frame | clk 固定分頻 |
| 3 | 11-bit frame，同 Mode2 格式 | 可變鮑率來源 |

### 6.1 傳送與事件

只有 `sbuf_write && !tx_busy` 才接受新資料；忙碌時再次寫入會忽略，沒有 FIFO。寫入 SBUF 後立即把 start bit 輸出為 0，之後依鮑率 tick 右移 tx_shift。最後回到 idle 高並輸出 ti_set。Mode0 會同時取樣 RXD，完成後同時產生 RI/TI。

TI/RI 不是傳送握手的 ready，控制端通常需先清 TI，再寫 SBUF，等待 TI。Mode1/2/3 接收時每個鮑率 tick 偵測 start 低，之後每個 tick 取一位。此版沒有 16 倍過取樣、半位元中心校準與多數決，外部非同步 UART 的可靠度必須用實際鮑率及相位驗證。

Mode1 的停止位存入 RB8；Mode2/3 的第九位存入 RB8。SM2=1 時，RI 只在對應 RB8 條件為 1 時置位。RTL 沒有額外 framing-error 或 overrun 狀態，也沒有接收 FIFO，後續 frame 可覆蓋 sbuf_read_data。

### 6.2 鮑率

預設 VARIABLE_BAUD_DIV=32，SMOD=1 改為一半，最小 1；Mode2 的 MODE2_BAUD_DIV=64，同樣可由 SMOD 減半。UART0 設 SEPARATE_BAUD=1，可分別選接收與傳送的 Timer2 溢位；選 Timer2 時分母固定 16，不走 SMOD。

因此穩態下，Mode1/3 搭 Timer1 為 `Foverflow1/32` 或 `/16`；搭 Timer2 為 `Foverflow2/16`；Mode2 為有效 clk 推進率 `/64` 或 `/32`。UART1 的實例使用模組預設參數，從 Timer1 取時鐘，SMOD 來自 EICON[7]；新增封裝的 SERIAL_* 參數只傳給 UART0。

選 Timer2 的除 16 計數器寬度仍由 VARIABLE_BAUD_DIV 決定。不要在使用 Timer2 時把該參數降到不足以表示 0～15，否則無法到達終值。傳送開始沒有重設所有自由運轉的 baud counter，第一個 start bit 長度需單獨評估。

## 7. SFR bank：mcu8051_sfr_bank.v

此模組提供基本 SFR 寫入及組合讀回，TL/TH 的資料實際由 Timer 儲存，SBUF 接收資料由 UART 儲存，GPIO 讀回由 gpio 提供。基本未知位址讀 0。

| 位址 | 暫存器 | 說明 |
|---|---|---|
| 88 | TCON | TF1/TR1/TF0/TR0/IE1/IT1/IE0/IT0 |
| 89 | TMOD | 高半 T1，低半 T0；各為 GATE/C-T/M1/M0 |
| 8A/8C | TL0/TH0 | 寫入直接送 Timer0 |
| 8B/8D | TL1/TH1 | 寫入直接送 Timer1 |
| 98/99 | SCON0/SBUF0 | 控制、傳送寫入／接收讀回 |
| 87 | PCON | bit7 SMOD0；bit5:4 強制為 11 |
| A8/B8 | IE/IP | 中斷 enable/priority；IP bit7 強制為 1 |

INT0/1 由 IT0/1 選下降沿或低電位。下降沿模式保存 IE0/1；低電位模式每拍以輸入電位更新旗標。TF0/TF1 在 overflow 時置位；RI/TI 在 UART 事件時置位。這些硬體更新排在軟體寫入後，因而同拍事件可蓋過軟體清除。

irq_ack_source=0/2 時只在邊沿模式清外部旗標；=1/3 時清 TF0/TF1。序列中斷 RI/TI 需軟體清除；同拍新事件仍可重新置位。ack 來源是 4-bit，不能只接低三位。

其餘 CPU 暫存器：SP 重置 07，ACC/B/PSW/DPTR 為 0，PCON=30、IP=80。82/83 為 DP0，84/85 為 DP1，86 bit0 選 DPS。CPU 選定 DPTR 輸出與固定 DP0/DP1 的 byte 位址不同。PSW bit0 由 ACC 奇偶性維護。這些是相依模組保留的行為，不影響本套件主要周邊功能。

## 8. 擴充模組：mcu8051_extended.v

### 8.1 位址與初始化

| 位址 | 功能 | 重置／特性 |
|---|---|---|
| 8E | CKCON | 01；bit3/4/5 分別影響 T0/1/2 計數時鐘 |
| 8F | SPC_FNC | 02；原 CPU 用 bit0 控制 program_write_enable |
| 91 | EXIF | 08；低四位寫入後強制 8 |
| 92 | MPAGE | 00；原 CPU MOVX page |
| C0/C1 | SCON1/SBUF1 | UART1 控制與資料 |
| C2/C3 | ADC 低／高結果 | 唯讀結果 |
| C8/C9 | T2CON/T2MOD | Timer2 控制 |
| CA/CB | RCAP2L/H | reload2，也用於 capture |
| CC/CD | TL2/TH2 | counter2 |
| D8 | EICON | 40；寫入強制 bit6=1、bit2=0 |
| E8 | EIE | 00；擴充 enable 與 priority 位元 |
| F8 | ADC control | SPI 啟動、busy、完成旗標 |
| F9 | export A | 寫 latch，讀 export_a_in；未提供 A 的 OE |
| FA/FB | DDRB / port B | DDR bit=1 時輸出 |
| FC/FD | DDRC / port C | 同上 |
| FE/FF | DDRD / port D | 同上 |

SPC_FNC、MPAGE 在獨立封裝內保留讀寫，但沒有連接 CPU 程式記憶體；不能只寫這兩個位址就操作外部 ROM/RAM。IE 這個 extended 輸入在此原始模組內未使用。

### 8.2 Timer2 / Counter2

T2CON bit2=TR2，bit1=C/T2，bit0=CP/RL2，bit3=EXEN2，bit4=TCLK，bit5=RCLK，bit6=EXF2，bit7=TF2。P1.0 是計數輸入，P1.1 是外部 capture/reload 或方向輸入。兩個下降沿都由前一拍 pins_d 與本拍 p1 比較。

一般 Timer2 在 TR2=1 時依 timer_tick 遞增；CKCON[5]、baud_mode 或 T2MOD[1] 任一有效會改用每個有效主時鐘。C/T2=1 時改選 P1.0 下降沿。寫 TL2/TH2 的同拍抑制計數器自動變更。

一般向上數到 FFFF：自動重載模式回 reload2；capture 模式回 0000。baud mode、up/down、clock-out 都會走重載條件。T2MOD[0]=1 且非 baud mode 時，P1.1 低改為向下數；到 reload2 後回 FFFF，並翻轉 EXF2。一般溢位設定 TF2，但 baud mode 或 clock-out 時不設定 TF2。

EXEN2=1、P1.1 下降沿且未使用 up/down 時觸發外部動作：設定 EXF2；非 baud 且 CP/RL2=1 時將 counter2 複製到 reload2，否則將 reload2 載回 counter2。若與溢位同拍，後面的 external 動作可能覆寫前面的 counter2 指派；capture 得到的是該拍更新前的 counter2。

Timer2 溢位脈波也送給 UART0；TCLK/RCLK 分別選傳送／接收來源。T2MOD[1] 且 TR2=1 且 C/T2=0 才啟用輸出，每次到達計數終值翻轉 t2_out。穩態重載時計數長度 `65536-reload2`，clock-out 約為主時鐘除以該長度再除 2。

### 8.3 UART1 與 EX2～EX5

UART1 的 RXD 為 P1.2、TXD 經 GPIO 接 P1.3。SCON1 的 RI/TI/RB8 由 UART 事件更新，軟體寫入後同拍硬體事件優先。

P1.4～P1.7 下降沿分別置 EXIF[4]～[7]，但只在對應 EIE[4]～[7] 已開啟且 run_enable=1 時捕捉。這與「先記旗標、之後才 enable」的設計不同；停用期間的邊沿不保留。EXIF 旗標由軟體寫入清除。

### 8.4 Export IO

port B/C/D 讀回公式為 `(input & ~DDR) | (latch & DDR)`：輸入位讀外部，輸出位讀 latch。OE 直接等於 DDR。port A 沒有 DDR，export_a 輸出 latch，但讀 F9 永遠取 export_a_in。新的封裝將這些原 CPU 頂層原本懸空的輸出接出；實際板子仍需分配腳位、方向與三態。

## 9. ADC SPI：同檔內的 mcu8051_adc_spi

這是特定 ADC 命令流程，不能當作任意 SPI master。寫 F8，且新 wdata[6]=1、舊 control[6]=0，會在 IDLE 啟動。第一 byte 為 `A0 | wdata[3:0]`，第二 byte=41，等待同步後 MISO 為低，再送 00、00。第三 byte 回傳值存 result_hi，第四 byte 存 result_lo；最後 control[7]=1、control[6]=0，CS 拉高。

| 狀態 | 動作 |
|---|---|
| IDLE | SCLK idle 高，等待 start |
| LOW | 分頻到點拉低 SCLK，更新 MOSI |
| HIGH | 分頻到點拉高 SCLK，取樣同步後 MISO |
| PAUSE | 字節間 GAP 計數 |
| READY | 等 MISO 低，沒有 timeout |
| FINISH | 設完成旗標，清 busy，釋放 CS |

預設 HALF_PERIOD=66，因此 SPI clock 約 `Fclk/(2*66)`；GAP=100 個主時鐘。MISO 有兩級同步。SCLK 為 Mode3 行為，CS 在整個四 byte 流程中保持低。READY 若一直等不到低，交易會停在該處，需外部處理復原。control 可被軟體再寫，busy 期間應避免重新寫控制值。

div_count 與 gap_count 均為 8-bit，變更 HALF_PERIOD/GAP 時必須留在計數器可表示的範圍且大於 0。模組沒有 run_enable，所以主周邊停用時 ADC 仍繼續。

## 10. 中斷輸出與主機整合

irq_pending 的 bit 編號沿用原 CPU 的 source 編號：

| bit/source | 來源 | 已套用 enable |
|---|---|---|
| 0 | INT0 | IE[0] |
| 1 | Timer0 | IE[1] |
| 2 | INT1 | IE[2] |
| 3 | Timer1 或 split TH0 | IE[3] |
| 4 | UART0 RI/TI | IE[4] |
| 5 | Timer2 TF2/EXF2 | IE[5] |
| 6 | EICON[4] | EICON[5] |
| 7 | UART1 RI/TI | IE[6] |
| 8～11 | EX2～EX5 | EIE[4]～[7] |
| 12 | EICON[3] | EICON[0] |

bit6/12 僅是原頂層的 EICON 請求接線，本套件不另外宣稱有獨立 watchdog 硬體。`IE[7] && |irq_pending` 可供單一 IRQ 線的基本總允許判斷，但若要重現 8051 優先權，還需要 IP/EIE/EICON 的仲裁與中斷服務狀態。

原 CPU 的來源排序為 0、1、2、3、4、5、7、8、9、10、11、6、12，先高優先群再低優先群；向量為 `source*8+3`。新增封裝不產生該向量，方便其他 CPU 自行映射至中斷控制器。

接其他 CPU 的建議順序：先做同步 byte SFR 轉接，驗證 GPIO；再確認 Fclk、TIMER_CLK_DIV、CKCON 與 UART 設定；最後整合中斷 enable、旗標清除和實體 I/O 限制。RTL 模擬通過不能替代非同步輸入 CDC 檢查與 FPGA 時序收斂。
