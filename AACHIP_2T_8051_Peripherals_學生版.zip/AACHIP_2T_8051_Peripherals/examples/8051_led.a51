; 基本 8051 範例；用 P1.0 驅動 LED，週期依 CPU 時鐘決定。
; 對應 8051_led.hex，每行一個 byte，可用 $readmemh 載入。
        ORG 0000H
        MOV P1,#0FFH
LOOP:   XRL P1,#01H
        MOV R7,#0FFH
OUTER:  MOV R6,#0FFH
INNER:  DJNZ R6,INNER
        DJNZ R7,OUTER
        SJMP LOOP
        END
