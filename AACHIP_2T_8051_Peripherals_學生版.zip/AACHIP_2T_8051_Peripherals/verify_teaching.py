"""Verify archived source hashes and exact executable-line preservation."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest().upper()
def code_lines(path):
 return [line.split('//',1)[0].rstrip() for line in path.read_text(encoding='utf-8-sig').splitlines()
         if line.split('//',1)[0].strip()]
manifest=json.loads((ROOT/'teaching_manifest.json').read_text(encoding='utf-8'))
if (ROOT/'core_teaching_manifest.json').exists():
 manifest+=json.loads((ROOT/'core_teaching_manifest.json').read_text(encoding='utf-8'))
original=json.loads((ROOT/'source_manifest.json').read_text(encoding='utf-8-sig'))
entries={item['path']:item for item in manifest}
actual={str(p.relative_to(ROOT)).replace('\\','/') for p in (ROOT/'rtl').glob('*.v')}
assert actual==set(entries),'RTL file set changed'
total=0
for item in manifest:
 before=ROOT/item['backup'];after=ROOT/item['path']
 assert digest(before)==item['original_sha256'],'Backup changed: '+item['backup']
 assert code_lines(before)==code_lines(after),'Executable line changed: '+item['path']
 previous=''
 for line in after.read_text(encoding='utf-8-sig').splitlines():
  if line.split('//',1)[0].strip():
   assert previous.lstrip().startswith('// 【教學】'),'Missing teaching comment: '+item['path']+': '+line
   total+=1
  previous=line
for item in original:
 backup=ROOT/entries[item['destination']]['backup']
 assert digest(backup)==item['sha256'],'Original source hash changed: '+item['destination']
print(f'PASS: {len(manifest)} RTL files, {total} executable lines each annotated; executable lines unchanged; original source SHA-256 verified')
