/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0x90) LED;
void Delay(void) {
#if LAB_FAST_SIM
 TH0=0xFF; TL0=0xE0; /* Mode 1: 32 timer ticks, DIV=12. */
#else
 TH0=0x80; TL0=0x10;
#endif
 TF0=0; TR0=1; while(TF0==0) {} TR0=0; TF0=0;
}
void main(void) { TMOD=0x01; LED=1; while(1) { LED=!LED; Delay(); } }
