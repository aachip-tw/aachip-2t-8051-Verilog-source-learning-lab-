/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0x80) RS;
__sbit __at(0x81) EN;
void LcdWait(void) { int i; for(i=0;i<LCD_WAIT;i++) {} }
void LcdNibble(unsigned char n) { P2=(n & 0x0F)<<4; EN=1; LcdWait(); EN=0; LcdWait(); }
void LcdCommand(unsigned char value) { RS=0; LcdNibble(value>>4); LcdNibble(value); }
void LcdChar(unsigned char value) { RS=1; LcdNibble(value>>4); LcdNibble(value); }
void main(void) {
 RS=0; EN=0; LcdWait();
 LcdNibble(3); LcdNibble(3); LcdNibble(3); LcdNibble(2);
 LcdCommand(0x28); LcdCommand(0x0C); LcdCommand(0x06); LcdCommand(0x01);
 LcdCommand(0x80); LcdChar('S');
 while(1) {}
}
