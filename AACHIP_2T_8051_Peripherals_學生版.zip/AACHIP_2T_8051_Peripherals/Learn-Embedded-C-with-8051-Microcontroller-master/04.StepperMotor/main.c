/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
void Delay(void) { int i,j; for(i=0;i<STEPPER_OUTER;i++) for(j=0;j<STEPPER_INNER;j++) {} }
void main(void) { while(1) {
 P2=0x01; Delay(); P2=0x03; Delay(); P2=0x02; Delay(); P2=0x06; Delay();
 P2=0x04; Delay(); P2=0x0C; Delay(); P2=0x08; Delay(); P2=0x09; Delay();
} }
