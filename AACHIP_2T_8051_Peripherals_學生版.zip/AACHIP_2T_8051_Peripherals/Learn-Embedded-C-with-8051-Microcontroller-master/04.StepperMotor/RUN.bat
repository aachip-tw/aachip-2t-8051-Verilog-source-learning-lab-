@echo off
setlocal
pushd "%~dp0..\.."
python -u tools\run_lessons.py 04 --open
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo FAIL - see build\lessons\04.StepperMotor\*.log
popd
pause
exit /b 1
