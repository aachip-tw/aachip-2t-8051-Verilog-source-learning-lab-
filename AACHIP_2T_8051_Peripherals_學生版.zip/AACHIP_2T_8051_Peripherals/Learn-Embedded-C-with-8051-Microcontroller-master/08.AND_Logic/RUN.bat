@echo off
setlocal
pushd "%~dp0..\.."
python -u tools\run_lessons.py 08 --open
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo FAIL - see build\lessons\08.AND_Logic\*.log
popd
pause
exit /b 1
