/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0x97) Led;
__sbit __at(0x86) SwitchA;
__sbit __at(0x87) SwitchB;
/* Inputs and LED are active low: both switches must be pressed. */
void main(void) { P0=0xFF; P1=0xFF; while(1) {
 if(SwitchA==0 && SwitchB==0) Led=0; else Led=1;
} }
