/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0x80) button;
__sbit __at(0x90) led;
void main(void) { P0=0xFF; P1=0xFF; while(1) { if(button) led=1; else led=0; } }
