/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0x80) LED;
void Delay(void) { int i; for(i=0;i<PIN_LIMIT;i++) {} }
void main(void) { while(1) { LED=0; Delay(); LED=1; Delay(); } }
