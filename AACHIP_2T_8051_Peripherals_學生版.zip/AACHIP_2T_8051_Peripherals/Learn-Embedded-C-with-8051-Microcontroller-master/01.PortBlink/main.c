/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
__sbit __at(0xA0) LED;
void Delay(void) { int i,j; for(i=0;i<10;i++) for(j=0;j<BLINK_LIMIT;j++) {} }
void main(void) { while(1) { LED=0; Delay(); LED=1; Delay(); } }
