@echo off
setlocal
pushd "%~dp0..\.."
python -u tools\run_lessons.py 01 --waves-only
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo FAIL - see build\lessons\01.PortBlink\*.log
popd
pause
exit /b 1
