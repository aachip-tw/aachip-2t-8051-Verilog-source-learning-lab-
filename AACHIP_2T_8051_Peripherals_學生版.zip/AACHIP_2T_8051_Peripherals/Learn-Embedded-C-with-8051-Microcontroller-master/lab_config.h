/* AACHIP labs: 1 = fast RTL teaching simulation; 0 = original long counts. */
#ifndef LAB_CONFIG_H
#define LAB_CONFIG_H
#define LAB_FAST_SIM 1
#if LAB_FAST_SIM
#define BLINK_LIMIT 10
#define PIN_LIMIT 10
#define STEPPER_OUTER 1
#define STEPPER_INNER 2
#define LCD_WAIT 1
#else
#define BLINK_LIMIT 10000
#define PIN_LIMIT 30000
#define STEPPER_OUTER 1000
#define STEPPER_INNER 100
#define LCD_WAIT 100
#endif
#endif
