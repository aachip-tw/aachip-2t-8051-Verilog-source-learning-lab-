@echo off
setlocal
pushd "%~dp0..\.."
python -u tools\run_lessons.py 02 --open
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo FAIL - see build\lessons\02.Blink_LED\*.log
popd
pause
exit /b 1
