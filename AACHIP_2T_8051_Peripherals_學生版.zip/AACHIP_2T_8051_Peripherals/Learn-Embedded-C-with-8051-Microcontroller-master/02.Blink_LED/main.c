/* AACHIP 8051 IDE C compiler teaching example. */
#include <reg51.h>
#include "../lab_config.h"
void Delay(void) { int i; for(i=0;i<BLINK_LIMIT;i++) {} }
void main(void) { while(1) { P0=0; Delay(); P0=1; Delay(); } }
